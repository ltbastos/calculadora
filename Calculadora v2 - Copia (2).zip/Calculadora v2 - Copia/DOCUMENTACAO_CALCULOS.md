# Documentacao detalhada das secoes da calculadora

Este documento descreve o comportamento atual da aplicacao com base na logica implementada em `index.html` e `script.js`.

Arquivos complementares:

- Guia visual HTML: `docs/GUIA_VISUAL_CALCULOS.html`
- Guia visual PDF: `docs/GUIA_VISUAL_CALCULOS.pdf`

Objetivo deste material:

- explicar o que cada secao faz;
- dizer quais campos/colunas entram em cada calculo;
- mostrar a formula usada em cada etapa;
- registrar observacoes importantes da implementacao atual.

## 1. Informacoes da empresa e parametros gerais

Esta primeira secao e principalmente cadastral. Ela nao faz os calculos financeiros das tabelas, mas define alguns parametros usados depois.

![Captura da secao Informacoes da empresa](docs/imagens/01-informacoes-gerais.jpg)

### 1.1. Campos desta secao

- `Visao`
- `Numero do Grupo`
- `Nome da Empresa`
- `Composicao do Grupo Economico`
- `Agencia`
- `Conta`
- `CNPJ`
- `Faturamento Total Mensal com Cartoes (R$) - (a ser negociado)`
- `Faturamento Total Anual com Cartoes (R$)`
- `Tipo de Cliente`
- `Recebiveis Antecipados (R.A)?`

### 1.2. O que cada parte faz

#### Visao: `CNPJ` ou `Grupo Economico`

- Se o usuario marcar `Grupo Economico`, o sistema:
- muda o rotulo `Nome da Empresa` para `Nome do Grupo`;
- esconde os campos `Agencia`, `Conta` e `CNPJ`;
- mostra `Numero do Grupo`;
- mostra a area `Composicao do Grupo Economico`.

- Se o usuario marcar `CNPJ`, o sistema faz o inverso:
- volta o rotulo para `Nome da Empresa`;
- mostra `Agencia`, `Conta` e `CNPJ`;
- esconde `Numero do Grupo`;
- esconde `Composicao do Grupo Economico`.

#### Composicao do Grupo Economico

- Os campos `CNPJs`, `Agencia(s)` e `Conta(s)` aceitam somente numeros.
- O usuario pode digitar um item por vez ou varios itens separados por virgula.
- Cada valor valido vira um "chip" visual na tela.
- Esta parte e apenas cadastral; nao entra nos calculos financeiros.

#### Faturamento total mensal e anual

- O campo usado como entrada e `Faturamento Total Mensal com Cartoes (R$) - (a ser negociado)`.
- O campo `Faturamento Total Anual com Cartoes (R$)` e calculado automaticamente.

Formula:

- `Faturamento Total Anual = Faturamento Total Mensal x 12`

#### Tipo de Cliente

Valores possiveis:

- `Conquista`
- `Blindagem`

Este campo impacta a secao `O que o Cliente trara na negociacao`:

- Em `Blindagem`, o sistema nao calcula repasse novo para:
- `Faturamento em Cartao`
- `Alelo / Veloe Go`
- `Tag Veloe`

- Em `Conquista`, essas linhas sao consideradas normalmente.

#### Recebiveis Antecipados (R.A)

Este campo tambem impacta a secao `O que o Cliente trara na negociacao`, especificamente a linha `Faturamento em Cartao`.

Percentuais usados:

- se `Sim`: `0,003` = `0,30%`
- se `Nao`: `0,0015` = `0,15%`
- se nada for marcado: `0`

## 2. Comparativo de Taxas: Debito, Credito e Parcelamento

Esta parte compara o custo da Cielo com o custo do concorrente por bandeira.

![Captura da secao Comparativo de Taxas](docs/imagens/02-comparativo-taxas.jpg)

### 2.1. Secoes existentes

- `Debito`
- `Credito`
- `Parcelamento`

Observacao:

- `Debito` usa as bandeiras `Visa`, `Master` e `Elo`.
- `Credito` e cada `Parcelamento` usam `Visa`, `Master`, `Elo` e `Amex`.
- O primeiro parcelamento criado por padrao vem como `6x`.
- Novos parcelamentos podem ser adicionados e usam exatamente a mesma formula do `Credito`.

### 2.2. Colunas usadas em cada linha

Para cada bandeira, a tabela usa:

- `Bandeira`
- `Faturamento Mes (R$)`
- `Taxa Cielo (%)`
- `Taxa Conc (%)`
- `Custo Cielo`
- `Custo Conc`
- `Diferenca`

### 2.3. Calculo de cada linha

Para cada bandeira, o sistema faz este fluxo:

1. Le o valor da coluna `Faturamento Mes (R$)`.
2. Le o valor da coluna `Taxa Cielo (%)`.
3. Le o valor da coluna `Taxa Conc (%)`.
4. Calcula o custo da Cielo.
5. Calcula o custo do concorrente.
6. Calcula a diferenca em reais da linha.
7. Preenche as colunas calculadas.

Formulas da linha:

- `Custo Cielo = Faturamento Mes x (Taxa Cielo / 100)`
- `Custo Conc = Faturamento Mes x (Taxa Conc / 100)`
- `Diferenca = Custo Cielo - Custo Conc`

Leitura pratica:

- se a `Diferenca` da linha ficar positiva, a Cielo esta mais cara naquela linha;
- se a `Diferenca` da linha ficar negativa, o concorrente esta mais caro naquela linha.

### 2.4. Resumo de cada secao

Quando o usuario clica em `Calcular Diferenca`, o sistema soma todas as bandeiras daquela secao.

Entradas consideradas:

- todas as colunas `Faturamento Mes (R$)` da secao;
- todas as colunas `Taxa Cielo (%)` da secao;
- todas as colunas `Taxa Conc (%)` da secao.

Passo a passo:

1. Soma todos os `Custo Cielo` das bandeiras da secao.
2. Soma todos os `Custo Conc` das bandeiras da secao.
3. Projeta os dois totais para o ano.
4. Calcula a diferenca mensal total.
5. Calcula a diferenca anual total.
6. Monta um texto dizendo se o concorrente esta maior, menor ou igual a Cielo.

Formulas do resumo da secao:

- `Total Cielo Mensal = soma dos Custos Cielo`
- `Total Concorrente Mensal = soma dos Custos Conc`
- `Total Cielo Anual = Total Cielo Mensal x 12`
- `Total Concorrente Anual = Total Concorrente Mensal x 12`
- `Diferenca Mensal Total = Total Concorrente Mensal - Total Cielo Mensal`
- `Diferenca Anual Total = Total Concorrente Anual - Total Cielo Anual`

Leitura pratica do resumo:

- se `Diferenca Mensal Total` ficar positiva, o concorrente custa mais no total da secao;
- se ficar negativa, a Cielo custa mais.

### 2.5. Observacoes importantes desta secao

- Na coluna `Diferenca` de cada linha, o calculo e `Cielo - Concorrente`.
- No resumo da secao, a diferenca total e exibida como `Concorrente - Cielo`.
- Ou seja: a logica do sinal da linha e a do resumo nao estao no mesmo sentido.
- Existe um bloco visual no HTML para `VISA`, `MASTER` e `ELO` (`resultado-taxas`), mas a implementacao atual nao preenche esse bloco com calculos.

## 3. Informacoes de Equipamentos

Esta secao compara custo mensal e anual de equipamentos da Cielo contra o concorrente.

![Captura da secao Equipamentos](docs/imagens/03-equipamentos.jpg)

### 3.1. Colunas usadas

As colunas dos modelos sao:

- `ZIP`
- `FLASH`
- `LIO`
- `TEF`

As linhas usadas na tabela sao:

- `Qtd Cielo`
- `Qtd Concorrente`
- `Custo Unitario Mensal Cielo (R$)`
- `Custo Unitario Mensal Concorrente (R$)`

### 3.2. Calculo por modelo

Para cada modelo, o sistema usa:

- a quantidade da linha `Qtd Cielo`;
- a quantidade da linha `Qtd Concorrente`;
- o custo unitario da linha `Custo Unitario Mensal Cielo (R$)`;
- o custo unitario da linha `Custo Unitario Mensal Concorrente (R$)`.

Formulas por modelo:

- `Custo Mensal Cielo do modelo = Qtd Cielo x Custo Unitario Mensal Cielo`
- `Custo Mensal Concorrente do modelo = Qtd Concorrente x Custo Unitario Mensal Concorrente`

### 3.3. Totais da secao

Depois o sistema soma todos os modelos.

Formulas dos totais:

- `Qtd Total Cielo = soma das quantidades da Cielo`
- `Qtd Total Concorrente = soma das quantidades do concorrente`
- `Custo Total Cielo Mensal = soma dos custos mensais da Cielo`
- `Custo Total Concorrente Mensal = soma dos custos mensais do concorrente`
- `Custo Total Cielo Anual = Custo Total Cielo Mensal x 12`
- `Custo Total Concorrente Anual = Custo Total Concorrente Mensal x 12`

Texto comparativo da secao:

- `Diferenca = Custo Total Cielo Mensal - Custo Total Concorrente Mensal`

Leitura pratica:

- se a diferenca ficar positiva, a Cielo esta mais cara no custo mensal;
- se a diferenca ficar negativa, a Cielo esta mais barata.

## 4. Pix na Maquininha

Esta secao calcula o custo atual e o custo proposto para Pix na maquininha, e mostra a reducao mensal e anual.

![Captura da secao Pix na Maquininha](docs/imagens/04-pix-maquininha.jpg)

### 4.1. Campos/colunas usados

Bloco `VOLUME FINANCEIRO (R$)`:

- `Volume Atual Bradesco (R$)`
- `Volume Novo (R$)`
- `Volume Total (R$)`

Bloco `QUANTIDADE`:

- `Quantidade Atual Bradesco`
- `Quantidade Novo`
- `Quantidade Total`

Bloco `TAXA (%)`:

- `Taxa Atual (%)`
- `Valor Maximo Atual (R$)`
- `Taxa Proposta (%)`
- `Valor Maximo Proposto (R$)`

Bloco `TARIFA (R$)`:

- `Tarifa Atual (R$)`
- `Tarifa Proposta (R$)`

Bloco `CUSTO CLIENTE`:

- `Custo Atual (R$)`
- `Custo Proposto (R$)`

Bloco `REDUCAO CUSTO`:

- `Reducao Mes (R$)`
- `Reducao Ano (R$)`

### 4.2. Primeira etapa: totais de volume e quantidade

O sistema primeiro soma os campos de Bradesco com os campos novos.

Formulas:

- `Volume Total = Volume Atual Bradesco + Volume Novo`
- `Quantidade Total = Quantidade Atual Bradesco + Quantidade Novo`

### 4.3. Segunda etapa: escolha entre taxa ou tarifa

Para o bloco `Atual`:

- se `Tarifa Atual (R$)` for maior que zero, o sistema usa `tarifa`;
- senao, usa `Taxa Atual (%)`.

Para o bloco `Proposta`:

- se `Tarifa Proposta (R$)` for maior que zero, o sistema usa `tarifa`;
- senao, usa `Taxa Proposta (%)`.

Comportamento adicional:

- ao digitar `Tarifa`, o sistema limpa `Taxa` e `Valor Maximo` do mesmo bloco;
- ao digitar `Taxa`, o sistema limpa `Tarifa` do mesmo bloco.

### 4.4. Formula do custo quando o tipo for `Taxa`

Entradas usadas:

- `Volume Total`
- `Quantidade Total`
- `Taxa Atual (%)` ou `Taxa Proposta (%)`
- `Valor Maximo Atual (R$)` ou `Valor Maximo Proposto (R$)`

Passo a passo:

1. Calcula o custo base percentual.
2. Se houver quantidade e valor maximo, calcula o custo unitario.
3. Se o custo unitario passar do maximo, limita pelo teto.

Formulas:

- `Custo Base = Volume Total x (Taxa / 100)`
- `Custo Unitario = Custo Base / Quantidade Total`
- se `Custo Unitario > Valor Maximo`, entao:
- `Custo Final = Quantidade Total x Valor Maximo`
- senao:
- `Custo Final = Custo Base`

### 4.5. Formula do custo quando o tipo for `Tarifa`

Entradas usadas:

- `Quantidade Total`
- `Tarifa Atual (R$)` ou `Tarifa Proposta (R$)`

Formula:

- `Custo Final = Quantidade Total x Tarifa`

### 4.6. Saidas da secao

Depois de apurar o custo atual e o custo proposto, o sistema calcula:

- `Reducao Mes = Custo Atual - Custo Proposto`
- `Reducao Ano = Reducao Mes x 12`

Leitura pratica:

- se a reducao ficar positiva, a proposta esta mais barata que o cenario atual;
- se ficar negativa, a proposta esta mais cara.

## 5. Demais Servicos Pix

Esta secao aplica a mesma logica de `taxa` ou `tarifa`, mas separada em duas linhas de servico Pix.

![Captura da secao Demais Servicos Pix](docs/imagens/05-demais-servicos-pix.jpg)

### 5.1. Linhas existentes

- `Pix Recebimento QR Code (exceto Pix na Maquininha)`
- `Pix Pagamento por Transferibilidade`

### 5.2. Colunas usadas em cada linha

- `Volume Bradesco`
- `Volume Novo`
- `Volume Total`
- `Quantidade Bradesco`
- `Quantidade Novo`
- `Quantidade Total`
- `Tipo`
- `Atual Taxa/Tarifa`
- `Atual Max.`
- `Proposto Taxa/Tarifa`
- `Proposto Max.`
- `Mes`
- `Ano`

### 5.3. Etapas do calculo em cada linha

#### Etapa 1: totalizar volume e quantidade

Formulas:

- `Volume Total = Volume Bradesco + Volume Novo`
- `Quantidade Total = Quantidade Bradesco + Quantidade Novo`

#### Etapa 2: identificar o tipo escolhido

O campo `Tipo` pode ser:

- `Taxa`
- `Tarifa`

#### Etapa 3: calcular custo atual

Se `Tipo = Taxa`:

- `Custo Atual Base = Volume Total x (Atual Taxa/Tarifa / 100)`
- `Custo Unitario Atual = Custo Atual Base / Quantidade Total`
- se `Custo Unitario Atual > Atual Max.`, entao:
- `Custo Atual = Quantidade Total x Atual Max.`
- senao:
- `Custo Atual = Custo Atual Base`

Se `Tipo = Tarifa`:

- `Custo Atual = Quantidade Total x Atual Taxa/Tarifa`

#### Etapa 4: calcular custo proposto

Se `Tipo = Taxa`:

- `Custo Proposto Base = Volume Total x (Proposto Taxa/Tarifa / 100)`
- `Custo Unitario Proposto = Custo Proposto Base / Quantidade Total`
- se `Custo Unitario Proposto > Proposto Max.`, entao:
- `Custo Proposto = Quantidade Total x Proposto Max.`
- senao:
- `Custo Proposto = Custo Proposto Base`

Se `Tipo = Tarifa`:

- `Custo Proposto = Quantidade Total x Proposto Taxa/Tarifa`

#### Etapa 5: calcular reducao da linha

- `Reducao Mes = Custo Atual - Custo Proposto`
- `Reducao Ano = Reducao Mes x 12`

### 5.4. Totais da secao

O sistema soma as duas linhas.

Formulas:

- `Custo Atual Total = soma dos custos atuais das linhas`
- `Custo Proposto Total = soma dos custos propostos das linhas`
- `Reducao Total Mes = soma das reducoes mensais das linhas`
- `Reducao Total Ano = soma das reducoes anuais das linhas`

### 5.5. Observacao importante

- Os campos `Atual Max.` e `Proposto Max.` so entram no calculo quando `Tipo = Taxa`.
- Se `Tipo = Tarifa`, esses campos ficam sem efeito pratico.

## 6. Produtos e Servicos Diversos

Esta secao compara custo atual e custo proposto de varios servicos unitarios.

![Captura da secao Produtos e Servicos Diversos](docs/imagens/06-produtos-servicos-diversos.jpg)

### 6.1. Linhas existentes

- `Cesta de Servicos`
- `Cartao de Credito: Anuidade`
- `Boletos: Tarifa de Registro`
- `Folha de Pagamento: Transmissao`
- `TED`

### 6.2. Colunas usadas em cada linha

- `Quantidade de Transacoes - Bradesco`
- `Quantidade de Transacoes - Novo`
- `Quantidade de Transacoes - Total`
- `Valor pago pelo Cliente/mes (R$) - Volume Bradesco`
- `Valor pago pelo Cliente/mes (R$) - Volume Novo`
- `Valor pago pelo Cliente/mes (R$) - Volume Total`
- `Valor Unitario (R$) - Atual`
- `Valor Unitario (R$) - Proposto`
- `Reducao (R$) - Mes`
- `Reducao (R$) - Ano`
- `Reducao (R$) - % Dif`

### 6.3. Regra especial antes do calculo

Se a linha estiver assim:

- `Quantidade Bradesco + Quantidade Novo = 0`
- e o usuario tiver preenchido `Atual` ou `Proposto`

entao o sistema forca:

- `Quantidade Bradesco = 1`

Ou seja: mesmo sem quantidade digitada, uma linha com valor unitario preenchido passa a ser tratada como se tivesse 1 unidade.

### 6.4. Calculo de cada linha

Depois de definir as quantidades, o sistema calcula:

- `Quantidade Total = Quantidade Bradesco + Quantidade Novo`
- `Volume Bradesco = Quantidade Bradesco x Valor Unitario Atual`
- `Volume Novo = Quantidade Novo x Valor Unitario Proposto`
- `Volume Total = Volume Bradesco + Volume Novo`
- `Custo Atual da Linha = Quantidade Total x Valor Unitario Atual`
- `Custo Proposto da Linha = Quantidade Total x Valor Unitario Proposto`
- `Reducao Mes = Custo Atual da Linha - Custo Proposto da Linha`
- `Reducao Ano = Reducao Mes x 12`
- `% Dif = (Reducao Mes / Custo Atual da Linha) x 100`

Leitura pratica:

- se `Reducao Mes` ficar positiva, o proposto esta menor que o atual;
- se ficar negativa, o proposto esta maior.

### 6.5. Totais da secao

O sistema soma todas as linhas validas.

Campos totalizados:

- `total-qtd-bradesco`
- `total-qtd-novo`
- `total-qtd`
- `total-vol-bradesco`
- `total-vol-novo`
- `total-vol-total`
- `total-atual`
- `total-proposto`
- `total-mes`
- `total-ano`
- `total-percentual`

Formulas dos totais:

- `Total Qtd Bradesco = soma das quantidades Bradesco`
- `Total Qtd Novo = soma das quantidades Novo`
- `Total Qtd = soma das quantidades totais`
- `Total Volume Bradesco = soma dos volumes Bradesco`
- `Total Volume Novo = soma dos volumes Novo`
- `Total Volume Total = soma dos volumes totais`
- `Total Atual = soma dos custos atuais das linhas`
- `Total Proposto = soma dos custos propostos das linhas`
- `Total Mes = Total Atual - Total Proposto`
- `Total Ano = Total Mes x 12`

Percentual total da secao:

- o sistema nao faz media ponderada por valor;
- ele soma o `% Dif` das linhas que possuem `Custo Atual da Linha` diferente de zero;
- depois divide pelo numero de linhas validas.

Formula:

- `Media Percentual = soma dos percentuais das linhas validas / quantidade de linhas validas`

### 6.6. Observacoes importantes

- As colunas `Volume Bradesco`, `Volume Novo` e `Volume Total` nao sao digitadas pelo usuario; elas sao calculadas.
- A coluna `Volume Novo` usa `Quantidade Novo x Valor Unitario Proposto`.
- O total percentual e uma media simples, nao ponderada.

## 7. Produtos e Servicos Consolidados

Esta secao junta tres blocos anteriores:

![Captura da secao Produtos e Servicos Consolidados](docs/imagens/07-servicos-consolidados.jpg)

- `Produtos e Servicos Diversos`
- `Pix na Maquininha`
- `Demais Servicos Pix`

### 7.1. Colunas desta secao

- `Secao`
- `Valor pago pelo cliente (R$) - Mes`
- `Valor pago pelo cliente (R$) - Ano`
- `Reducao (R$) - Mes`
- `Reducao (R$) - Ano`
- `Reducao (R$) - % Dif`

### 7.2. De onde cada linha puxa os valores

#### Linha `Produtos e Servicos Diversos`

Campos de origem:

- `total-atual`
- `total-proposto`
- `total-mes`
- `total-ano`

Valores calculados:

- `Valor pago pelo cliente (Mes) = total-proposto`
- `Valor pago pelo cliente (Ano) = total-proposto x 12`
- `Reducao Mes = total-mes`
- `Reducao Ano = total-ano`
- `% Dif = total-mes / total-atual x 100`

#### Linha `Pix na Maquininha`

Campos de origem:

- `pixmaq-custo-atual`
- `pixmaq-custo-proposto`
- `pixmaq-reducao-mes`
- `pixmaq-reducao-ano`

Valores calculados:

- `Valor pago pelo cliente (Mes) = pixmaq-custo-proposto`
- `Valor pago pelo cliente (Ano) = pixmaq-custo-proposto x 12`
- `Reducao Mes = pixmaq-reducao-mes`
- `Reducao Ano = pixmaq-reducao-ano`
- `% Dif = pixmaq-reducao-mes / pixmaq-custo-atual x 100`

#### Linha `Demais Servicos Pix`

Campos de origem:

- `pixdem-total-atual`
- `pixdem-total-proposto`
- `pixdem-total-mes`
- `pixdem-total-ano`

Valores calculados:

- `Valor pago pelo cliente (Mes) = pixdem-total-proposto`
- `Valor pago pelo cliente (Ano) = pixdem-total-proposto x 12`
- `Reducao Mes = pixdem-total-mes`
- `Reducao Ano = pixdem-total-ano`
- `% Dif = pixdem-total-mes / pixdem-total-atual x 100`

### 7.3. Total consolidado

Depois o sistema soma as tres linhas.

Formulas:

- `Total Atual Consolidado = total-atual + pixmaq-custo-atual + pixdem-total-atual`
- `Total Valor Mes = total-proposto + pixmaq-custo-proposto + pixdem-total-proposto`
- `Total Valor Ano = Total Valor Mes x 12`
- `Total Reducao Mes = total-mes + pixmaq-reducao-mes + pixdem-total-mes`
- `Total Reducao Ano = total-ano + pixmaq-reducao-ano + pixdem-total-ano`
- `Total % Dif = Total Reducao Mes / Total Atual Consolidado x 100`

### 7.4. Observacao importante

- A coluna `Valor pago pelo cliente` mostra o valor `proposto`, e nao o valor atual.

## 8. O que o Cliente trara na negociacao

Esta secao calcula o resultado estimado de novos negocios para o banco.

![Captura da secao O que o Cliente trara na negociacao](docs/imagens/08-negociacao.jpg)

### 8.1. Colunas usadas

- `Produto/Servico`
- `Quantidade`
- `Volume Financeiro (R$)`
- `Tarifa Proposta (R$)`
- `Taxa Proposta (%)`
- `Valor Max. (R$)`
- `Repasse Mes (R$)`
- `Repasse Ano (R$)`

### 8.2. Regra geral desta secao

O sistema calcula cada linha separadamente e depois soma tudo.

Formula final de cada linha:

- `Repasse Ano = Repasse Mes x 12`

### 8.3. Formula de cada linha

#### Linha `Faturamento em Cartao`

Campos usados:

- `Volume Financeiro (R$)`
- `Recebiveis Antecipados (R.A)?`
- `Tipo de Cliente`

Formula:

- se `Tipo de Cliente = Blindagem`, entao:
- `Repasse Mes = 0`

- senao:
- `Repasse Mes = Volume Financeiro x Percentual RA`

Percentual RA usado:

- `Sim = 0,30%`
- `Nao = 0,15%`
- em branco = `0%`

Observacao:

- nesta linha, `Quantidade`, `Tarifa Proposta`, `Taxa Proposta` e `Valor Max.` nao entram no calculo atual.

#### Linha `Boletos - Emissao Cliente`

Campos usados:

- `Quantidade`
- `Volume Financeiro (R$)`
- `Tarifa Proposta (R$)`
- `Taxa Proposta (%)`
- `Valor Max. (R$)`

Se `Tarifa Proposta (R$) > 0`:

- `Repasse Mes = (Tarifa Proposta - 0,55) x Quantidade`

Se `Tarifa Proposta` nao for usada e `Taxa Proposta (%) > 0`:

- `Custo Proposto = Volume Financeiro x (Taxa Proposta / 100)`
- calcula `Custo Unitario = Custo Proposto / Quantidade`
- se `Custo Unitario > Valor Max.`, usa `Quantidade x Valor Max.`
- depois:
- `Repasse Mes = Custo Proposto Ajustado - (0,55 x Quantidade)`

Observacao:

- `0,55` e o custo base considerado pelo sistema para boletos.

#### Linha `Recebimento - Pix QR Code (chave/maquininha)`

Campos usados:

- `Quantidade`
- `Volume Financeiro (R$)`
- `Tarifa Proposta (R$)`
- `Taxa Proposta (%)`
- `Valor Max. (R$)`

Se `Tarifa Proposta (R$) > 0`:

- `Repasse Mes = (Tarifa Proposta - 0,20) x Quantidade`

Se `Tarifa Proposta` nao for usada e `Taxa Proposta (%) > 0`:

- calcula o custo proposto por taxa, com limitacao por `Valor Max.`;
- depois:
- `Repasse Mes = Custo Proposto Ajustado - (0,20 x Quantidade)`

Observacao:

- `0,20` e o custo base considerado pelo sistema para este servico.

#### Linha `Pagamento por Transferencia - Pix Chave`

Campos usados:

- `Quantidade`
- `Volume Financeiro (R$)`
- `Tarifa Proposta (R$)`
- `Taxa Proposta (%)`
- `Valor Max. (R$)`

Se `Tarifa Proposta (R$) > 0`:

- `Repasse Mes = (Tarifa Proposta - 0,04) x Quantidade`

Se `Tarifa Proposta` nao for usada e `Taxa Proposta (%) > 0`:

- calcula o custo proposto por taxa, com limitacao por `Valor Max.`;
- depois:
- `Repasse Mes = Custo Proposto Ajustado - (0,04 x Quantidade)`

Observacao:

- `0,04` e o custo base considerado pelo sistema para este servico.

#### Linha `Folha - Repasse GDAD Gerente PJ`

Campos usados:

- `Quantidade`
- `Volume Financeiro (R$)`

Formula:

- `Repasse Mes = Volume Financeiro x Quantidade x 0,20`

Observacao:

- `Tarifa Proposta`, `Taxa Proposta` e `Valor Max.` nao entram no calculo atual desta linha.

#### Linha `Alelo / Veloe Go`

Campos usados:

- `Quantidade`
- `Volume Financeiro (R$)`
- `Tarifa Proposta (R$)`
- `Taxa Proposta (%)`
- `Tipo de Cliente`

Formula:

- se `Tipo de Cliente = Blindagem`, entao:
- `Repasse Mes = 0`

- senao:
- `Taxa Percentual = Taxa Proposta / 100`
- se `Taxa Proposta` nao for informada, o sistema usa `3%`
- `Bonus por Cartao = Tarifa Proposta`
- se `Tarifa Proposta` nao for informada, o sistema usa `10`
- `Repasse Mes = (Volume Financeiro x Taxa Percentual) + (Quantidade x Bonus por Cartao)`

#### Linha `Tag Veloe`

Campos usados:

- `Quantidade`
- `Tarifa Proposta (R$)`
- `Tipo de Cliente`

Formula:

- se `Tipo de Cliente = Blindagem`, entao:
- `Repasse Mes = 0`

- senao:
- `Tarifa Tag = Tarifa Proposta`
- se `Tarifa Proposta` nao for informada, o sistema usa `10`
- `Repasse Mes = Quantidade x Tarifa Tag`

### 8.4. Total da secao

O total soma todas as linhas:

- `Total Mes = soma de todos os Repasse Mes`
- `Total Ano = soma de todos os Repasse Ano`

### 8.5. Observacoes importantes

- Nas linhas de `Boletos`, `Pix QR Code` e `Pix Pagamento`, se o usuario preencher `Tarifa Proposta` e `Taxa Proposta`, a `Tarifa Proposta` tem prioridade.
- `Blindagem` zera as linhas de novos ganhos em `Faturamento em Cartao`, `Alelo / Veloe Go` e `Tag Veloe`.

## 9. Invest Facil - Projecao com Conquista de Caixa

Esta secao transforma os volumes negociados em uma projecao de saldo e de resultado de Invest Facil.

![Captura da secao Invest Facil](docs/imagens/09-invest-facil.jpg)

### 9.1. Linhas/colunas usadas

Linhas de entrada mensal:

- `Volume Faturamento Cartoes`
- `Volume Boletos`
- `Volume Recebimento de Pix (todas as chaves)`
- `Volume Pix na Maquininha`
- `Volume Pagamentos Diversos`
- `Volume Folha de Pagamento`
- `Volume Alelo`
- `Volume Veloe Go`
- `Tag Veloe`

Colunas:

- `VOLUME MES (R$)`
- `VOLUME ANO (R$)`

Linha final:

- `Saldo`

### 9.2. Primeira etapa: anualizar cada linha

Para cada linha mensal, o sistema preenche a coluna anual:

- `Valor Anual da Linha = Valor Mensal da Linha x 12`

### 9.3. Segunda etapa: calcular o saldo

Entradas consideradas como `Entrada`:

- `Volume Faturamento Cartoes`
- `Volume Boletos`
- `Volume Recebimento de Pix`
- `Volume Pix na Maquininha`

Entradas consideradas como `Saida`:

- `Volume Pagamentos Diversos`
- `Volume Folha de Pagamento`
- `Volume Alelo`
- `Volume Veloe Go`
- `Tag Veloe`

Formulas:

- `Entrada = Faturamento Cartoes + Boletos + Pix + Pix na Maquininha`
- `Saida = Pagamentos Diversos + Folha + Alelo + Veloe Go + Tag Veloe`
- `Saldo Mes = Entrada - Saida`
- `Saldo Ano = Saldo Mes x 12`

### 9.4. Terceira etapa: calcular a projecao de Invest Facil

Depois o sistema pega o valor da linha `Saldo Mes` e aplica dois multiplicadores.

Formulas:

- `Repasse Mes = Saldo Mes x 0,0136`
- `Repasse Ano = Repasse Mes x 12`
- `Incremento Mes = Repasse Mes x 0,05`
- `Incremento Ano = Incremento Mes x 12`

### 9.5. O que aparece nos cards

Card `Saldo Medio Invest Projetado`:

- mostra `repasse-mes`
- mostra `repasse-ano`

Card `Resultado Invest Projetado`:

- mostra `incremento-mes`
- mostra `incremento-ano`

### 9.6. Observacao importante

- O valor exibido no card `Saldo Medio Invest Projetado` nao e o saldo bruto da tabela.
- O sistema mostra `Saldo x 1,36%`.
- Portanto, o rotulo visual e diferente da formula implementada.

## 10. Resumo Final

Esta secao consolida os resultados das secoes anteriores.

![Captura da secao Resumo Final](docs/imagens/10-resumo-final.jpg)

Antes de montar o resumo, o sistema executa novamente:

- comparativo de taxas;
- equipamentos;
- produtos e servicos diversos;
- Pix na maquininha;
- demais servicos Pix;
- consolidado de servicos;
- negociacao;
- Invest Facil.

### 10.1. Bloco `Comparativo de Taxas`

O resumo final pega:

- todas as linhas de `Debito`;
- todas as linhas de `Credito`;
- todas as linhas de cada `Parcelamento` existente.

Para cada linha, usa:

- `Faturamento Mes (R$)`
- `Taxa Cielo (%)`
- `Taxa Conc (%)`

Formulas:

- `Total Custo Cielo Mensal = soma de Faturamento x Taxa Cielo / 100`
- `Total Custo Concorrente Mensal = soma de Faturamento x Taxa Conc / 100`
- `Total Mensal Taxas = soma de Faturamento x (Taxa Conc - Taxa Cielo) / 100`
- `Total Anual Taxas = Total Mensal Taxas x 12`

Observacao:

- neste resumo, a diferenca esta no sentido `Concorrente - Cielo`.

### 10.2. Bloco `Equipamentos`

O resumo final reaproveita:

- `Qtd Cielo`
- `Qtd Concorrente`
- `Custo Unitario Mensal Cielo (R$)`
- `Custo Unitario Mensal Concorrente (R$)`

Formulas:

- `Qtd Cielo = soma das quantidades da Cielo`
- `Qtd Concorrente = soma das quantidades do concorrente`
- `Custo Cielo = soma de Qtd Cielo x Custo Unitario Cielo`
- `Custo Concorrente = soma de Qtd Concorrente x Custo Unitario Concorrente`
- `Diferenca Equipamentos Mes = Custo Concorrente - Custo Cielo`
- `Diferenca Equipamentos Ano = Diferenca Equipamentos Mes x 12`

### 10.3. Bloco `Produtos e Servicos Consolidados`

O resumo final usa os retornos da secao consolidada:

- `Total Valor Mes`
- `Total Valor Ano`
- `Total Reducao Mes`
- `Total Reducao Ano`
- `Total % Dif`

### 10.4. Bloco `O que o Cliente trara na negociacao`

O resumo final usa:

- `Total Mes`
- `Total Ano`
- `Tipo de Cliente`

### 10.5. Bloco `Invest Facil`

O resumo final usa:

- `repasse-mes`
- `repasse-ano`
- `incremento-mes`
- `incremento-ano`

### 10.6. Resultado consolidado: Visao do Cliente

Formula mensal:

- `Resultado Cliente Mes = Total Mensal Taxas + Diferenca Equipamentos Mes - Total Reducao Mes Consolidada`

Formula anual:

- `Resultado Cliente Ano = Total Anual Taxas + Diferenca Equipamentos Ano - Total Reducao Ano Consolidada`

Leitura:

- `Total Mensal Taxas` representa a diferenca entre concorrente e Cielo nas taxas;
- `Diferenca Equipamentos Mes` representa a diferenca entre concorrente e Cielo nos equipamentos;
- `Total Reducao Mes Consolidada` representa a economia do cliente nas secoes de servicos, por isso entra subtraindo.

### 10.7. Resultado consolidado: Visao do Banco

Formula mensal:

- `Resultado Banco Mes = Incremento Mes Invest Facil + Total Mes Negociacao`

Formula anual:

- `Resultado Banco Ano = Incremento Ano Invest Facil + Total Ano Negociacao`

### 10.8. Classificacao visual

Cada bloco recebe um status:

- `Positivo`
- `Negativo`
- `Neutro`

Regra:

- valor maior que zero = `Positivo`
- valor menor que zero = `Negativo`
- valor igual a zero = `Neutro`

Observacao importante:

- os cards do resumo final exibem o valor absoluto;
- o sinal real fica representado pelo status (`Positivo`, `Negativo` ou `Neutro`).

## 11. Outras observacoes uteis

- O botao `Calcular Resumo` recalcula praticamente toda a aplicacao antes de montar o bloco final.
- O botao `Exportar como Imagem PDF` apenas tira um "snapshot" visual das secoes e salva em PDF; ele nao muda os calculos.
- O botao `Limpar Tudo` recarrega a pagina inteira e apaga os dados preenchidos.

## 12. Resumo executivo das secoes de calculo

Se quiser ler de forma bem direta, a aplicacao hoje funciona assim:

1. `Comparativo de Taxas`: pega `Faturamento Mes`, aplica `Taxa Cielo` e `Taxa Conc`, calcula custo de cada uma e compara.
2. `Equipamentos`: multiplica `Quantidade` por `Custo Unitario` para Cielo e concorrente e compara o total mensal/anual.
3. `Pix na Maquininha`: soma volume e quantidade, calcula custo atual/proposto por `taxa` ou `tarifa`, aplica teto quando houver `Valor Maximo`, e mostra a reducao.
4. `Demais Servicos Pix`: repete a logica de taxa/tarifa para dois servicos Pix especificos.
5. `Produtos e Servicos Diversos`: multiplica quantidades pelos valores unitarios atual/proposto, calcula custo atual/proposto e a reducao por servico.
6. `Produtos e Servicos Consolidados`: junta os resultados de servicos diversos, Pix na maquininha e demais servicos Pix.
7. `O que o Cliente trara na negociacao`: calcula repasse estimado por produto novo, usando custo base, taxa, tarifa, valor maximo, tipo de cliente e RA quando aplicavel.
8. `Invest Facil`: transforma os volumes negociados em saldo mensal/anual e depois aplica os percentuais de projecao.
9. `Resumo Final`: junta tudo em duas visoes, `Cliente` e `Banco`.
