/* ============================================================================
   Calculadora de Pricing PJ — esquema do banco

   Rode uma vez, no phpMyAdmin (http://localhost/phpmyadmin) ou pelo terminal:
       mysql -u root < banco/01-esquema.sql

   Ordem dos arquivos:
       01-esquema.sql    as tabelas (este)
       02-produtos.sql   o catálogo de produtos e os fatores
       03-exemplo.sql    clientes fictícios, só para você ver a tela funcionando

   ---------------------------------------------------------------------------
   AS TRÊS TABELAS PRINCIPAIS, e por que existem as de apoio:

     encarteiramento   quem atende quem. Amarra o gerente aos clientes dele.
     fdados            o retrato do cliente hoje, por nível (conta, CNPJ ou
                       grupo econômico): faturamento, receita e projeção.
     dim_produto       o catálogo de produtos com o fator de cada um.

   As de apoio não são enfeite — cada uma resolve um problema que aparece no
   primeiro dia de uso:

     fdados_produto    a abertura de fdados por produto. A tela precisa saber
                       "o cliente já tem 8.000 boletos/mês", não só o total.
                       Fica separada porque a granularidade é outra: uma linha
                       por cliente E produto, e não uma por cliente.
     fator_historico   quem mudou qual fator, quando e de quanto para quanto.
                       Fator é preço. Preço sem rastro vira discussão.
     parametro         a régua do veredito, editável na tela de administração.
     simulacao         o que foi simulado, por quem e para qual cliente.
     simulacao_item    as linhas daquela simulação, congeladas com o fator que
                       valia NA HORA. Se a área mudar a tarifa amanhã, a
                       simulação de ontem continua contando a mesma história.
     app_admin         quem pode abrir a tela de administração.

   ---------------------------------------------------------------------------
   MariaDB 10.1 (o que vem no XAMPP). Sem JSON nativo, sem colunas geradas,
   sem CHECK — tudo aqui é SQL conservador de propósito, para rodar igual na
   sua máquina e no servidor do trabalho.

   Nomes de coluna sem acento, sempre. Acento em identificador de banco
   funciona até o dia em que a carga vem de um cliente com outra codificação.
   ========================================================================== */

CREATE DATABASE IF NOT EXISTS calculadora_pricing
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE calculadora_pricing;


/* ===========================================================================
   encarteiramento — quem atende quem

   Uma linha por CONTA. O mesmo CNPJ costuma ter várias contas, e o mesmo
   grupo econômico vários CNPJs — por isso a linha nasce na conta, que é o
   nível mais fino. Subir para CNPJ ou grupo é só agrupar.

   A carteira do usuário sai daqui: entra o e-mail (ou a funcional) de quem
   abriu a página, saem os clientes dele. Nenhuma tela mostra cliente de
   outro gerente sem isso bater.
   ========================================================================= */
DROP TABLE IF EXISTS encarteiramento;
CREATE TABLE encarteiramento (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,

  /* --- o cliente ------------------------------------------------------- */
  cnpj              VARCHAR(14)  NOT NULL COMMENT 'So digitos, 14 posicoes, com zeros a esquerda',
  razao_social      VARCHAR(180) NOT NULL,
  nome_fantasia     VARCHAR(180)     NULL,

  /* --- a conta --------------------------------------------------------- */
  agencia           VARCHAR(6)       NULL,
  conta             VARCHAR(14)      NULL COMMENT 'So digitos, DV incluido no fim',
  conta_exibicao    VARCHAR(24)      NULL COMMENT 'Como o gerente le: 1234 / 0012345-6',

  /* --- o grupo economico ----------------------------------------------- */
  grupo_numero      VARCHAR(20)      NULL,
  grupo_nome        VARCHAR(180)     NULL,

  /* --- quem atende ------------------------------------------------------
     O e-mail é a chave de verdade: é o que o Power App / Automate entrega
     com certeza. A funcional entra junto porque nem todo extrato de carteira
     traz e-mail, e aí ela salva o dia.                                     */
  gerente_email     VARCHAR(160)     NULL,
  gerente_funcional VARCHAR(20)      NULL,
  gerente_nome      VARCHAR(160)     NULL,

  /* --- onde o cliente se encaixa --------------------------------------- */
  segmento          VARCHAR(60)      NULL COMMENT 'Ex.: Corporate, Empresas, Varejo PJ',
  porte             VARCHAR(40)      NULL,
  regional          VARCHAR(80)      NULL,
  juncao            VARCHAR(20)      NULL,

  ativo             TINYINT(1)   NOT NULL DEFAULT 1,
  carga_em          DATETIME         NULL COMMENT 'Quando esta linha entrou na ultima carga',

  PRIMARY KEY (id),
  KEY ix_enc_cnpj     (cnpj),
  KEY ix_enc_conta    (conta),
  KEY ix_enc_grupo    (grupo_numero),
  KEY ix_enc_email    (gerente_email),
  KEY ix_enc_func     (gerente_funcional),
  KEY ix_enc_razao    (razao_social)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   dim_produto — o catálogo, e o que cada fator significa

   Aqui mora a decisão que faz a calculadora inteira funcionar: um produto não
   cobra sempre do mesmo jeito.

     Emissão de Cobrança  cobra POR BOLETO      -> volume é QUANTIDADE,
                                                   fator é TARIFA em R$
     Invest Fácil         cobra SOBRE O SALDO   -> volume é VALOR em R$,
                                                   fator é TAXA em %

   Por isso cada produto declara os dois tipos, e o motor de cálculo só
   pergunta ao produto como ele cobra. Produto novo entra como linha, não
   como alteração de código.

   ---------------------------------------------------------------------------
   ATENÇÃO AO FORMATO DO FATOR — é o erro mais fácil de cometer aqui:

     tipo_fator = TARIFA     o fator está em REAIS por unidade.
                             2.45000000  = R$ 2,45 por boleto

     tipo_fator = TAXA       o fator está em PONTOS PERCENTUAIS, já na
                             escala que a área fala.
                             0.35000000  = 0,35%   (e NÃO 35%)
                             O motor divide por 100 na hora de calcular.

   A tela de administração mostra o sufixo certo (R$ ou %) ao lado do campo,
   justamente para ninguém digitar 35 quando queria dizer 0,35.
   ========================================================================= */
DROP TABLE IF EXISTS dim_produto;
CREATE TABLE dim_produto (
  codigo          VARCHAR(40)  NOT NULL COMMENT 'Slug estavel. Nunca mude depois de usado em simulacao',
  nome            VARCHAR(120) NOT NULL COMMENT 'O nome que o gerente le na tela',
  grupo           VARCHAR(60)  NOT NULL DEFAULT 'Outros' COMMENT 'Agrupador visual da tabela',
  ordem           SMALLINT     NOT NULL DEFAULT 999,

  /* --- como o produto cobra -------------------------------------------- */
  tipo_volume     ENUM('QUANTIDADE','VALOR','CONTEXTO') NOT NULL DEFAULT 'VALOR',
  tipo_fator      ENUM('TARIFA','TAXA','NENHUM')        NOT NULL DEFAULT 'TAXA',
  periodicidade   ENUM('MENSAL','ANUAL')                NOT NULL DEFAULT 'MENSAL',

  /* CONTEXTO + NENHUM é a dupla para o que NÃO gera receita mas importa na
     conversa — o prazo contratual da Cielo, por exemplo. Entra na tela, sai
     no relatório, e fica de fora de toda soma.                             */

  unidade         VARCHAR(40)      NULL COMMENT 'Ex.: boletos/mes, funcionarios, meses',
  ajuda           VARCHAR(255)     NULL COMMENT 'Aparece no balao de ajuda do produto',

  /* --- o preço ---------------------------------------------------------- */
  fator           DECIMAL(18,8) NOT NULL DEFAULT 0 COMMENT 'R$ se TARIFA, pontos percentuais se TAXA',
  fator_piso      DECIMAL(18,8)     NULL COMMENT 'Minimo que o gerente pode negociar. NULL = sem piso',
  fator_teto      DECIMAL(18,8)     NULL COMMENT 'Maximo. NULL = sem teto',

  ativo           TINYINT(1)   NOT NULL DEFAULT 1,
  atualizado_em   DATETIME         NULL,
  atualizado_por  VARCHAR(160)     NULL,

  PRIMARY KEY (codigo),
  KEY ix_prod_ativo (ativo, ordem)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   fdados — o retrato do cliente hoje

   Uma linha por (chave, nível). O mesmo cliente pode aparecer três vezes:
   uma pela conta, uma pelo CNPJ e uma pelo grupo econômico. Não é duplicata,
   são três recortes do mesmo cliente — e a tela deixa o gerente escolher em
   qual deles quer negociar.

   A CHAVE guarda só dígitos, sempre. CNPJ com ponto, conta com traço e grupo
   com prefixo são formas de ESCREVER a mesma coisa; se o banco guardar a
   forma escrita, a busca falha no primeiro cliente que alguém digitou
   diferente. A tela normaliza antes de procurar.
   ========================================================================= */
DROP TABLE IF EXISTS fdados;
CREATE TABLE fdados (
  id                      INT UNSIGNED NOT NULL AUTO_INCREMENT,

  chave                   VARCHAR(24) NOT NULL COMMENT 'So digitos: CNPJ, conta ou numero do grupo',
  nivel                   ENUM('CONTA','CNPJ','GRUPO') NOT NULL,

  /* Repetido aqui de propósito: o gerente precisa ver o nome do cliente
     mesmo quando a busca entrou por um número de grupo que não está no
     encarteiramento dele.                                                  */
  razao_social            VARCHAR(180)     NULL,

  /* --- o que o banco sabe do cliente ------------------------------------ */
  faturamento_mensal_medio  DECIMAL(18,2) NOT NULL DEFAULT 0,
  receita_mensal_atual      DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'Soma da receita de todos os produtos hoje',
  receita_projetada_ano     DECIMAL(18,2) NOT NULL DEFAULT 0,

  segmento                VARCHAR(60)      NULL,
  porte                   VARCHAR(40)      NULL,
  data_relacionamento     DATE             NULL COMMENT 'Desde quando e cliente. Vazio = prospect',

  referencia              CHAR(7)          NULL COMMENT 'Mes-base dos numeros, AAAA-MM',
  carga_em                DATETIME         NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uq_fdados (chave, nivel),
  KEY ix_fdados_razao (razao_social)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   fdados_produto — a abertura de fdados, produto a produto

   Formato longo: uma linha por cliente E produto. É o formato que a planilha
   da área já usa por dentro, e o único que aguenta produto novo sem mexer no
   banco — produto novo é uma linha a mais, nunca uma coluna a mais.

   receita_atual vem do banco em vez de ser calculada de volta a partir do
   volume, e isso é proposital: a receita que o cliente paga hoje pode ter
   desconto, acordo antigo ou condição especial que o fator padrão da tabela
   não reproduz. A tela avisa quando os dois não batem, mas quem manda no
   "hoje" é o número que veio do banco.
   ========================================================================= */
DROP TABLE IF EXISTS fdados_produto;
CREATE TABLE fdados_produto (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,

  chave           VARCHAR(24) NOT NULL,
  nivel           ENUM('CONTA','CNPJ','GRUPO') NOT NULL,
  produto_codigo  VARCHAR(40) NOT NULL,

  volume_atual    DECIMAL(18,4) NOT NULL DEFAULT 0 COMMENT 'Quantidade ou R$, conforme tipo_volume do produto',
  receita_atual   DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'O que esse produto rende hoje, em R$/mes',

  referencia      CHAR(7)          NULL,
  carga_em        DATETIME         NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uq_fdprod (chave, nivel, produto_codigo),
  KEY ix_fdprod_produto (produto_codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   fator_historico — o rastro de quem mexeu no preço

   Gravado pela própria tela de administração, a cada alteração. Nunca é
   apagado. Quando alguém perguntar "por que essa simulação de março usou
   2,10 se hoje é 2,45?", a resposta está aqui.
   ========================================================================= */
DROP TABLE IF EXISTS fator_historico;
CREATE TABLE fator_historico (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  produto_codigo  VARCHAR(40)  NOT NULL,
  campo           VARCHAR(40)  NOT NULL DEFAULT 'fator' COMMENT 'fator, fator_piso, fator_teto, ativo...',
  valor_antes     VARCHAR(60)      NULL,
  valor_depois    VARCHAR(60)      NULL,
  motivo          VARCHAR(255)     NULL,
  usuario_nome    VARCHAR(160)     NULL,
  usuario_email   VARCHAR(160)     NULL,
  criado_em       DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_hist_produto (produto_codigo, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   parametro — a régua do veredito, e o resto do que a área regula

   Tabela chave-valor de propósito: parâmetro novo não pede coluna nova. O
   valor viaja como texto e o PHP converte, porque aqui cabe número, texto e
   sim/não no mesmo lugar.
   ========================================================================= */
DROP TABLE IF EXISTS parametro;
CREATE TABLE parametro (
  chave           VARCHAR(60)  NOT NULL,
  valor           VARCHAR(255) NOT NULL,
  rotulo          VARCHAR(160)     NULL COMMENT 'Como aparece na tela de administracao',
  ajuda           VARCHAR(255)     NULL,
  tipo            ENUM('NUMERO','PERCENTUAL','DINHEIRO','TEXTO','BOOLEANO') NOT NULL DEFAULT 'NUMERO',
  grupo           VARCHAR(60)  NOT NULL DEFAULT 'Geral',
  ordem           SMALLINT     NOT NULL DEFAULT 999,
  atualizado_em   DATETIME         NULL,
  atualizado_por  VARCHAR(160)     NULL,
  PRIMARY KEY (chave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   simulacao / simulacao_item — o histórico

   O item guarda o fator usado NAQUELE momento. Não é redundância: é o que
   impede a simulação de ontem de mudar de resultado porque a área reajustou
   a tarifa hoje de manhã.
   ========================================================================= */
DROP TABLE IF EXISTS simulacao_item;
DROP TABLE IF EXISTS simulacao;

CREATE TABLE simulacao (
  id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  protocolo             VARCHAR(20)  NOT NULL COMMENT 'Codigo curto para o gerente citar no e-mail',

  /* --- quem simulou ----------------------------------------------------- */
  usuario_nome          VARCHAR(160)     NULL,
  usuario_email         VARCHAR(160)     NULL,
  usuario_funcional     VARCHAR(20)      NULL,

  /* --- para quem -------------------------------------------------------- */
  chave                 VARCHAR(24)  NOT NULL,
  nivel                 ENUM('CONTA','CNPJ','GRUPO') NOT NULL,
  razao_social          VARCHAR(180)     NULL,
  cliente_novo          TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '1 = nao havia nada em fdados',

  /* --- o resultado, congelado ------------------------------------------- */
  receita_atual_mes     DECIMAL(18,2) NOT NULL DEFAULT 0,
  receita_projetada_mes DECIMAL(18,2) NOT NULL DEFAULT 0,
  incremento_mes        DECIMAL(18,2) NOT NULL DEFAULT 0,
  variacao_pct          DECIMAL(12,4) NOT NULL DEFAULT 0,
  receita_ano           DECIMAL(18,2) NOT NULL DEFAULT 0,
  veredito              ENUM('APROVADO','ATENCAO','REPROVADO') NOT NULL DEFAULT 'ATENCAO',
  veredito_texto        VARCHAR(255)     NULL,

  observacao            TEXT             NULL,
  criado_em             DATETIME     NOT NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uq_sim_protocolo (protocolo),
  KEY ix_sim_usuario (usuario_email, criado_em),
  KEY ix_sim_cliente (chave, nivel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE simulacao_item (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  simulacao_id       INT UNSIGNED NOT NULL,
  produto_codigo     VARCHAR(40)  NOT NULL,
  produto_nome       VARCHAR(120)     NULL COMMENT 'Congelado: o nome pode mudar no catalogo',

  volume_atual       DECIMAL(18,4) NOT NULL DEFAULT 0,
  receita_atual      DECIMAL(18,2) NOT NULL DEFAULT 0,
  incremento_volume  DECIMAL(18,4) NOT NULL DEFAULT 0 COMMENT 'O que o gerente digitou',
  fator_usado        DECIMAL(18,8) NOT NULL DEFAULT 0,
  fator_negociado    TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '1 = gerente alterou o fator padrao',
  receita_incremento DECIMAL(18,2) NOT NULL DEFAULT 0,
  receita_projetada  DECIMAL(18,2) NOT NULL DEFAULT 0,

  PRIMARY KEY (id),
  KEY ix_item_sim (simulacao_id),
  CONSTRAINT fk_item_sim FOREIGN KEY (simulacao_id)
      REFERENCES simulacao (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   app_admin — quem abre a tela de administração

   Deliberadamente simples: uma lista de e-mails. Quem autentica é o Power
   App / Automate; esta tabela só responde "este e-mail pode mexer nos
   fatores?". Sem senha, porque senha aqui seria uma segunda porta para
   guardar e nenhuma segurança a mais.
   ========================================================================= */
DROP TABLE IF EXISTS app_admin;
CREATE TABLE app_admin (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  email         VARCHAR(160) NOT NULL,
  nome          VARCHAR(160)     NULL,
  funcional     VARCHAR(20)      NULL,
  ativo         TINYINT(1)   NOT NULL DEFAULT 1,
  criado_em     DATETIME         NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
