/* ============================================================================
   Calculadora de Pricing PJ — dados fictícios para desenvolvimento

   NADA AQUI É REAL. São cinco empresas inventadas, com números redondos e
   fáceis de conferir de cabeça, montadas para exercitar os quatro cenários
   que a calculadora precisa acertar:

     1. TRANSPORTADORA ROTA NORTE   cliente grande, já rende bem.
                                    Serve para ver o veredito ficar exigente:
                                    crescer 15% sobre R$ 47 mil é muita coisa.

     2. METALÚRGICA SÃO BENTO       cliente médio com pouca receita hoje.
                                    Qualquer incremento decente aprova.

     3. DISTRIBUIDORA VALE VERDE    tem dados nos TRÊS níveis (conta, CNPJ e
                                    grupo). Serve para testar a escolha de
                                    nível na busca.

     4. CLÍNICA BOM PASTOR          cliente do banco, mas sem produto nenhum
                                    contratado. Receita atual zero mesmo
                                    sendo cliente — cai na régua de prospect.

     5. (não cadastrado)            qualquer CNPJ que você digitar e não
                                    existir aqui cai no caminho de PROSPECT:
                                    a tela abre vazia e deixa simular do zero.

   Para carregar:
       mysql -u root < banco/03-exemplo.sql

   No trabalho, este arquivo não roda. Lá as três tabelas vêm da carga real.
   ========================================================================== */

USE calculadora_pricing;

DELETE FROM fdados_produto;
DELETE FROM fdados;
DELETE FROM encarteiramento;
DELETE FROM app_admin;


/* ===========================================================================
   Os gerentes fictícios

   Troque estes e-mails pelo SEU e-mail para a carteira aparecer quando você
   abrir a página em modo mock. O e-mail do mock está em mock/perfil.json.
   ========================================================================= */

INSERT INTO encarteiramento
  (cnpj, razao_social, nome_fantasia, agencia, conta, conta_exibicao,
   grupo_numero, grupo_nome, gerente_email, gerente_funcional, gerente_nome,
   segmento, porte, regional, juncao, ativo, carga_em)
VALUES

/* --- 1. Transportadora Rota Norte: uma conta, cliente relevante --------- */
('11222333000181', 'TRANSPORTADORA ROTA NORTE LTDA', 'Rota Norte',
 '1234', '00123456', '1234 / 0012345-6',
 '4471', 'GRUPO ROTA NORTE',
 'luantbastos@gmail.com', '9437643', 'Luan Bastos',
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 2. Metalúrgica São Bento: cliente médio, pouca receita ------------- */
('22333444000172', 'METALURGICA SAO BENTO S/A', 'São Bento Metais',
 '1234', '00234567', '1234 / 0023456-7',
 '5580', 'GRUPO SAO BENTO',
 'luantbastos@gmail.com', '9437643', 'Luan Bastos',
 'Empresas', 'Média', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 3. Distribuidora Vale Verde: duas contas, mesmo CNPJ ---------------
   Duas linhas, um CNPJ. É o caso que obriga a tabela a nascer na conta.  */
('33444555000163', 'DISTRIBUIDORA VALE VERDE LTDA', 'Vale Verde',
 '1234', '00345678', '1234 / 0034567-8',
 '6692', 'GRUPO VALE VERDE',
 'luantbastos@gmail.com', '9437643', 'Luan Bastos',
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

('33444555000163', 'DISTRIBUIDORA VALE VERDE LTDA', 'Vale Verde — filial',
 '4321', '00456789', '4321 / 0045678-9',
 '6692', 'GRUPO VALE VERDE',
 'luantbastos@gmail.com', '9437643', 'Luan Bastos',
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 3b. Outro CNPJ do MESMO grupo econômico ---------------------------
   Serve para o nível GRUPO ter o que somar.                             */
('33444555000244', 'VALE VERDE LOGISTICA LTDA', 'Vale Verde Log',
 '4321', '00567890', '4321 / 0056789-0',
 '6692', 'GRUPO VALE VERDE',
 'luantbastos@gmail.com', '9437643', 'Luan Bastos',
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 4. Clínica Bom Pastor: cliente sem produto contratado ------------- */
('44555666000154', 'CLINICA BOM PASTOR LTDA', 'Bom Pastor',
 '1234', '00678901', '1234 / 0067890-1',
 '7703', 'CLINICA BOM PASTOR',
 'luantbastos@gmail.com', '9437643', 'Luan Bastos',
 'Empresas', 'Pequena', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 5. Cliente de OUTRO gerente ---------------------------------------
   Existe na base, mas não na sua carteira. Serve para conferir que a
   tela não entrega cliente alheio.                                      */
('55666777000145', 'INDUSTRIA PAULISTA DE PAPEL LTDA', 'IPP',
 '9876', '00789012', '9876 / 0078901-2',
 '8814', 'GRUPO IPP',
 'outro.gerente@exemplo.com', '9111222', 'Outro Gerente',
 'Corporate', 'Grande', 'Campinas', '9876', 1, NOW());


/* ===========================================================================
   fdados — o retrato de cada cliente

   Os números de receita_mensal_atual batem com a soma de fdados_produto mais
   abaixo. Se você mexer num, mexa no outro: a tela compara os dois e avisa
   quando divergem.
   ========================================================================= */

INSERT INTO fdados
  (chave, nivel, razao_social, faturamento_mensal_medio, receita_mensal_atual,
   receita_projetada_ano, segmento, porte, data_relacionamento, referencia, carga_em)
VALUES

/* --- 1. Rota Norte: R$ 47.190 de receita mensal ------------------------- */
('00123456', 'CONTA', 'TRANSPORTADORA ROTA NORTE LTDA',
 8500000.00, 47190.00, 566280.00, 'Corporate', 'Grande', '2015-03-10', '2026-08', NOW()),
('11222333000181', 'CNPJ', 'TRANSPORTADORA ROTA NORTE LTDA',
 8500000.00, 47190.00, 566280.00, 'Corporate', 'Grande', '2015-03-10', '2026-08', NOW()),

/* --- 2. São Bento: R$ 3.640 de receita mensal --------------------------- */
('00234567', 'CONTA', 'METALURGICA SAO BENTO S/A',
 1200000.00, 3640.00, 43680.00, 'Empresas', 'Média', '2021-07-01', '2026-08', NOW()),
('22333444000172', 'CNPJ', 'METALURGICA SAO BENTO S/A',
 1200000.00, 3640.00, 43680.00, 'Empresas', 'Média', '2021-07-01', '2026-08', NOW()),

/* --- 3. Vale Verde: os três níveis -------------------------------------
   Matriz R$ 12.800 + filial R$ 5.200 = CNPJ R$ 18.000
   CNPJ R$ 18.000 + logística R$ 6.500 = GRUPO R$ 24.500                  */
('00345678', 'CONTA', 'DISTRIBUIDORA VALE VERDE LTDA',
 4200000.00, 12800.00, 153600.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),
('00456789', 'CONTA', 'DISTRIBUIDORA VALE VERDE LTDA',
 1600000.00, 5200.00, 62400.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),
('33444555000163', 'CNPJ', 'DISTRIBUIDORA VALE VERDE LTDA',
 5800000.00, 18000.00, 216000.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),
('00567890', 'CONTA', 'VALE VERDE LOGISTICA LTDA',
 2100000.00, 6500.00, 78000.00, 'Corporate', 'Grande', '2019-11-04', '2026-08', NOW()),
('33444555000244', 'CNPJ', 'VALE VERDE LOGISTICA LTDA',
 2100000.00, 6500.00, 78000.00, 'Corporate', 'Grande', '2019-11-04', '2026-08', NOW()),
('6692', 'GRUPO', 'GRUPO VALE VERDE',
 7900000.00, 24500.00, 294000.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),

/* --- 4. Bom Pastor: é cliente, mas não tem produto nenhum --------------- */
('00678901', 'CONTA', 'CLINICA BOM PASTOR LTDA',
 380000.00, 0.00, 0.00, 'Empresas', 'Pequena', '2024-02-19', '2026-08', NOW()),
('44555666000154', 'CNPJ', 'CLINICA BOM PASTOR LTDA',
 380000.00, 0.00, 0.00, 'Empresas', 'Pequena', '2024-02-19', '2026-08', NOW());


/* ===========================================================================
   fdados_produto — a abertura por produto

   Confira as contas: volume x fator tem que dar a receita. Os números foram
   escolhidos para fechar redondo, para você conseguir auditar a tela olhando.

   Rota Norte, por exemplo:
     Invest Fácil    R$ 6.000.000 x 0,35%  = R$ 21.000
     Cobrança qtde         8.000 x R$ 2,45 = R$ 19.600
     Fopag qtde              420 x R$ 3,90 = R$  1.638
     Contas a pagar  R$ 4.500.000 x 0,06%  = R$  2.700
     Pix             R$ 8.000.000 x 0,02%  = R$  1.600
     Alelo              R$ 25.000 x 0,90%  = R$    225
     Ad valorem        R$ 210.000 x 1,20%  = R$  2.520
                                             ----------
                                             R$ 49.283

   Está de propósito diferente dos R$ 47.190 de fdados: é o caso real de
   receita negociada abaixo da tabela. A tela sinaliza a divergência em vez
   de esconder, porque essa diferença costuma ser o assunto da reunião.
   ========================================================================= */

INSERT INTO fdados_produto
  (chave, nivel, produto_codigo, volume_atual, receita_atual, referencia, carga_em)
VALUES

/* --- 1. Rota Norte (conta e CNPJ, mesmos números) ----------------------- */
('00123456', 'CONTA', 'invest_facil',   6000000.0000, 21000.00, '2026-08', NOW()),
('00123456', 'CONTA', 'cobranca_qtde',     8000.0000, 18400.00, '2026-08', NOW()),
('00123456', 'CONTA', 'fopag_qtde',         420.0000,  1638.00, '2026-08', NOW()),
('00123456', 'CONTA', 'contas_pagar',  4500000.0000,  2700.00, '2026-08', NOW()),
('00123456', 'CONTA', 'pix',           8000000.0000,  1600.00, '2026-08', NOW()),
('00123456', 'CONTA', 'alelo',           25000.0000,   225.00, '2026-08', NOW()),
('00123456', 'CONTA', 'ad_valorem',     210000.0000,  1627.00, '2026-08', NOW()),

('11222333000181', 'CNPJ', 'invest_facil',   6000000.0000, 21000.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'cobranca_qtde',     8000.0000, 18400.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'fopag_qtde',         420.0000,  1638.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'contas_pagar',  4500000.0000,  2700.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'pix',           8000000.0000,  1600.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'alelo',           25000.0000,   225.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'ad_valorem',     210000.0000,  1627.00, '2026-08', NOW()),

/* --- 2. São Bento: pouca coisa contratada ------------------------------ */
('00234567', 'CONTA', 'cobranca_qtde',   1200.0000, 2940.00, '2026-08', NOW()),
('00234567', 'CONTA', 'fopag_qtde',        80.0000,  312.00, '2026-08', NOW()),
('00234567', 'CONTA', 'pix',         1940000.0000,  388.00, '2026-08', NOW()),

('22333444000172', 'CNPJ', 'cobranca_qtde',   1200.0000, 2940.00, '2026-08', NOW()),
('22333444000172', 'CNPJ', 'fopag_qtde',        80.0000,  312.00, '2026-08', NOW()),
('22333444000172', 'CNPJ', 'pix',         1940000.0000,  388.00, '2026-08', NOW()),

/* --- 3. Vale Verde: matriz -------------------------------------------- */
('00345678', 'CONTA', 'invest_facil',  2000000.0000, 7000.00, '2026-08', NOW()),
('00345678', 'CONTA', 'cobranca_qtde',    1800.0000, 4410.00, '2026-08', NOW()),
('00345678', 'CONTA', 'contas_receber', 1500000.0000,  900.00, '2026-08', NOW()),
('00345678', 'CONTA', 'pix',           2450000.0000,  490.00, '2026-08', NOW()),

/* --- 3. Vale Verde: filial -------------------------------------------- */
('00456789', 'CONTA', 'cobranca_qtde',    1400.0000, 3430.00, '2026-08', NOW()),
('00456789', 'CONTA', 'fopag_qtde',        300.0000, 1170.00, '2026-08', NOW()),
('00456789', 'CONTA', 'pix',           3000000.0000,  600.00, '2026-08', NOW()),

/* --- 3. Vale Verde: consolidado no CNPJ da matriz --------------------- */
('33444555000163', 'CNPJ', 'invest_facil',  2000000.0000,  7000.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'cobranca_qtde',    3200.0000,  7840.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'fopag_qtde',        300.0000,  1170.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'contas_receber', 1500000.0000,   900.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'pix',           5450000.0000,  1090.00, '2026-08', NOW()),

/* --- 3. Vale Verde Logística ------------------------------------------ */
('00567890', 'CONTA', 'invest_facil',  1000000.0000, 3500.00, '2026-08', NOW()),
('00567890', 'CONTA', 'contas_pagar',  3000000.0000, 1800.00, '2026-08', NOW()),
('00567890', 'CONTA', 'ad_valorem',      100000.0000, 1200.00, '2026-08', NOW()),

('33444555000244', 'CNPJ', 'invest_facil',  1000000.0000, 3500.00, '2026-08', NOW()),
('33444555000244', 'CNPJ', 'contas_pagar',  3000000.0000, 1800.00, '2026-08', NOW()),
('33444555000244', 'CNPJ', 'ad_valorem',      100000.0000, 1200.00, '2026-08', NOW()),

/* --- 3. Vale Verde: o grupo econômico inteiro ------------------------- */
('6692', 'GRUPO', 'invest_facil',  3000000.0000, 10500.00, '2026-08', NOW()),
('6692', 'GRUPO', 'cobranca_qtde',    3200.0000,  7840.00, '2026-08', NOW()),
('6692', 'GRUPO', 'fopag_qtde',        300.0000,  1170.00, '2026-08', NOW()),
('6692', 'GRUPO', 'contas_pagar',  3000000.0000,  1800.00, '2026-08', NOW()),
('6692', 'GRUPO', 'contas_receber', 1500000.0000,   900.00, '2026-08', NOW()),
('6692', 'GRUPO', 'pix',           5450000.0000,  1090.00, '2026-08', NOW()),
('6692', 'GRUPO', 'ad_valorem',     100000.0000,  1200.00, '2026-08', NOW());

/* Bom Pastor não entra aqui de propósito: é cliente do banco, tem cadastro
   em fdados, e não tem uma linha de produto sequer. A tela precisa abrir
   sem quebrar e tratar como receita zero. */


/* ===========================================================================
   Quem administra

   Coloque o SEU e-mail aqui para a tela de administração abrir no mock.
   ========================================================================= */
INSERT INTO app_admin (email, nome, funcional, ativo, criado_em) VALUES
('luantbastos@gmail.com', 'Luan Bastos', '9437643', 1, NOW());
