/* ============================================================================
   Calculadora de Pricing PJ — catálogo de produtos e régua do veredito

   Os produtos são exatamente as linhas da planilha da área, na mesma ordem e
   com os mesmos nomes. Isso é intencional: o gerente que já usa a planilha
   precisa reconhecer a tela sem ninguém explicar.

   ---------------------------------------------------------------------------
   OS FATORES ABAIXO SÃO PROVISÓRIOS.

   Coloquei valores plausíveis só para a tela nascer funcionando. Quando a
   área responsável passar a tabela oficial, ninguém precisa mexer neste
   arquivo: é só abrir a tela de administração e digitar. Este arquivo existe
   para o primeiro dia; depois dele, quem manda é a tela.
   ---------------------------------------------------------------------------

   Lembrete do formato, porque é onde se erra:
       TARIFA  -> reais por unidade.        2.45 = R$ 2,45 por boleto
       TAXA    -> pontos percentuais.       0.35 = 0,35%  (não 35%)
   ========================================================================== */

USE calculadora_pricing;

DELETE FROM dim_produto;

INSERT INTO dim_produto
  (codigo, nome, grupo, ordem, tipo_volume, tipo_fator, periodicidade, unidade, ajuda,
   fator, fator_piso, fator_teto, ativo, atualizado_em, atualizado_por)
VALUES

/* --- Investimentos ------------------------------------------------------ */
('invest_facil', 'Invest Fácil (Saldo)', 'Investimentos', 10,
 'VALOR', 'TAXA', 'MENSAL', 'R$ de saldo médio',
 'Saldo médio aplicado no mês. O fator é o spread mensal que o banco captura sobre esse saldo.',
 0.35000000, 0.15000000, 0.60000000, 1, NOW(), 'carga inicial'),

/* --- Cobrança -----------------------------------------------------------
   Duas linhas porque são duas cobranças diferentes sobre o mesmo produto:
   a tarifa por boleto emitido, e o percentual sobre o valor financeiro.   */
('cobranca_qtde', 'Emissão de Cobrança — Qtde/mês', 'Cobrança', 20,
 'QUANTIDADE', 'TARIFA', 'MENSAL', 'boletos/mês',
 'Quantidade de boletos emitidos por mês. O fator é a tarifa unitária por boleto.',
 2.45000000, 1.20000000, 4.50000000, 1, NOW(), 'carga inicial'),

('cobranca_valor', 'Emissão de Cobrança — R$', 'Cobrança', 30,
 'VALOR', 'TAXA', 'MENSAL', 'R$ liquidados/mês',
 'Valor financeiro liquidado via cobrança no mês.',
 0.08000000, 0.02000000, 0.20000000, 1, NOW(), 'carga inicial'),

/* --- Folha de pagamento ------------------------------------------------- */
('fopag_qtde', 'Fopag — Qtde de funcionários/mês', 'Folha de pagamento', 40,
 'QUANTIDADE', 'TARIFA', 'MENSAL', 'funcionários',
 'Funcionários processados na folha. O fator é a tarifa por crédito de salário.',
 3.90000000, 1.50000000, 7.00000000, 1, NOW(), 'carga inicial'),

('fopag_valor', 'Fopag — R$/mês', 'Folha de pagamento', 50,
 'VALOR', 'TAXA', 'MENSAL', 'R$ de folha/mês',
 'Volume financeiro da folha. Conta pelo saldo médio que circula na conta.',
 0.05000000, 0.01000000, 0.15000000, 1, NOW(), 'carga inicial'),

/* --- Pagamentos e recebimentos ------------------------------------------ */
('contas_pagar', 'Contas a Pagar — R$/mês', 'Pagamentos e recebimentos', 60,
 'VALOR', 'TAXA', 'MENSAL', 'R$ pagos/mês',
 'Volume mensal de pagamentos a fornecedores processados pelo banco.',
 0.06000000, 0.01000000, 0.18000000, 1, NOW(), 'carga inicial'),

('contas_receber', 'Contas a Receber — R$/mês', 'Pagamentos e recebimentos', 70,
 'VALOR', 'TAXA', 'MENSAL', 'R$ recebidos/mês',
 'Volume mensal de recebimentos processados pelo banco.',
 0.06000000, 0.01000000, 0.18000000, 1, NOW(), 'carga inicial'),

('pix', 'Pix — total média/mês', 'Pagamentos e recebimentos', 80,
 'VALOR', 'TAXA', 'MENSAL', 'R$ transacionados/mês',
 'Média mensal transacionada em Pix, entrada e saída.',
 0.02000000, 0.00000000, 0.10000000, 1, NOW(), 'carga inicial'),

/* --- Benefícios ---------------------------------------------------------- */
('alelo', 'Alelo — mês', 'Benefícios', 90,
 'VALOR', 'TAXA', 'MENSAL', 'R$ em benefícios/mês',
 'Valor mensal carregado em cartões de benefício.',
 0.90000000, 0.30000000, 2.00000000, 1, NOW(), 'carga inicial'),

/* --- Adquirência ---------------------------------------------------------
   TPV é ANUAL na planilha da área — o volume digitado já é o do ano inteiro.
   O motor sabe disso e não multiplica por 12 de novo na projeção do ano.   */
('tpv_ano', 'TPV esperado — ano', 'Adquirência', 100,
 'VALOR', 'TAXA', 'ANUAL', 'R$ de TPV no ano',
 'Volume total transacionado em cartão previsto para os 12 meses. O fator é a taxa média de desconto (MDR).',
 0.89000000, 0.45000000, 2.50000000, 1, NOW(), 'carga inicial'),

('ad_valorem', 'Ad Valorem — mês', 'Adquirência', 110,
 'VALOR', 'TAXA', 'MENSAL', 'R$ antecipados/mês',
 'Base mensal sujeita a ad valorem. O fator é o percentual cobrado sobre ela.',
 1.20000000, 0.50000000, 3.00000000, 1, NOW(), 'carga inicial'),

/* CONTEXTO: entra na tela, aparece no resumo, e fica fora de toda soma.
   Prazo não é receita — é o que sustenta (ou derruba) a receita projetada. */
('prazo_cielo', 'Prazo contratual Cielo', 'Adquirência', 120,
 'CONTEXTO', 'NENHUM', 'MENSAL', 'meses',
 'Prazo do contrato de adquirência, em meses. Não gera receita direta: entra como contexto da negociação.',
 0.00000000, NULL, NULL, 1, NOW(), 'carga inicial'),

/* --- Livres --------------------------------------------------------------
   As duas linhas "Outros" da planilha. Nascem desligadas: quem precisar
   liga na tela de administração, dá um nome de verdade e define o fator.  */
('outros_1', 'Outros 1', 'Outros', 900,
 'VALOR', 'TAXA', 'MENSAL', 'R$/mês',
 'Linha livre. Renomeie na tela de administração conforme a necessidade.',
 0.00000000, NULL, NULL, 0, NOW(), 'carga inicial'),

('outros_2', 'Outros 2', 'Outros', 910,
 'VALOR', 'TAXA', 'MENSAL', 'R$/mês',
 'Linha livre. Renomeie na tela de administração conforme a necessidade.',
 0.00000000, NULL, NULL, 0, NOW(), 'carga inicial');


/* ===========================================================================
   A RÉGUA DO VEREDITO

   A conta é sempre a mesma: quanto a receita projetada cresce sobre a receita
   que o cliente já dá hoje.

       variação = (receita projetada - receita atual) / receita atual x 100

   E aí ela cai numa das três faixas abaixo.

   O caso do PROSPECT é diferente e precisa de régua própria: quem não é
   cliente tem receita atual zero, e dividir por zero não dá veredito nenhum.
   Para esses, o que vale é o valor absoluto — a receita projetada precisa
   passar do piso. Os dois pisos abaixo cuidam disso.
   ========================================================================= */

DELETE FROM parametro;

INSERT INTO parametro (chave, valor, rotulo, ajuda, tipo, grupo, ordem, atualizado_em, atualizado_por) VALUES

('veredito_pct_aprovado', '15',
 'Incremento para aprovar',
 'A partir deste crescimento sobre a receita atual, a negociação sai como "vale a pena".',
 'PERCENTUAL', 'Régua do veredito', 10, NOW(), 'carga inicial'),

('veredito_pct_atencao', '5',
 'Incremento mínimo aceitável',
 'Abaixo deste crescimento a negociação sai como "não compensa". Entre este e o de cima, sai como "atenção".',
 'PERCENTUAL', 'Régua do veredito', 20, NOW(), 'carga inicial'),

('prospect_piso_aprovado', '5000',
 'Receita mínima para aprovar prospect',
 'Cliente novo não tem receita atual para comparar. Precisa gerar pelo menos isto por mês para valer a pena.',
 'DINHEIRO', 'Régua do veredito', 30, NOW(), 'carga inicial'),

('prospect_piso_atencao', '1500',
 'Receita mínima para não reprovar prospect',
 'Abaixo disto, a proposta para cliente novo sai como "não compensa".',
 'DINHEIRO', 'Régua do veredito', 40, NOW(), 'carga inicial'),

('meses_projecao', '12',
 'Meses na projeção do ano',
 'Quantos meses a calculadora usa para anualizar a receita mensal. Mexer aqui muda a coluna "Receita total ano".',
 'NUMERO', 'Cálculo', 50, NOW(), 'carga inicial'),

('permitir_negociar_fator', '1',
 'Gerente pode ajustar o fator',
 'Ligado, o gerente altera o fator de cada produto dentro do piso e do teto cadastrados. Desligado, o fator é fixo.',
 'BOOLEANO', 'Cálculo', 60, NOW(), 'carga inicial'),

('alerta_divergencia_pct', '10',
 'Alerta de divergência de receita',
 'Quando a receita que o cliente paga hoje difere do fator padrão acima desta margem, a tela sinaliza a linha.',
 'PERCENTUAL', 'Cálculo', 70, NOW(), 'carga inicial'),

('titulo_ferramenta', 'Calculadora de Pricing',
 'Nome da ferramenta',
 'Aparece no cabeçalho de todas as telas.',
 'TEXTO', 'Geral', 80, NOW(), 'carga inicial'),

('subtitulo_ferramenta', 'Pessoa Jurídica',
 'Complemento do nome',
 'O texto menor ao lado do nome, no cabeçalho.',
 'TEXTO', 'Geral', 90, NOW(), 'carga inicial');
