<?php
/* ============================================================================
   Calculadora de Pricing PJ — credenciais do banco

   COPIE ESTE ARQUIVO para config/segredos.php e preencha. O arquivo
   segredos.php não vai para lugar nenhum: fica de fora do Git e o .htaccess
   da pasta impede o Apache de servi-lo.

   Por que um arquivo separado em vez de deixar a senha no código: para você
   poder mandar a pasta inteira para alguém, ou subir num repositório, sem
   mandar junto a senha do banco.
   ========================================================================== */

return array(

    /* --- o banco ---------------------------------------------------------
       No XAMPP recém-instalado o usuário é 'root' e a senha é vazia. No
       servidor do trabalho, peça um usuário só de leitura para as tabelas
       de carga (encarteiramento, fdados, fdados_produto) e de escrita
       apenas para as de aplicação (dim_produto, parametro, simulacao...). */
    'DB_HOST'  => '127.0.0.1',
    'DB_PORTA' => '3306',
    'DB_NOME'  => 'calculadora_pricing',
    'DB_USER'  => 'root',
    'DB_SENHA' => '',

    /* --- assinatura da identidade (opcional) ------------------------------
       Deixe vazio para não usar.

       Quando preenchido, a página só aceita a identidade que chegar na URL
       se ela vier acompanhada de uma assinatura conferida com este segredo.
       Serve para impedir que alguém digite o e-mail de outro gerente na
       barra de endereços e veja a carteira alheia.

       O preço de ligar isto: quem monta a URL precisa saber assinar, e o
       Power Fx não tem função de hash. Só vale a pena se um dia a
       identidade passar por um fluxo do Power Automate, que sabe assinar.
       Enquanto for Power Apps puro, deixe vazio e leia o aviso no DEPLOY.md.    */
    'ASSINATURA_SEGREDO' => '',

    /* --- modo de manutenção ----------------------------------------------
       Ligue para tirar a ferramenta do ar durante uma carga de dados. A tela
       mostra o aviso em vez de números pela metade.                         */
    'MANUTENCAO'       => false,
    'MANUTENCAO_TEXTO' => 'Carga de dados em andamento. Volte em alguns minutos.',
);
