@echo off
REM ============================================================================
REM  Copia o projeto para o htdocs do XAMPP.
REM
REM  POR QUE ISTO EXISTE: o PHP 7.1 no Windows nao abre arquivos em caminhos
REM  com acento, e esta pasta mora em "Area de Trabalho". Rodando de la, o
REM  require do PHP falha com "No such file or directory" e a tela morre sem
REM  explicacao nenhuma. Entao edita-se aqui e roda-se de la.
REM
REM  O config/segredos.php do destino e PRESERVADO: as credenciais do servidor
REM  nao sao as mesmas da sua maquina, e sobrescrever seria derrubar a
REM  aplicacao a cada sincronizacao.
REM ============================================================================

setlocal
set ORIGEM=%~dp0
set DESTINO=C:\xampp\htdocs\calculadora_pricing
set GUARDADO=%TEMP%\pricing_segredos_guardado.php

echo.
echo  De : %ORIGEM%
echo  Para: %DESTINO%
echo.

if not exist "C:\xampp\htdocs" (
    echo  ERRO: nao achei C:\xampp\htdocs. O XAMPP esta instalado em outro lugar?
    exit /b 1
)

REM --- guarda as credenciais do destino ------------------------------------
if exist "%DESTINO%\config\segredos.php" (
    copy /Y "%DESTINO%\config\segredos.php" "%GUARDADO%" >nul
    echo  credenciais do destino guardadas
)

REM --- copia ----------------------------------------------------------------
REM  /MIR espelha; /XD exclui pastas que nao pertencem ao servidor.
robocopy "%ORIGEM%." "%DESTINO%" /MIR /NFL /NDL /NJH /NJS /NP ^
    /XD node_modules .git ^
    /XF *.log >nul

if errorlevel 8 (
    echo  ERRO na copia. Codigo %errorlevel%.
    exit /b 1
)

REM --- devolve as credenciais ----------------------------------------------
if exist "%GUARDADO%" (
    copy /Y "%GUARDADO%" "%DESTINO%\config\segredos.php" >nul
    del "%GUARDADO%" >nul
    echo  credenciais do destino restauradas
)

echo.
echo  Pronto. Abra: http://localhost/calculadora_pricing/
echo.
endlocal
