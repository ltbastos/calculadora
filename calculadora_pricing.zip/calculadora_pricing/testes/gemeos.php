<?php
/* ============================================================================
   Roda os cenários de testes/cenarios.json no motor PHP e imprime o
   resultado em JSON, para o testes/gemeos.js comparar com o motor da tela.

   Não é para rodar sozinho — quem chama é o gemeos.js.
   ========================================================================== */

/* O motor usa parametroNumero() e parametroBooleano() só em pricingConfig(),
   que este teste não chama: a configuração vem do arquivo de cenários. Os
   stubs existem para o require não quebrar por função ausente. */
function parametroNumero($c, $p = 0)   { return $p; }
function parametroBooleano($c, $p = false) { return $p; }

require __DIR__ . '/../api/motor.php';

$json = file_get_contents(__DIR__ . '/cenarios.json');
$d = json_decode($json, true);

if (!is_array($d)) {
    fwrite(STDERR, "cenarios.json inválido\n");
    exit(1);
}

$saida = array();

foreach ($d['casos'] as $caso) {
    $r = pricingCalcular(
        $d['produtos'],
        isset($caso['atual']) ? $caso['atual'] : array(),
        isset($caso['entradas']) ? $caso['entradas'] : array(),
        $d['config']
    );

    /* Só o que precisa bater. Os textos do veredito entram porque eles vão
       para o banco e para o resumo copiado — divergir neles também é bug. */
    $linhas = array();
    foreach ($r['linhas'] as $l) {
        $linhas[$l['codigo']] = array(
            'receita_incremento' => $l['receita_incremento'],
            'receita_projetada'  => $l['receita_projetada'],
            'receita_ano'        => $l['receita_ano'],
            'fator_usado'        => (float) $l['fator_usado'],
            'fator_negociado'    => (bool) $l['fator_negociado'],
            'fator_ajustado'     => (bool) $l['fator_ajustado'],
            'divergente'         => (bool) $l['divergente'],
        );
    }

    $saida[] = array(
        'nome'     => $caso['nome'],
        'totais'   => $r['totais'],
        'veredito' => $r['veredito'],
        'linhas'   => $linhas,
    );
}

echo json_encode($saida, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
