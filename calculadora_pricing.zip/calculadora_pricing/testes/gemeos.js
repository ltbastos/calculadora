/* ============================================================================
   Os gêmeos precisam concordar.

       node testes/gemeos.js

   src/motor.js calcula na tela, api/motor.php recalcula ao gravar. Se os dois
   discordarem, a pessoa vê um número na tela e outro no comprovante — e
   descobre isso na frente do cliente.

   Este teste roda os mesmos cenários nos dois e compara valor por valor,
   inclusive os textos do veredito (que vão para o banco).

   RODE DEPOIS DE MEXER EM QUALQUER UM DOS DOIS MOTORES.

   Precisa do Node só para o teste; a aplicação não usa Node para nada.
   ========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { execFileSync } = require('child_process');

const RAIZ = path.join(__dirname, '..');

/* Onde está o PHP. O do XAMPP, ou o que estiver no PATH. */
const PHP = fs.existsSync('C:/xampp/php/php.exe') ? 'C:/xampp/php/php.exe' : 'php';


/* ---------------------------------------------------------------------------
   Carrega os dois arquivos da tela num contexto com window falso, que é tudo
   de que eles precisam — nenhum dos dois toca em DOM.
   ------------------------------------------------------------------------- */
function carregarMotorDaTela() {
  const janela = {};
  const contexto = vm.createContext({ window: janela, Intl, console });

  for (const arquivo of ['src/formato.js', 'src/motor.js']) {
    const codigo = fs.readFileSync(path.join(RAIZ, arquivo), 'utf8');
    vm.runInContext(codigo, contexto, { filename: arquivo });
  }

  if (!janela.Motor) { throw new Error('src/motor.js não publicou window.Motor'); }
  return janela.Motor;
}


/* ---------------------------------------------------------------------------
   Comparação
   ------------------------------------------------------------------------- */

/* Tolerância de meio centavo. Zero seria rigoroso demais para float, e mais
   que isso deixaria passar justamente o erro que este teste procura. */
const TOLERANCIA = 0.005;

function comparar(caminho, a, b, problemas) {
  if (typeof a === 'number' || typeof b === 'number') {
    const na = Number(a) || 0;
    const nb = Number(b) || 0;
    if (Math.abs(na - nb) > TOLERANCIA) {
      problemas.push(`${caminho}: js=${na} php=${nb}`);
    }
    return;
  }

  if (typeof a === 'boolean' || typeof b === 'boolean') {
    if (!!a !== !!b) { problemas.push(`${caminho}: js=${a} php=${b}`); }
    return;
  }

  if (typeof a === 'string' || typeof b === 'string') {
    if (String(a) !== String(b)) {
      problemas.push(`${caminho}:\n        js  "${a}"\n        php "${b}"`);
    }
    return;
  }

  if (a && b && typeof a === 'object') {
    const chaves = new Set([...Object.keys(a), ...Object.keys(b)]);
    for (const k of chaves) { comparar(`${caminho}.${k}`, a[k], b[k], problemas); }
  }
}


/* ------------------------------------------------------------------------- */
function rodar() {
  const cenarios = JSON.parse(fs.readFileSync(path.join(__dirname, 'cenarios.json'), 'utf8'));
  const Motor = carregarMotorDaTela();

  let doPhp;
  try {
    const bruto = execFileSync(PHP, [path.join(__dirname, 'gemeos.php')], {
      encoding: 'utf8', maxBuffer: 20 * 1024 * 1024
    });
    doPhp = JSON.parse(bruto);
  } catch (e) {
    console.error('Não consegui rodar o motor PHP.');
    console.error(e.stdout || e.message);
    process.exit(2);
  }

  console.log('\n  Comparando src/motor.js  x  api/motor.php\n');

  let falhas = 0;

  cenarios.casos.forEach((caso, i) => {
    const js = Motor.calcular(
      cenarios.produtos,
      caso.atual || {},
      caso.entradas || {},
      cenarios.config
    );

    const linhasJs = {};
    js.linhas.forEach(l => {
      linhasJs[l.codigo] = {
        receita_incremento: l.receita_incremento,
        receita_projetada:  l.receita_projetada,
        receita_ano:        l.receita_ano,
        fator_usado:        l.fator_usado,
        fator_negociado:    l.fator_negociado,
        fator_ajustado:     l.fator_ajustado,
        divergente:         l.divergente
      };
    });

    const php = doPhp[i];
    const problemas = [];

    comparar('totais',   js.totais,   php.totais,   problemas);
    comparar('veredito', js.veredito, php.veredito, problemas);
    comparar('linhas',   linhasJs,    php.linhas,   problemas);

    if (problemas.length) {
      falhas++;
      console.log(`  FALHOU  ${caso.nome}`);
      problemas.forEach(p => console.log(`      ${p}`));
    } else {
      const t = js.totais;
      console.log(`  ok      ${caso.nome}`);
      console.log(`          ${js.veredito.status.padEnd(9)} `
        + `hoje ${t.receita_atual_mes.toFixed(2)}  `
        + `+${t.receita_incremento_mes.toFixed(2)}  `
        + `= ${t.receita_projetada_mes.toFixed(2)}  `
        + `ano ${t.receita_ano.toFixed(2)}`);
    }
  });

  console.log('');
  if (falhas) {
    console.log(`  ${falhas} de ${cenarios.casos.length} cenários DIVERGIRAM.`);
    console.log('  Os dois motores precisam dar o mesmo número. Veja docs/CALCULO.md.\n');
    process.exit(1);
  }

  console.log(`  Os ${cenarios.casos.length} cenários bateram nos dois motores.\n`);
}

rodar();
