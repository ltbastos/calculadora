# Levar para o ambiente do trabalho

Um roteiro. A ordem importa: cada passo depende do anterior.

---

## Antes de começar, três coisas para confirmar

| O quê | Por quê |
|---|---|
| Existe um MySQL/MariaDB acessível | é onde as três tabelas vão morar |
| O caminho da pasta **não tem acento** | o PHP no Windows não abre arquivo em caminho com acento — `Área`, `Ação`, `Serviço`. `C:\xampp\htdocs\calculadora_pricing` serve |
| Você consegue publicar um Power App | é o que identifica o usuário. Ver `docs/IDENTIFICACAO.md` |

---

## 1. Copiar a pasta

Para o `htdocs` do XAMPP do servidor. **Não leve junto:**

- `config/segredos.php` — as credenciais de lá são outras
- `mock/` e `banco/03-exemplo.sql` — dados fictícios não têm o que fazer em produção
- `testes/` e `node_modules/` — só servem para desenvolver

---

## 2. Criar o banco

```
banco/01-esquema.sql     as tabelas
banco/02-produtos.sql    o catálogo e a régua
```

**Não rode o `03-exemplo.sql`.** As três tabelas de carga vêm da fonte real.

O `02-produtos.sql` roda **uma vez só**. Depois dele, produto e fator se
mexem pela tela de administração — rodar de novo apagaria o que a área já
tiver ajustado.

---

## 3. As credenciais

Copie `config/segredos.exemplo.php` para `config/segredos.php` e preencha.

Peça ao DBA um usuário com o mínimo necessário:

```sql
-- só leitura nas tabelas de carga
GRANT SELECT ON calculadora_pricing.encarteiramento  TO 'pricing_app'@'%';
GRANT SELECT ON calculadora_pricing.fdados           TO 'pricing_app'@'%';
GRANT SELECT ON calculadora_pricing.fdados_produto   TO 'pricing_app'@'%';

-- leitura e escrita nas tabelas da aplicação
GRANT SELECT, INSERT, UPDATE ON calculadora_pricing.dim_produto     TO 'pricing_app'@'%';
GRANT SELECT, INSERT, UPDATE ON calculadora_pricing.parametro       TO 'pricing_app'@'%';
GRANT SELECT, INSERT         ON calculadora_pricing.fator_historico TO 'pricing_app'@'%';
GRANT SELECT, INSERT         ON calculadora_pricing.simulacao       TO 'pricing_app'@'%';
GRANT SELECT, INSERT         ON calculadora_pricing.simulacao_item  TO 'pricing_app'@'%';
GRANT SELECT                 ON calculadora_pricing.app_admin       TO 'pricing_app'@'%';
```

Sem `DELETE` em lugar nenhum: nada nesta ferramenta apaga registro, e o
histórico de fator existe justamente para não poder ser apagado.

---

## 4. Carregar as três tabelas

### encarteiramento — quem atende quem

Uma linha por conta. O essencial:

| Coluna | Observação |
|---|---|
| `cnpj` | **só dígitos, 14 posições, com os zeros à esquerda** |
| `conta` | só dígitos |
| `grupo_numero` | só dígitos |
| `gerente_email` | **o mais importante** — é por ele que a carteira é encontrada |
| `gerente_funcional` | o segundo caminho, quando o extrato não traz e-mail |
| `razao_social` | o nome que o gerente vê |

> **O erro que mais custa tempo:** CNPJ perdendo o zero à esquerda por ter
> passado por uma coluna numérica do Excel. `01234567000189` vira
> `1234567000189` e o cliente some da busca para sempre.
> Importe a coluna como **texto**, e confira com:
> ```sql
> SELECT COUNT(*) FROM encarteiramento WHERE LENGTH(cnpj) <> 14;
> ```
> Tem que dar zero.

### fdados — o retrato do cliente

Uma linha por (`chave`, `nivel`). O mesmo cliente pode aparecer três vezes —
uma pela conta, uma pelo CNPJ, uma pelo grupo. Não é duplicata: são três
recortes, e a tela deixa escolher em qual negociar.

`chave` guarda **só dígitos**, sempre.

### fdados_produto — a abertura por produto

Uma linha por cliente **e** produto. O `produto_codigo` tem que bater com o
`codigo` de `dim_produto` — é a única amarração entre a carga e o catálogo.

Confira se sobrou algum código órfão:

```sql
SELECT DISTINCT fp.produto_codigo
  FROM fdados_produto fp
  LEFT JOIN dim_produto p ON p.codigo = fp.produto_codigo
 WHERE p.codigo IS NULL;
```

Nada deve voltar. O que voltar é produto que a carga conhece e o catálogo
não — some da tela sem avisar.

### E confira se a soma fecha

```sql
SELECT f.chave, f.nivel, f.receita_mensal_atual,
       ROUND(SUM(fp.receita_atual), 2) AS soma_produtos
  FROM fdados f
  JOIN fdados_produto fp ON fp.chave = f.chave AND fp.nivel = f.nivel
 GROUP BY f.chave, f.nivel, f.receita_mensal_atual
HAVING ABS(f.receita_mensal_atual - soma_produtos) > 1;
```

Divergência aqui não impede a ferramenta de funcionar, mas significa que o
cabeçalho e a abertura vieram de recortes diferentes — e o gerente vai ver
dois números que não conversam.

---

## 5. Quem administra

```sql
INSERT INTO app_admin (email, nome, ativo, criado_em) VALUES
('fulano@bradesco.com.br', 'Fulano de Tal', 1, NOW());
```

O e-mail tem que ser **o mesmo** que o Power App entrega — sempre em
minúsculas.

---

## 6. Ligar a identificação

`docs/IDENTIFICACAO.md` tem o passo a passo do Power App.

Depois, em `src/config.js`:

```js
MODO: 'powerapps',
POWERAPP_URL: 'https://apps.powerapps.com/play/e/.../a/...',
```

---

## 7. Conferir que o Apache protege o `config/`

A pasta tem um `.htaccess` que nega tudo. Ele **só vale se o Apache estiver
com `AllowOverride All`** para o `htdocs`. Teste abrindo no navegador:

```
http://SERVIDOR/calculadora_pricing/config/segredos.php
```

Tem que dar **403**. Se aparecer uma página em branco, também está seguro
(o PHP executou o arquivo, que só devolve um array sem imprimir nada) — mas
o 403 é a resposta certa. Se aparecer **o código com a senha**, pare tudo e
arrume o `AllowOverride` antes de qualquer outra coisa.

---

## 8. O passeio de aceitação

Antes de liberar para o time, faça este caminho inteiro:

- [ ] abrir pelo Power App e o nome que aparece no topo é o seu
- [ ] "Escolher da minha carteira" lista os seus clientes, e só os seus
- [ ] buscar um CNPJ da carteira traz os números certos
- [ ] buscar um número de grupo oferece o nível de grupo
- [ ] digitar um incremento muda o veredito **enquanto digita**
- [ ] "Salvar em PDF" devolve um protocolo, e a simulação aparece no histórico
- [ ] o PDF sai em **uma página**, com protocolo, veredito, tabela e rodapé de autor
- [ ] no PDF entram só os produtos com movimento — os zerados ficam de fora
- [ ] abrir com o e-mail de outro gerente mostra a carteira **dele**, não a sua
- [ ] quem não está em `app_admin` não abre o `admin.html`
- [ ] mudar um fator na tela de administração e ver a mudança no histórico
- [ ] o fator novo aparece na calculadora ao recarregar

---

## Manutenção

### A cada carga de dados

Ligue o modo de manutenção em `config/segredos.php` enquanto recarrega as
tabelas:

```php
'MANUTENCAO' => true,
```

A tela passa a mostrar o aviso em vez de meia base. Desligue ao terminar.

### Quando a área passar uma tabela de fatores nova

Pela tela de administração, nunca pelo SQL. Preencha o campo "Por que está
mudando?" — é o que responde, daqui a três meses, à pergunta "por que essa
tarifa mudou?".

### Se mexer no cálculo

Rode `node testes/gemeos.js` **antes de publicar**. Os dois motores precisam
dar o mesmo número; quando divergem, a pessoa vê um valor na tela e outro no
comprovante gravado.

### Se a tela ficar em branco

Nessa ordem:

1. **F12 → Console.** Erro de JavaScript aparece ali.
2. **F12 → Rede.** Uma chamada em vermelho diz qual endpoint falhou.
3. **Abra o endpoint direto no navegador**, com a identidade na URL:
   `api/sessao.php?email=voce@bradesco.com.br` — se vier HTML em vez de
   JSON, é erro de PHP.
4. **Log de erro do Apache.** As mensagens cruas de banco vão para lá de
   propósito: elas contêm usuário e host, e não podem aparecer na tela de
   ninguém.
