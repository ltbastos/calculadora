<?php
/* ============================================================================
   GET  api/admin.php            catálogo completo, parâmetros e histórico
   POST api/admin.php            grava alterações de produtos e parâmetros

   A tela que a área responsável usa para mexer nos fatores sem pedir nada
   para a TI. É o ponto do projeto onde "fácil de mudar" deixa de ser promessa.

   ---------------------------------------------------------------------------
   TODA ALTERAÇÃO VIRA LINHA EM fator_historico, campo por campo.

   Não é burocracia: fator é preço. Daqui a três meses alguém vai perguntar
   por que a tarifa do boleto subiu, e a resposta precisa existir em algum
   lugar que não seja a memória de quem mexeu.
   ========================================================================== */

require __DIR__ . '/comum.php';

conferirManutencao();

$metodo = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';

/* exigirAdmin antes de qualquer coisa, inclusive da leitura: o catálogo com
   piso e teto de negociação é informação de alçada, não é para todo mundo. */
$eu = exigirAdmin();

if ($metodo === 'POST') {
    gravarAdmin($eu);
}
lerAdmin();


/* ========================================================================= */
/*  leitura                                                                  */
/* ========================================================================= */
function lerAdmin()
{
    /* Aqui vêm os inativos também — é nesta tela que eles voltam a existir. */
    $produtos = consultar(
        'SELECT codigo, nome, grupo, ordem, tipo_volume, tipo_fator, periodicidade,
                unidade, ajuda, fator, fator_piso, fator_teto, ativo,
                atualizado_em, atualizado_por
           FROM dim_produto
          ORDER BY ordem, nome'
    );

    foreach ($produtos as $i => $p) {
        $produtos[$i]['fator']      = (float) $p['fator'];
        $produtos[$i]['fator_piso'] = $p['fator_piso'] === null ? null : (float) $p['fator_piso'];
        $produtos[$i]['fator_teto'] = $p['fator_teto'] === null ? null : (float) $p['fator_teto'];
        $produtos[$i]['ordem']      = (int) $p['ordem'];
        $produtos[$i]['ativo']      = ((int) $p['ativo'] === 1);
    }

    $parametros = consultar(
        'SELECT chave, valor, rotulo, ajuda, tipo, grupo, ordem, atualizado_em, atualizado_por
           FROM parametro ORDER BY ordem, chave'
    );

    /* As últimas trinta mudanças. Quem quiser o histórico inteiro de um
       produto pede por produto — a tela tem esse filtro. */
    $historico = consultar(
        'SELECT h.produto_codigo, h.campo, h.valor_antes, h.valor_depois, h.motivo,
                h.usuario_nome, h.criado_em, p.nome AS produto_nome
           FROM fator_historico h
           LEFT JOIN dim_produto p ON p.codigo = h.produto_codigo
          ORDER BY h.id DESC LIMIT 30'
    );

    $admins = consultar('SELECT email, nome, funcional FROM app_admin WHERE ativo = 1 ORDER BY nome, email');

    responder(array(
        'ok'         => true,
        'produtos'   => $produtos,
        'parametros' => $parametros,
        'historico'  => $historico,
        'admins'     => $admins,
    ));
}


/* ========================================================================= */
/*  gravação                                                                 */
/* ========================================================================= */
function gravarAdmin($eu)
{
    $corpo = corpoJson();
    $motivo = isset($corpo['motivo']) ? textoOuNulo($corpo['motivo'], 255) : null;

    $mudancas = 0;
    $pdo = banco();
    $pdo->beginTransaction();

    try {
        /* --- produtos ----------------------------------------------------- */
        if (isset($corpo['produtos']) && is_array($corpo['produtos'])) {
            foreach ($corpo['produtos'] as $p) {
                $mudancas += gravarProduto($p, $eu, $motivo);
            }
        }

        /* --- parâmetros --------------------------------------------------- */
        if (isset($corpo['parametros']) && is_array($corpo['parametros'])) {
            foreach ($corpo['parametros'] as $chave => $valor) {
                $mudancas += gravarParametro((string) $chave, $valor, $eu, $motivo);
            }
        }

        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('[pricing] falha ao gravar admin: ' . $e->getMessage());
        erro('falha-gravacao', 'Não consegui salvar as alterações. Nada foi gravado. Tente de novo.', 500);
    }

    responder(array(
        'ok'       => true,
        'mudancas' => $mudancas,
        'mensagem' => $mudancas === 0
            ? 'Nada mudou — os valores enviados são iguais aos que já estavam salvos.'
            : ($mudancas === 1 ? '1 alteração salva.' : $mudancas . ' alterações salvas.'),
    ));
}


/* Grava um produto e devolve quantos campos mudaram de fato.

   A comparação campo a campo existe para o histórico não encher de linhas
   vazias: a tela manda o catálogo inteiro a cada salvamento, e sem isso
   catorze produtos gerariam catorze registros de "mudou de 2,45 para 2,45". */
function gravarProduto($p, $eu, $motivo)
{
    if (!isset($p['codigo'])) { return 0; }

    $codigo = trim((string) $p['codigo']);
    if ($codigo === '') { return 0; }

    $antes = consultarUm('SELECT * FROM dim_produto WHERE codigo = ? LIMIT 1', array($codigo));

    /* --- produto novo -------------------------------------------------- */
    if ($antes === null) {
        if (!preg_match('/^[a-z0-9_]{2,40}$/', $codigo)) {
            erro('codigo-invalido',
                 'O código "' . $codigo . '" não serve. Use só letras minúsculas, números e sublinhado.', 400);
        }

        executar(
            'INSERT INTO dim_produto
                (codigo, nome, grupo, ordem, tipo_volume, tipo_fator, periodicidade,
                 unidade, ajuda, fator, fator_piso, fator_teto, ativo, atualizado_em, atualizado_por)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?)',
            array(
                $codigo,
                textoOuNulo(isset($p['nome']) ? $p['nome'] : $codigo, 120),
                textoOuNulo(isset($p['grupo']) ? $p['grupo'] : 'Outros', 60),
                isset($p['ordem']) ? (int) $p['ordem'] : 999,
                validarEnum(isset($p['tipo_volume']) ? $p['tipo_volume'] : 'VALOR', array('QUANTIDADE','VALOR','CONTEXTO')),
                validarEnum(isset($p['tipo_fator']) ? $p['tipo_fator'] : 'TAXA', array('TARIFA','TAXA','NENHUM')),
                validarEnum(isset($p['periodicidade']) ? $p['periodicidade'] : 'MENSAL', array('MENSAL','ANUAL')),
                textoOuNulo(isset($p['unidade']) ? $p['unidade'] : null, 40),
                textoOuNulo(isset($p['ajuda']) ? $p['ajuda'] : null, 255),
                isset($p['fator']) ? paraNumero($p['fator']) : 0,
                valorOuNulo(isset($p['fator_piso']) ? $p['fator_piso'] : null),
                valorOuNulo(isset($p['fator_teto']) ? $p['fator_teto'] : null),
                (isset($p['ativo']) && !$p['ativo']) ? 0 : 1,
                textoOuNulo($eu['nome'] !== '' ? $eu['nome'] : $eu['email'], 160),
            )
        );

        registrarHistorico($codigo, 'criado', null, $codigo, $motivo, $eu);
        return 1;
    }

    /* --- produto existente: só o que mudou ----------------------------- */
    $novo = array(
        'nome'          => textoOuNulo(isset($p['nome']) ? $p['nome'] : $antes['nome'], 120),
        'grupo'         => textoOuNulo(isset($p['grupo']) ? $p['grupo'] : $antes['grupo'], 60),
        'ordem'         => isset($p['ordem']) ? (int) $p['ordem'] : (int) $antes['ordem'],
        'tipo_volume'   => validarEnum(isset($p['tipo_volume']) ? $p['tipo_volume'] : $antes['tipo_volume'], array('QUANTIDADE','VALOR','CONTEXTO')),
        'tipo_fator'    => validarEnum(isset($p['tipo_fator']) ? $p['tipo_fator'] : $antes['tipo_fator'], array('TARIFA','TAXA','NENHUM')),
        'periodicidade' => validarEnum(isset($p['periodicidade']) ? $p['periodicidade'] : $antes['periodicidade'], array('MENSAL','ANUAL')),
        'unidade'       => textoOuNulo(isset($p['unidade']) ? $p['unidade'] : $antes['unidade'], 40),
        'ajuda'         => textoOuNulo(isset($p['ajuda']) ? $p['ajuda'] : $antes['ajuda'], 255),
        'fator'         => isset($p['fator']) ? paraNumero($p['fator']) : (float) $antes['fator'],
        'fator_piso'    => array_key_exists('fator_piso', $p) ? valorOuNulo($p['fator_piso']) : ($antes['fator_piso'] === null ? null : (float) $antes['fator_piso']),
        'fator_teto'    => array_key_exists('fator_teto', $p) ? valorOuNulo($p['fator_teto']) : ($antes['fator_teto'] === null ? null : (float) $antes['fator_teto']),
        'ativo'         => isset($p['ativo']) ? ($p['ativo'] ? 1 : 0) : (int) $antes['ativo'],
    );

    /* Piso maior que teto é a alçada invertida: barra aqui, porque o motor
       aplicaria os dois em sequência e o resultado seria silenciosamente
       errado em vez de recusado. */
    if ($novo['fator_piso'] !== null && $novo['fator_teto'] !== null
        && $novo['fator_piso'] > $novo['fator_teto']) {
        erro('alcada-invertida',
             'Em "' . $novo['nome'] . '", o piso está maior que o teto. Confira os dois valores.', 400);
    }

    $mudou = array();
    foreach ($novo as $campo => $valor) {
        $valorAntes = $antes[$campo];

        /* Comparação numérica onde o campo é número: "2.45" e "2.45000000"
           são o mesmo fator, e o MySQL devolve a segunda forma. */
        if (in_array($campo, array('fator', 'fator_piso', 'fator_teto'), true)) {
            $a = $valorAntes === null ? null : (float) $valorAntes;
            $b = $valor === null ? null : (float) $valor;
            $igual = ($a === null && $b === null) || ($a !== null && $b !== null && abs($a - $b) < 0.00000001);
        } elseif ($campo === 'ordem' || $campo === 'ativo') {
            $igual = ((int) $valorAntes === (int) $valor);
        } else {
            $igual = ((string) $valorAntes === (string) $valor);
        }

        if (!$igual) { $mudou[$campo] = array($valorAntes, $valor); }
    }

    if (count($mudou) === 0) { return 0; }

    executar(
        'UPDATE dim_produto
            SET nome = ?, grupo = ?, ordem = ?, tipo_volume = ?, tipo_fator = ?, periodicidade = ?,
                unidade = ?, ajuda = ?, fator = ?, fator_piso = ?, fator_teto = ?, ativo = ?,
                atualizado_em = NOW(), atualizado_por = ?
          WHERE codigo = ?',
        array(
            $novo['nome'], $novo['grupo'], $novo['ordem'], $novo['tipo_volume'], $novo['tipo_fator'],
            $novo['periodicidade'], $novo['unidade'], $novo['ajuda'], $novo['fator'],
            $novo['fator_piso'], $novo['fator_teto'], $novo['ativo'],
            textoOuNulo($eu['nome'] !== '' ? $eu['nome'] : $eu['email'], 160),
            $codigo,
        )
    );

    foreach ($mudou as $campo => $par) {
        registrarHistorico($codigo, $campo, $par[0], $par[1], $motivo, $eu);
    }

    return count($mudou);
}


function gravarParametro($chave, $valor, $eu, $motivo)
{
    $antes = consultarUm('SELECT valor, rotulo, tipo FROM parametro WHERE chave = ? LIMIT 1', array($chave));
    if ($antes === null) { return 0; }

    /* Número é normalizado antes de comparar, senão "15" e "15,0" gerariam
       uma mudança fantasma toda vez que a tela salvasse. */
    if (in_array($antes['tipo'], array('NUMERO', 'PERCENTUAL', 'DINHEIRO'), true)) {
        $novo = (string) paraNumero($valor);
        $velho = (string) paraNumero($antes['valor']);
    } elseif ($antes['tipo'] === 'BOOLEANO') {
        $novo  = ($valor === true || $valor === 1 || $valor === '1' || $valor === 'true') ? '1' : '0';
        $velho = ($antes['valor'] === '1') ? '1' : '0';
    } else {
        $novo  = (string) textoOuNulo($valor, 255);
        $velho = (string) $antes['valor'];
    }

    if ($novo === $velho) { return 0; }

    executar(
        'UPDATE parametro SET valor = ?, atualizado_em = NOW(), atualizado_por = ? WHERE chave = ?',
        array($novo, textoOuNulo($eu['nome'] !== '' ? $eu['nome'] : $eu['email'], 160), $chave)
    );

    /* Parâmetro também entra no histórico dos fatores, com o código
       "(parâmetro)" no lugar do produto. É um rastro só, e não dois. */
    registrarHistorico('(parametro)', $chave, $velho, $novo, $motivo, $eu);

    return 1;
}


function registrarHistorico($produto, $campo, $antes, $depois, $motivo, $eu)
{
    executar(
        'INSERT INTO fator_historico
            (produto_codigo, campo, valor_antes, valor_depois, motivo, usuario_nome, usuario_email, criado_em)
         VALUES (?,?,?,?,?,?,?,NOW())',
        array(
            $produto,
            $campo,
            $antes === null ? null : substr((string) $antes, 0, 60),
            $depois === null ? null : substr((string) $depois, 0, 60),
            $motivo,
            textoOuNulo($eu['nome'], 160),
            textoOuNulo($eu['email'], 160),
        )
    );
}


/* ========================================================================= */
/*  validação                                                                */
/* ========================================================================= */

/* ENUM inválido não pode chegar ao MySQL: em modo não-estrito ele grava
   string vazia sem reclamar, e aí o motor de cálculo recebe um produto que
   não sabe como cobra. */
function validarEnum($valor, $permitidos)
{
    $v = strtoupper(trim((string) $valor));
    if (!in_array($v, $permitidos, true)) {
        erro('valor-invalido',
             'Valor "' . $valor . '" não é aceito. Use um entre: ' . implode(', ', $permitidos) . '.', 400);
    }
    return $v;
}

/* Campo em branco vira NULL, e não zero. Piso zero é "não pode negociar
   abaixo de zero"; piso vazio é "não tem piso". São coisas diferentes. */
function valorOuNulo($v)
{
    if ($v === null || $v === '' || $v === false) { return null; }
    return paraNumero($v);
}
