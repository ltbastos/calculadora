<?php
/* ============================================================================
   POST api/simulacao.php   grava uma simulação
   GET  api/simulacao.php   lista as últimas de quem abriu
   GET  api/simulacao.php?protocolo=PRC-XXXXXX   abre uma específica

   ---------------------------------------------------------------------------
   O SERVIDOR RECALCULA TUDO. Sempre.

   A tela já calculou enquanto a pessoa digitava, e o resultado dela está
   correto. Mas o que chega aqui é só o VOLUME digitado — os totais que a tela
   mandou são ignorados e refeitos do zero com os fatores que estão no banco
   AGORA.

   Não é desconfiança de quem usa. É que uma simulação gravada é uma decisão
   comercial com nome e data, e ela precisa poder ser reproduzida: se o número
   viesse do navegador, uma aba aberta desde ontem gravaria hoje um resultado
   calculado com a tarifa de ontem, sem ninguém perceber.
   ========================================================================== */

require __DIR__ . '/comum.php';
require __DIR__ . '/motor.php';

conferirManutencao();

$eu = exigirIdentidade();

$metodo = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';

if ($metodo === 'POST') {
    gravarSimulacao($eu);
}
listarSimulacoes($eu);


/* ========================================================================= */
/*  gravar                                                                   */
/* ========================================================================= */
function gravarSimulacao($eu)
{
    $corpo = corpoJson();

    $nivel = isset($corpo['nivel']) ? strtoupper(trim($corpo['nivel'])) : '';
    $chave = isset($corpo['chave']) ? soDigitos($corpo['chave']) : '';

    if (!in_array($nivel, array('CONTA', 'CNPJ', 'GRUPO'), true) || $chave === '') {
        erro('alvo-invalido', 'Não sei para qual cliente é esta simulação.', 400);
    }

    $entradasBrutas = isset($corpo['entradas']) && is_array($corpo['entradas']) ? $corpo['entradas'] : array();
    if (count($entradasBrutas) === 0) {
        erro('sem-entradas', 'Nenhum valor foi informado na negociação.', 400);
    }

    /* --- normaliza o que veio da tela ------------------------------------
       Só o volume e o fator interessam. Qualquer outro campo que a tela
       tenha mandado é descartado aqui — o motor não olha para ele.        */
    $entradas = array();
    foreach ($entradasBrutas as $codigo => $e) {
        if (!is_array($e)) { continue; }
        $entradas[(string) $codigo] = array(
            'incremento' => isset($e['incremento']) ? paraNumero($e['incremento']) : 0.0,
            'fator'      => (isset($e['fator']) && $e['fator'] !== '' && $e['fator'] !== null)
                            ? paraNumero($e['fator']) : null,
        );
    }

    /* --- o catálogo e o retrato do cliente, lidos do banco agora ---------- */
    $produtos = consultar(
        'SELECT codigo, nome, grupo, tipo_volume, tipo_fator, periodicidade, unidade,
                fator, fator_piso, fator_teto
           FROM dim_produto WHERE ativo = 1 ORDER BY ordem, nome'
    );
    if (count($produtos) === 0) {
        erro('sem-produtos', 'Não há produto ativo no catálogo. Avise o administrador da calculadora.', 409);
    }

    $atual = array();
    foreach (consultar(
        'SELECT produto_codigo, volume_atual, receita_atual
           FROM fdados_produto WHERE chave = ? AND nivel = ?',
        array($chave, $nivel)
    ) as $p) {
        $atual[$p['produto_codigo']] = array(
            'volume_atual'  => (float) $p['volume_atual'],
            'receita_atual' => (float) $p['receita_atual'],
        );
    }

    $f = consultarUm(
        'SELECT razao_social, receita_mensal_atual FROM fdados WHERE chave = ? AND nivel = ? LIMIT 1',
        array($chave, $nivel)
    );

    $clienteNovo = ($f === null);

    $razao = isset($corpo['razao_social']) ? textoOuNulo($corpo['razao_social'], 180) : null;
    if ($f !== null && $f['razao_social'] !== null && $f['razao_social'] !== '') {
        $razao = $f['razao_social'];
    }

    /* --- a conta, refeita do zero ---------------------------------------- */
    $r = pricingCalcular($produtos, $atual, $entradas, pricingConfig());

    /* --- grava ------------------------------------------------------------
       Tudo dentro de uma transação: simulação sem itens seria um registro
       que não conta história nenhuma, e é exatamente o que sobraria se a
       segunda parte falhasse no meio.                                      */
    $pdo = banco();
    $pdo->beginTransaction();

    try {
        $protocolo = gerarProtocoloLivre();

        executar(
            'INSERT INTO simulacao
                (protocolo, usuario_nome, usuario_email, usuario_funcional,
                 chave, nivel, razao_social, cliente_novo,
                 receita_atual_mes, receita_projetada_mes, incremento_mes,
                 variacao_pct, receita_ano, veredito, veredito_texto, observacao, criado_em)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())',
            array(
                $protocolo,
                textoOuNulo($eu['nome'], 160),
                textoOuNulo($eu['email'], 160),
                textoOuNulo($eu['funcional'], 20),
                $chave,
                $nivel,
                $razao,
                $clienteNovo ? 1 : 0,
                $r['totais']['receita_atual_mes'],
                $r['totais']['receita_projetada_mes'],
                $r['totais']['receita_incremento_mes'],
                $r['totais']['variacao_pct'],
                $r['totais']['receita_ano'],
                $r['veredito']['status'] === 'VAZIO' ? 'REPROVADO' : $r['veredito']['status'],
                textoOuNulo($r['veredito']['titulo'] . ' — ' . $r['veredito']['texto'], 255),
                isset($corpo['observacao']) ? textoOuNulo($corpo['observacao'], 4000) : null,
            )
        );

        $simulacaoId = (int) $pdo->lastInsertId();

        /* Só as linhas que alguém tocou. Gravar as catorze todas, sendo que
           onze estão zeradas, é lixo que vai atrapalhar quem for ler depois. */
        foreach ($r['linhas'] as $linha) {
            if ($linha['incremento'] == 0.0 && $linha['receita_atual'] == 0.0) { continue; }

            executar(
                'INSERT INTO simulacao_item
                    (simulacao_id, produto_codigo, produto_nome, volume_atual, receita_atual,
                     incremento_volume, fator_usado, fator_negociado, receita_incremento, receita_projetada)
                 VALUES (?,?,?,?,?,?,?,?,?,?)',
                array(
                    $simulacaoId,
                    $linha['codigo'],
                    $linha['nome'],
                    $linha['volume_atual'],
                    $linha['receita_atual'],
                    $linha['incremento'],
                    $linha['fator_usado'],
                    $linha['fator_negociado'] ? 1 : 0,
                    $linha['receita_incremento'],
                    $linha['receita_projetada'],
                )
            );
        }

        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('[pricing] falha ao gravar simulacao: ' . $e->getMessage());
        erro('falha-gravacao', 'Não consegui gravar a simulação. Tente de novo; se persistir, avise o suporte.', 500);
    }

    responder(array(
        'ok'        => true,
        'protocolo' => $protocolo,
        'resultado' => $r,
    ));
}

/* Protocolo é ditado ao telefone e citado em e-mail, então precisa ser único
   de verdade. Seis caracteres em 32 dão 1 bilhão de combinações; mesmo assim
   conferimos, porque "raro" não é "nunca" e o índice UNIQUE rejeitaria a
   gravação inteira por causa disso. */
function gerarProtocoloLivre()
{
    for ($tentativa = 0; $tentativa < 12; $tentativa++) {
        $p = gerarProtocolo();
        $existe = consultarUm('SELECT id FROM simulacao WHERE protocolo = ? LIMIT 1', array($p));
        if ($existe === null) { return $p; }
    }
    /* Doze colisões seguidas não acontecem por acaso — nesse ponto o
       problema é outro, e o timestamp garante que a gravação não se perca. */
    return 'PRC-' . date('ymdHis');
}


/* ========================================================================= */
/*  listar                                                                   */
/* ========================================================================= */
function listarSimulacoes($eu)
{
    $protocolo = isset($_GET['protocolo']) ? trim($_GET['protocolo']) : '';

    if ($protocolo !== '') {
        $s = consultarUm(
            'SELECT * FROM simulacao WHERE protocolo = ? LIMIT 1',
            array($protocolo)
        );
        if ($s === null) {
            erro('nao-encontrado', 'Não achei a simulação ' . $protocolo . '.', 404);
        }

        $s['itens'] = consultar(
            'SELECT * FROM simulacao_item WHERE simulacao_id = ? ORDER BY id',
            array((int) $s['id'])
        );

        responder(array('ok' => true, 'simulacao' => $s));
    }

    $limite = isset($_GET['limite']) ? (int) $_GET['limite'] : 12;
    if ($limite < 1)  { $limite = 12; }
    if ($limite > 100) { $limite = 100; }

    /* Filtrado pelo e-mail de quem abriu: o histórico é o da pessoa, não o
       da ferramenta. Quem precisa ver tudo usa o banco. */
    $linhas = consultar(
        'SELECT protocolo, chave, nivel, razao_social, cliente_novo,
                receita_atual_mes, receita_projetada_mes, incremento_mes,
                variacao_pct, receita_ano, veredito, criado_em
           FROM simulacao
          WHERE LOWER(usuario_email) = ?
          ORDER BY id DESC
          LIMIT ' . (int) $limite,
        array($eu['email'])
    );

    foreach ($linhas as $i => $l) {
        $linhas[$i]['receita_atual_mes']     = (float) $l['receita_atual_mes'];
        $linhas[$i]['receita_projetada_mes'] = (float) $l['receita_projetada_mes'];
        $linhas[$i]['incremento_mes']        = (float) $l['incremento_mes'];
        $linhas[$i]['variacao_pct']          = (float) $l['variacao_pct'];
        $linhas[$i]['receita_ano']           = (float) $l['receita_ano'];
        $linhas[$i]['cliente_novo']          = ((int) $l['cliente_novo'] === 1);
    }

    responder(array('ok' => true, 'total' => count($linhas), 'simulacoes' => $linhas));
}
