<?php
/* ============================================================================
   GET api/cliente.php?termo=…&nivel=CNPJ&chave=…

   O coração da busca. O gerente digita UMA coisa — CNPJ, conta ou número de
   grupo — e esta chamada descobre o que ele quis dizer.

   ---------------------------------------------------------------------------
   POR QUE NÃO DÁ PARA ADIVINHAR PELO TAMANHO

   Seria cômodo dizer "14 dígitos é CNPJ, 8 é conta, 4 é grupo". Só que 8
   dígitos também é raiz de CNPJ, e conta com DV também dá 8. Chutar pelo
   tamanho acerta na maioria e erra justamente no cliente grande, que é onde
   o erro custa caro.

   Então esta chamada procura o número em TODOS os níveis e devolve o que
   encontrou. Achou um só, a tela já abre. Achou mais de um, a tela pergunta.
   Ninguém adivinha nada.

   ---------------------------------------------------------------------------
   Duas passagens:
     1ª  termo=…            procura e devolve os alvos possíveis
     2ª  nivel=…&chave=…    traz os dados daquele alvo específico
   ========================================================================== */

require __DIR__ . '/comum.php';

conferirManutencao();

$eu = exigirIdentidade();

$termo = isset($_GET['termo']) ? trim($_GET['termo']) : '';
$nivel = isset($_GET['nivel']) ? strtoupper(trim($_GET['nivel'])) : '';
$chave = isset($_GET['chave']) ? soDigitos($_GET['chave']) : '';

$niveisValidos = array('CONTA', 'CNPJ', 'GRUPO');


/* ===========================================================================
   2ª passagem — o alvo já está escolhido, traga os dados
   ========================================================================= */
if ($nivel !== '' && $chave !== '') {

    if (!in_array($nivel, $niveisValidos, true)) {
        erro('nivel-invalido', 'Nível de análise desconhecido: ' . $nivel, 400);
    }

    responder(montarCliente($chave, $nivel, $eu));
}


/* ===========================================================================
   1ª passagem — descobrir o que a pessoa digitou
   ========================================================================= */
if ($termo === '') {
    erro('sem-termo', 'Digite um CNPJ, uma conta ou um número de grupo econômico.', 400);
}

$digitos = soDigitos($termo);

if ($digitos === '') {
    /* Não é número: trate como nome. A busca por nome vive em carteira.php,
       que já filtra pela carteira — e é lá que ela deve ficar. */
    erro('termo-texto',
         'Para procurar pelo nome, use a busca da sua carteira. Aqui entra CNPJ, conta ou número de grupo.', 400);
}

$alvos = array();
$vistos = array();

/* --- o que existe em fdados, em qualquer nível --------------------------- */
$emFdados = consultar(
    'SELECT chave, nivel, razao_social, receita_mensal_atual, faturamento_mensal_medio, segmento, referencia
       FROM fdados
      WHERE chave = ?
      ORDER BY FIELD(nivel, "GRUPO", "CNPJ", "CONTA")',
    array($digitos)
);

foreach ($emFdados as $f) {
    $id = $f['nivel'] . ':' . $f['chave'];
    if (isset($vistos[$id])) { continue; }
    $vistos[$id] = true;

    $alvos[] = array(
        'nivel'         => $f['nivel'],
        'chave'         => $f['chave'],
        'rotulo'        => rotuloDoNivel($f['nivel'], $f['chave']),
        'razao_social'  => $f['razao_social'],
        'receita_atual' => (float) $f['receita_mensal_atual'],
        'tem_dados'     => true,
        'referencia'    => $f['referencia'],
    );
}

/* --- o que existe no encarteiramento -------------------------------------
   Um cliente pode estar na carteira e ainda não ter entrado na carga de
   fdados. Nesse caso ele aparece na lista, identificado, mas sem números —
   e a tela deixa claro que a simulação começa do zero.                     */
$noEnc = consultar(
    'SELECT DISTINCT cnpj, conta, grupo_numero, razao_social, grupo_nome
       FROM encarteiramento
      WHERE ativo = 1
        AND (cnpj = ? OR conta = ? OR grupo_numero = ?)',
    array($digitos, $digitos, $digitos)
);

foreach ($noEnc as $e) {
    $candidatos = array();
    if ($e['cnpj'] === $digitos)         { $candidatos[] = array('CNPJ',  $digitos, $e['razao_social']); }
    if ($e['conta'] === $digitos)        { $candidatos[] = array('CONTA', $digitos, $e['razao_social']); }
    if ($e['grupo_numero'] === $digitos) { $candidatos[] = array('GRUPO', $digitos, $e['grupo_nome']); }

    foreach ($candidatos as $c) {
        $id = $c[0] . ':' . $c[1];
        if (isset($vistos[$id])) { continue; }
        $vistos[$id] = true;

        $alvos[] = array(
            'nivel'         => $c[0],
            'chave'         => $c[1],
            'rotulo'        => rotuloDoNivel($c[0], $c[1]),
            'razao_social'  => $c[2],
            'receita_atual' => 0.0,
            'tem_dados'     => false,
            'referencia'    => null,
        );
    }
}

/* --- não achou nada em lugar nenhum: é prospect -------------------------- */
if (count($alvos) === 0) {
    /* 14 dígitos com CNPJ válido merece tratamento de prospect de verdade.
       Qualquer outra coisa é provavelmente erro de digitação, e dizer isso
       poupa a pessoa de simular para um número que ela errou. */
    $nivelChutado = (strlen($digitos) === 14) ? 'CNPJ' : null;

    if ($nivelChutado === null) {
        erro('nao-encontrado',
             'Não encontrei nada com "' . $termo . '". Confira o número, ou procure pelo nome na sua carteira.', 404);
    }

    if (!cnpjValido($digitos)) {
        erro('cnpj-invalido',
             'O CNPJ ' . formatarCnpj($digitos) . ' não passa na verificação dos dígitos. Confira a digitação.', 400);
    }

    responder(array(
        'ok'       => true,
        'prospect' => true,
        'alvos'    => array(),
        'cliente'  => array(
            'nivel'         => 'CNPJ',
            'chave'         => $digitos,
            'chave_exibicao'=> formatarCnpj($digitos),
            'razao_social'  => '',
            'na_carteira'   => false,
            'tem_dados'     => false,
        ),
        'produtos' => array(),
        'aviso'    => 'Este CNPJ não está na base do banco. A simulação começa do zero, como cliente novo.',
    ));
}

/* --- achou um só: já devolve pronto -------------------------------------- */
if (count($alvos) === 1) {
    responder(montarCliente($alvos[0]['chave'], $alvos[0]['nivel'], $eu));
}

/* --- achou vários: a tela pergunta em qual nível simular ----------------- */
responder(array(
    'ok'        => true,
    'escolher'  => true,
    'termo'     => $termo,
    'alvos'     => $alvos,
));


/* ===========================================================================
   Monta o retrato completo de um cliente num nível
   ========================================================================= */
function montarCliente($chave, $nivel, $eu)
{
    $f = consultarUm(
        'SELECT * FROM fdados WHERE chave = ? AND nivel = ? LIMIT 1',
        array($chave, $nivel)
    );

    /* --- o cadastro, vindo do encarteiramento ---------------------------- */
    $coluna = ($nivel === 'CNPJ') ? 'cnpj' : (($nivel === 'CONTA') ? 'conta' : 'grupo_numero');

    $enc = consultarUm(
        'SELECT razao_social, nome_fantasia, cnpj, grupo_numero, grupo_nome,
                segmento, porte, regional, gerente_nome, gerente_email, gerente_funcional
           FROM encarteiramento
          WHERE ativo = 1 AND ' . $coluna . ' = ?
          ORDER BY razao_social LIMIT 1',
        array($chave)
    );

    /* Está na carteira de quem abriu? A tela mostra isso em letras claras.
       Não é bloqueio: o gerente às vezes simula para um cliente que ainda
       vai entrar na carteira dele, e travar isso atrapalharia o trabalho.
       Mas a simulação fica gravada dizendo de quem era o cliente.          */
    $naCarteira = false;
    if ($enc !== null) {
        $naCarteira = (strtolower((string) $enc['gerente_email']) === $eu['email'])
                   || ($enc['gerente_funcional'] !== '' && $enc['gerente_funcional'] === $eu['funcional']);
    }

    /* --- os outros níveis do mesmo cliente -------------------------------
       Serve para a tela oferecer "ver no CNPJ" ou "ver no grupo" sem a
       pessoa ter que descobrir sozinha que existe outro recorte.          */
    $irmaos = array();
    if ($enc !== null) {
        $chavesIrmas = array();
        if ($enc['cnpj'] !== null && $enc['cnpj'] !== '')                 { $chavesIrmas['CNPJ']  = $enc['cnpj']; }
        if ($enc['grupo_numero'] !== null && $enc['grupo_numero'] !== '') { $chavesIrmas['GRUPO'] = $enc['grupo_numero']; }

        foreach ($chavesIrmas as $n => $c) {
            if ($n === $nivel && $c === $chave) { continue; }

            $existe = consultarUm(
                'SELECT chave, nivel, razao_social, receita_mensal_atual
                   FROM fdados WHERE chave = ? AND nivel = ? LIMIT 1',
                array($c, $n)
            );
            if ($existe !== null) {
                $irmaos[] = array(
                    'nivel'         => $n,
                    'chave'         => $c,
                    'rotulo'        => rotuloDoNivel($n, $c),
                    'razao_social'  => $existe['razao_social'],
                    'receita_atual' => (float) $existe['receita_mensal_atual'],
                );
            }
        }
    }

    /* --- a abertura por produto ------------------------------------------ */
    $produtos = array();
    foreach (consultar(
        'SELECT produto_codigo, volume_atual, receita_atual, referencia
           FROM fdados_produto WHERE chave = ? AND nivel = ?',
        array($chave, $nivel)
    ) as $p) {
        $produtos[$p['produto_codigo']] = array(
            'volume_atual'  => (float) $p['volume_atual'],
            'receita_atual' => (float) $p['receita_atual'],
            'referencia'    => $p['referencia'],
        );
    }

    /* --- quantas contas e CNPJs esse recorte abrange ---------------------- */
    $abrangencia = null;
    if ($nivel === 'GRUPO' || $nivel === 'CNPJ') {
        $abrangencia = consultarUm(
            'SELECT COUNT(DISTINCT cnpj) AS cnpjs, COUNT(DISTINCT conta) AS contas
               FROM encarteiramento WHERE ativo = 1 AND ' . $coluna . ' = ?',
            array($chave)
        );
    }

    $razao = '';
    if ($f !== null && $f['razao_social'] !== null && $f['razao_social'] !== '') {
        $razao = $f['razao_social'];
    } elseif ($enc !== null) {
        $razao = ($nivel === 'GRUPO' && $enc['grupo_nome'] !== '') ? $enc['grupo_nome'] : $enc['razao_social'];
    }

    return array(
        'ok'       => true,
        'prospect' => ($f === null),
        'cliente'  => array(
            'nivel'           => $nivel,
            'chave'           => $chave,
            'chave_exibicao'  => rotuloDoNivel($nivel, $chave, true),
            'razao_social'    => $razao,
            'nome_fantasia'   => $enc !== null ? $enc['nome_fantasia'] : null,
            'cnpj'            => $enc !== null ? $enc['cnpj'] : ($nivel === 'CNPJ' ? $chave : null),
            'cnpj_exibicao'   => $enc !== null ? formatarCnpj($enc['cnpj']) : ($nivel === 'CNPJ' ? formatarCnpj($chave) : null),
            'grupo_numero'    => $enc !== null ? $enc['grupo_numero'] : null,
            'grupo_nome'      => $enc !== null ? $enc['grupo_nome'] : null,
            'segmento'        => $f !== null && $f['segmento'] !== '' ? $f['segmento'] : ($enc !== null ? $enc['segmento'] : null),
            'porte'           => $f !== null && $f['porte'] !== '' ? $f['porte'] : ($enc !== null ? $enc['porte'] : null),
            'regional'        => $enc !== null ? $enc['regional'] : null,
            'gerente_nome'    => $enc !== null ? $enc['gerente_nome'] : null,
            'na_carteira'     => $naCarteira,
            'tem_dados'       => ($f !== null),

            'faturamento_mensal_medio' => $f !== null ? (float) $f['faturamento_mensal_medio'] : 0.0,
            'receita_mensal_atual'     => $f !== null ? (float) $f['receita_mensal_atual']     : 0.0,
            'receita_projetada_ano'    => $f !== null ? (float) $f['receita_projetada_ano']    : 0.0,
            'data_relacionamento'      => $f !== null ? $f['data_relacionamento'] : null,
            'referencia'               => $f !== null ? $f['referencia'] : null,

            'cnpjs_abrangidos'  => $abrangencia !== null ? (int) $abrangencia['cnpjs']  : null,
            'contas_abrangidas' => $abrangencia !== null ? (int) $abrangencia['contas'] : null,
        ),
        'outros_niveis' => $irmaos,
        'produtos'      => $produtos,
        'aviso'         => ($f === null)
            ? 'Este cliente está cadastrado mas ainda não tem números na base de receita. A simulação começa do zero.'
            : null,
    );
}


/* ===========================================================================
   Rótulos e validação
   ========================================================================= */

function rotuloDoNivel($nivel, $chave, $soValor = false)
{
    if ($nivel === 'CNPJ') {
        return $soValor ? formatarCnpj($chave) : 'CNPJ ' . formatarCnpj($chave);
    }
    if ($nivel === 'GRUPO') {
        return $soValor ? $chave : 'Grupo econômico ' . $chave;
    }
    return $soValor ? $chave : 'Conta ' . $chave;
}

/* Verificação dos dois dígitos do CNPJ.

   Existe por um motivo prático: sem ela, um CNPJ digitado errado viraria um
   "prospect" novinho em folha, a pessoa simularia a negociação inteira e só
   descobriria o engano na hora de gravar. Errar cedo custa menos. */
function cnpjValido($cnpj)
{
    $c = soDigitos($cnpj);
    if (strlen($c) !== 14) { return false; }

    /* 00000000000000, 11111111111111… passam na conta dos dígitos mas não
       são CNPJ de ninguém. */
    if (preg_match('/^(\d)\1{13}$/', $c)) { return false; }

    $calcular = function ($base, $pesos) {
        $soma = 0;
        for ($i = 0; $i < strlen($base); $i++) {
            $soma += (int) $base[$i] * $pesos[$i];
        }
        $resto = $soma % 11;
        return ($resto < 2) ? 0 : 11 - $resto;
    };

    $d1 = $calcular(substr($c, 0, 12), array(5,4,3,2,9,8,7,6,5,4,3,2));
    $d2 = $calcular(substr($c, 0, 13), array(6,5,4,3,2,9,8,7,6,5,4,3,2));

    return ($d1 === (int) $c[12] && $d2 === (int) $c[13]);
}
