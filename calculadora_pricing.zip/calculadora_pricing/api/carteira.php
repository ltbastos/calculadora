<?php
/* ============================================================================
   GET api/carteira.php?email=…&q=texto&limite=50

   Os clientes de quem abriu a tela.

   Agrupado por CNPJ, e não por conta: o gerente pensa em "a Rota Norte", não
   em "a conta 0012345-6 da Rota Norte". As contas viajam junto, dentro de
   cada cliente, porque a simulação pode ser feita em qualquer nível.

   O filtro por gerente não é opcional nem parametrizável. Ele está grudado
   na consulta justamente para não existir um caminho que devolva a base
   inteira por descuido.
   ========================================================================== */

require __DIR__ . '/comum.php';

conferirManutencao();

$eu = exigirIdentidade();

$busca  = isset($_GET['q']) ? trim($_GET['q']) : '';
$limite = isset($_GET['limite']) ? (int) $_GET['limite'] : 60;
if ($limite < 1)   { $limite = 60; }
if ($limite > 500) { $limite = 500; }

$sql = 'SELECT cnpj, razao_social, nome_fantasia, agencia, conta, conta_exibicao,
               grupo_numero, grupo_nome, segmento, porte
          FROM encarteiramento
         WHERE ativo = 1
           AND (LOWER(gerente_email) = ? OR (gerente_funcional <> "" AND gerente_funcional = ?))';

$params = array($eu['email'], $eu['funcional']);

/* A busca aceita as quatro formas de procurar um cliente, porque cada
   gerente tem a sua: uns sabem o nome, outros têm o CNPJ do contrato na
   mão, outros o número da conta que está no extrato. */
if ($busca !== '') {
    $digitos = soDigitos($busca);

    $sql .= ' AND (razao_social LIKE ?
                OR nome_fantasia LIKE ?
                OR grupo_nome LIKE ?';
    $params[] = '%' . $busca . '%';
    $params[] = '%' . $busca . '%';
    $params[] = '%' . $busca . '%';

    if ($digitos !== '') {
        $sql .= ' OR cnpj LIKE ? OR conta LIKE ? OR grupo_numero = ?';
        $params[] = $digitos . '%';
        $params[] = '%' . $digitos . '%';
        $params[] = $digitos;
    }
    $sql .= ')';
}

$sql .= ' ORDER BY razao_social, conta LIMIT ' . (int) ($limite * 4);
/* x4 no limite do SQL porque o agrupamento por CNPJ acontece depois: um
   cliente com quatro contas ocupa quatro linhas aqui e uma só na saída. */

$linhas = consultar($sql, $params);

/* --- agrupa as contas dentro de cada CNPJ -------------------------------- */
$clientes = array();
$ordem = array();

foreach ($linhas as $l) {
    $cnpj = $l['cnpj'];

    if (!isset($clientes[$cnpj])) {
        if (count($ordem) >= $limite) { continue; }

        $clientes[$cnpj] = array(
            'cnpj'          => $cnpj,
            'cnpj_exibicao' => formatarCnpj($cnpj),
            'razao_social'  => $l['razao_social'],
            'nome_fantasia' => $l['nome_fantasia'],
            'grupo_numero'  => $l['grupo_numero'],
            'grupo_nome'    => $l['grupo_nome'],
            'segmento'      => $l['segmento'],
            'porte'         => $l['porte'],
            'contas'        => array(),
        );
        $ordem[] = $cnpj;
    }

    if ($l['conta'] !== null && $l['conta'] !== '') {
        $clientes[$cnpj]['contas'][] = array(
            'conta'     => $l['conta'],
            'agencia'   => $l['agencia'],
            'exibicao'  => $l['conta_exibicao'] !== null && $l['conta_exibicao'] !== ''
                           ? $l['conta_exibicao']
                           : trim($l['agencia'] . ' / ' . $l['conta']),
        );
    }
}

$saida = array();
foreach ($ordem as $cnpj) { $saida[] = $clientes[$cnpj]; }

responder(array(
    'ok'       => true,
    'total'    => count($saida),
    'truncado' => count($saida) >= $limite,
    'clientes' => $saida,
));
