<?php
/* ============================================================================
   Calculadora de Pricing PJ — o que todos os endpoints usam

   Conexão, resposta, normalização de texto e a leitura da identidade.

   ---------------------------------------------------------------------------
   UMA COISA IMPORTANTE SOBRE A IDENTIDADE, e ela vale a leitura:

   Esta página roda no Apache do XAMPP, não no IIS. Sem autenticação
   integrada do Windows, o servidor NÃO tem como saber quem está do outro
   lado — se perguntasse "quem é o usuário?", a resposta seria sempre o dono
   da máquina que hospeda o Apache, para todo mundo.

   Por isso quem autentica é o Power App: ele roda sob a conta de quem abre,
   sabe o e-mail real da pessoa e passa adiante na URL. Este arquivo apenas
   LÊ o que chegou.

   O que isso significa na prática, dito sem rodeio: a identidade é
   DECLARADA, não provada. Alguém que conheça o endereço pode trocar o
   e-mail na barra de endereços e ver a carteira de outro gerente. Duas
   coisas seguram esse risco:

     · a carteira é filtrada pelo e-mail no banco, então o estrago máximo é
       ver a carteira de quem a pessoa já sabe o e-mail — não a base inteira;
     · a tela de administração confere o e-mail contra a tabela app_admin,
       e mudar fator fica registrado em fator_historico com nome e e-mail.

   Se um dia isso não bastar, ligue ASSINATURA_SEGREDO em config/segredos.php
   e faça a identidade passar por um fluxo que saiba assinar. Está no
   DEPLOY.md.

   Compatível com PHP 5.6+.
   ========================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

/* Erro nunca vira HTML no meio do JSON: a tela não saberia ler. */
ini_set('display_errors', '0');
error_reporting(E_ALL);


/* ========================================================================= */
/*  resposta                                                                 */
/* ========================================================================= */

function responder($dados, $status = 200)
{
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* Um erro que a TELA consegue explicar para a pessoa. O 'motivo' é um código
   curto que o JavaScript reconhece; a 'mensagem' é o que aparece escrito. */
function erro($motivo, $mensagem, $status = 400)
{
    responder(array('ok' => false, 'motivo' => $motivo, 'mensagem' => $mensagem), $status);
}


/* ========================================================================= */
/*  segredos e conexão                                                       */
/* ========================================================================= */

function segredo($chave, $padrao = '')
{
    static $cofre = null;

    if ($cofre === null) {
        $caminho = __DIR__ . '/../config/segredos.php';
        $cofre = is_readable($caminho) ? include $caminho : array();
        if (!is_array($cofre)) { $cofre = array(); }
    }
    return array_key_exists($chave, $cofre) ? $cofre[$chave] : $padrao;
}

/* A conexão, aberta uma vez por requisição.

   ERRMODE_EXCEPTION porque erro silencioso de banco é o pior tipo: a tela
   mostraria zero em vez de avisar que não conseguiu ler. Melhor falhar alto.

   EMULATE_PREPARES desligado para o MySQL receber os tipos de verdade — sem
   isso, um LIMIT com parâmetro chega como string e o MariaDB recusa. */
function banco()
{
    static $pdo = null;
    if ($pdo !== null) { return $pdo; }

    $dsn = 'mysql:host=' . segredo('DB_HOST', '127.0.0.1')
         . ';port='      . segredo('DB_PORTA', '3306')
         . ';dbname='    . segredo('DB_NOME', 'calculadora_pricing')
         . ';charset=utf8mb4';

    try {
        $pdo = new PDO($dsn, segredo('DB_USER', 'root'), segredo('DB_SENHA', ''), array(
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ));
    } catch (PDOException $e) {
        /* A mensagem crua do PDO traz usuário e host do banco. Isso não vai
           para a tela de ninguém — fica no log do Apache. */
        error_log('[pricing] falha de conexao: ' . $e->getMessage());
        erro('sem-banco',
             'Não consegui falar com o banco de dados. Confira se o MySQL do XAMPP está ligado '
           . 'e se config/segredos.php existe (copie de config/segredos.exemplo.php).', 503);
    }

    return $pdo;
}

/* Atalho para consulta com parâmetros. Toda leitura do sistema passa por
   aqui, e por isso nenhuma concatena valor dentro do SQL. */
function consultar($sql, $params = array())
{
    $st = banco()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function consultarUm($sql, $params = array())
{
    $linhas = consultar($sql, $params);
    return count($linhas) ? $linhas[0] : null;
}

function executar($sql, $params = array())
{
    $st = banco()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
}


/* ========================================================================= */
/*  texto e números                                                          */
/* ========================================================================= */

/* Minúsculas e sem acento, para comparar o que o usuário digitou com o que
   está no banco sem depender de como cada um escreveu. */
function normalizar($s)
{
    $s = function_exists('mb_strtolower')
        ? mb_strtolower(trim((string) $s), 'UTF-8')
        : strtolower(trim((string) $s));

    $com = array('á','à','ã','â','ä','é','è','ê','í','ì','î','ó','ò','ô','õ','ö','ú','ù','û','ü','ç');
    $sem = array('a','a','a','a','a','e','e','e','i','i','i','o','o','o','o','o','u','u','u','u','c');
    return str_replace($com, $sem, $s);
}

/* Só os dígitos. É assim que CNPJ, conta e grupo entram na busca e é assim
   que estão guardados — ver o comentário da tabela fdados. */
function soDigitos($s)
{
    return preg_replace('/\D+/', '', (string) $s);
}

/* O número como ele chega da tela: pode vir "1.234.567,89" (digitado por
   gente) ou "1234567.89" (montado por código). Os dois viram float. */
function paraNumero($v)
{
    if (is_int($v) || is_float($v)) { return (float) $v; }

    $s = trim((string) $v);
    if ($s === '') { return 0.0; }

    /* Se tem vírgula, ela é o separador decimal e o ponto é de milhar.
       Sem vírgula, o ponto é o decimal — é o formato que o JavaScript manda. */
    if (strpos($s, ',') !== false) {
        $s = str_replace('.', '', $s);
        $s = str_replace(',', '.', $s);
    }
    $s = preg_replace('/[^0-9.\-]/', '', $s);

    return $s === '' ? 0.0 : (float) $s;
}

function textoOuNulo($v, $limite = 255)
{
    $s = trim((string) $v);
    if ($s === '') { return null; }
    return function_exists('mb_substr') ? mb_substr($s, 0, $limite, 'UTF-8') : substr($s, 0, $limite);
}

/* O corpo JSON de um POST. A tela manda tudo assim; formulário tradicional
   não é usado em lugar nenhum.

   Guardado em static porque duas partes leem o mesmo corpo: identidade(), que
   procura quem é o usuário, e o endpoint, que quer os dados. php://input é um
   fluxo — reler não é garantido em todo ambiente, e um corpo vazio na segunda
   leitura viraria "campos obrigatórios em branco" sem explicação nenhuma. */
function corpoJson()
{
    static $cache = null;
    if ($cache !== null) { return $cache; }

    $bruto = file_get_contents('php://input');
    if ($bruto === false || $bruto === '') { $cache = array(); return $cache; }

    $dados = json_decode($bruto, true);
    if (!is_array($dados)) {
        erro('json-invalido', 'O conteúdo enviado não é um JSON válido.', 400);
    }

    $cache = $dados;
    return $cache;
}


/* ========================================================================= */
/*  identidade                                                               */
/* ========================================================================= */

/* Lê quem é o usuário a partir do que veio na requisição.

   Aceita tanto na querystring (GET) quanto no corpo (POST), porque os dois
   caminhos existem: a tela carrega dados com GET e salva simulação com POST.

   Devolve sempre o mesmo formato, com e-mail em minúsculas — o banco guarda
   assim e maiúscula perdida no meio já custou tarde de gente. */
function identidade()
{
    static $eu = null;
    if ($eu !== null) { return $eu; }

    $corpo = array();
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $corpo = corpoJson();
        if (isset($corpo['usuario']) && is_array($corpo['usuario'])) {
            $corpo = $corpo['usuario'];
        }
    }

    $pegar = function ($chave) use ($corpo) {
        if (isset($_GET[$chave]) && trim($_GET[$chave]) !== '')  { return trim($_GET[$chave]); }
        if (isset($corpo[$chave]) && trim((string) $corpo[$chave]) !== '') { return trim((string) $corpo[$chave]); }
        return '';
    };

    $email = strtolower($pegar('email'));

    $eu = array(
        'nome'      => $pegar('nome'),
        'email'     => $email,
        'funcional' => soDigitos($pegar('funcional')),
        'cargo'     => $pegar('cargo'),
    );

    /* Assinatura, quando ligada em config/segredos.php. Ver o cabeçalho
       deste arquivo para o porquê de ela ser opcional. */
    $chaveHmac = segredo('ASSINATURA_SEGREDO', '');
    if ($chaveHmac !== '') {
        $assinatura = $pegar('sig');
        $esperado = hash_hmac('sha256', $eu['email'] . '|' . $eu['funcional'], $chaveHmac);

        /* hash_equals compara em tempo constante. Comparar hash com == abre
           brecha para descobrir o segredo medindo o tempo da resposta. */
        if ($assinatura === '' || !hash_equals($esperado, $assinatura)) {
            erro('assinatura-invalida',
                 'A identidade recebida não confere com a assinatura. Abra a ferramenta pelo caminho oficial.', 403);
        }
    }

    return $eu;
}

/* Exige que a pessoa esteja identificada. Todo endpoint que devolve dado de
   cliente chama isto na primeira linha. */
function exigirIdentidade()
{
    $eu = identidade();
    if ($eu['email'] === '' && $eu['funcional'] === '') {
        erro('sem-identidade',
             'Não sei quem é você. Abra a calculadora pelo atalho oficial, que passa a sua identificação.', 401);
    }
    return $eu;
}

/* Administrador é quem está em app_admin, e ponto. A tela também esconde o
   botão, mas esconder botão não é controle de acesso — o endpoint confere. */
function souAdmin()
{
    $eu = identidade();
    if ($eu['email'] === '') { return false; }

    $linha = consultarUm(
        'SELECT id FROM app_admin WHERE ativo = 1 AND LOWER(email) = ? LIMIT 1',
        array($eu['email'])
    );
    return $linha !== null;
}

function exigirAdmin()
{
    $eu = exigirIdentidade();
    if (!souAdmin()) {
        erro('sem-permissao',
             'Esta tela é restrita aos administradores da calculadora.', 403);
    }
    return $eu;
}


/* ========================================================================= */
/*  parâmetros                                                               */
/* ========================================================================= */

/* Todos os parâmetros de uma vez, em um array chave => valor. São poucos e
   a tela usa quase todos, então uma consulta só sai mais barato que várias. */
function parametros()
{
    static $cache = null;
    if ($cache !== null) { return $cache; }

    $cache = array();
    foreach (consultar('SELECT chave, valor FROM parametro') as $linha) {
        $cache[$linha['chave']] = $linha['valor'];
    }
    return $cache;
}

function parametro($chave, $padrao = null)
{
    $todos = parametros();
    return array_key_exists($chave, $todos) ? $todos[$chave] : $padrao;
}

function parametroNumero($chave, $padrao = 0)
{
    return paraNumero(parametro($chave, $padrao));
}

function parametroBooleano($chave, $padrao = false)
{
    $v = parametro($chave, $padrao ? '1' : '0');
    return $v === '1' || $v === 1 || $v === true || $v === 'true';
}


/* ========================================================================= */
/*  manutenção                                                               */
/* ========================================================================= */

/* Chamado no topo de cada endpoint. Durante uma carga de dados, é melhor a
   tela dizer "estamos carregando" do que mostrar meia base. */
function conferirManutencao()
{
    if (segredo('MANUTENCAO', false)) {
        erro('manutencao',
             segredo('MANUTENCAO_TEXTO', 'Ferramenta em manutenção. Tente novamente em alguns minutos.'),
             503);
    }
}


/* ========================================================================= */
/*  utilidades de apresentação                                               */
/* ========================================================================= */

/* 11222333000181 -> 11.222.333/0001-81
   Formatar aqui e não no JavaScript porque o CNPJ também sai em CSV e no
   texto do resumo, e um formato só evita três jeitos diferentes. */
function formatarCnpj($cnpj)
{
    $d = soDigitos($cnpj);
    if (strlen($d) !== 14) { return $cnpj; }

    return substr($d, 0, 2) . '.' . substr($d, 2, 3) . '.' . substr($d, 5, 3)
         . '/' . substr($d, 8, 4) . '-' . substr($d, 12, 2);
}

/* Protocolo curto e legível ao telefone: PRC-A7K2M9.
   Sem 0/O e 1/I no alfabeto, que são os que geram confusão ao ditar. */
function gerarProtocolo()
{
    $alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $saida = '';
    for ($i = 0; $i < 6; $i++) {
        $saida .= $alfabeto[mt_rand(0, strlen($alfabeto) - 1)];
    }
    return 'PRC-' . $saida;
}
