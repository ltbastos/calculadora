<?php
/* ============================================================================
   GET api/sessao.php?email=…&nome=…&funcional=…

   A primeira chamada que a tela faz. Devolve tudo que ela precisa para se
   montar: quem é a pessoa, se ela administra, o catálogo de produtos e os
   parâmetros.

   Vem tudo junto de propósito. Seriam quatro idas ao servidor para desenhar
   uma tela que não funciona sem as quatro — e quatro chances de a pessoa ver
   a tela montando aos pedaços.
   ========================================================================== */

require __DIR__ . '/comum.php';

conferirManutencao();

$eu = exigirIdentidade();

/* --- a carteira existe? --------------------------------------------------
   Não é controle de acesso, é orientação: quem não tem cliente nenhum
   precisa saber que o problema é a carga do encarteiramento, e não a
   ferramenta. Sem isso a pessoa fica procurando cliente que nunca vai achar. */
$carteira = consultarUm(
    'SELECT COUNT(*) AS total,
            COUNT(DISTINCT cnpj) AS cnpjs,
            COUNT(DISTINCT grupo_numero) AS grupos
       FROM encarteiramento
      WHERE ativo = 1
        AND (LOWER(gerente_email) = ? OR (gerente_funcional <> "" AND gerente_funcional = ?))',
    array($eu['email'], $eu['funcional'])
);

/* --- o catálogo ---------------------------------------------------------- */
$produtos = consultar(
    'SELECT codigo, nome, grupo, ordem, tipo_volume, tipo_fator, periodicidade,
            unidade, ajuda, fator, fator_piso, fator_teto
       FROM dim_produto
      WHERE ativo = 1
      ORDER BY ordem, nome'
);

/* Os números saem como número, não como string. O MySQL devolve DECIMAL em
   texto para não perder precisão, e no JavaScript "0.35" + 1 daria "0.351". */
foreach ($produtos as $i => $p) {
    $produtos[$i]['fator']      = (float) $p['fator'];
    $produtos[$i]['fator_piso'] = $p['fator_piso'] === null ? null : (float) $p['fator_piso'];
    $produtos[$i]['fator_teto'] = $p['fator_teto'] === null ? null : (float) $p['fator_teto'];
    $produtos[$i]['ordem']      = (int) $p['ordem'];
}

/* --- os parâmetros que a tela usa para calcular -------------------------- */
$cfg = parametros();

responder(array(
    'ok'      => true,
    'usuario' => array(
        'nome'      => $eu['nome'],
        'email'     => $eu['email'],
        'funcional' => $eu['funcional'],
        'admin'     => souAdmin(),
    ),
    'carteira' => array(
        'contas' => $carteira ? (int) $carteira['total']  : 0,
        'cnpjs'  => $carteira ? (int) $carteira['cnpjs']  : 0,
        'grupos' => $carteira ? (int) $carteira['grupos'] : 0,
    ),
    'produtos' => $produtos,
    'config'   => array(
        'titulo'               => isset($cfg['titulo_ferramenta'])    ? $cfg['titulo_ferramenta']    : 'Calculadora de Pricing',
        'subtitulo'            => isset($cfg['subtitulo_ferramenta']) ? $cfg['subtitulo_ferramenta'] : 'Pessoa Jurídica',
        'meses'                => (int) parametroNumero('meses_projecao', 12),
        'pctAprovado'          => parametroNumero('veredito_pct_aprovado', 15),
        'pctAtencao'           => parametroNumero('veredito_pct_atencao', 5),
        'prospectPisoAprovado' => parametroNumero('prospect_piso_aprovado', 5000),
        'prospectPisoAtencao'  => parametroNumero('prospect_piso_atencao', 1500),
        'permitirNegociar'     => parametroBooleano('permitir_negociar_fator', true),
        'alertaDivergenciaPct' => parametroNumero('alerta_divergencia_pct', 10),
    ),
));
