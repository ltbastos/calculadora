<?php
/* ============================================================================
   Calculadora de Pricing PJ — o motor de cálculo

   ---------------------------------------------------------------------------
   ESTE ARQUIVO TEM UM GÊMEO: src/motor.js

   A tela calcula enquanto a pessoa digita — se cada tecla fosse ao servidor,
   a experiência morria. Mas o servidor NÃO pode confiar no número que a tela
   mandou: quem salva uma simulação está gravando uma decisão comercial, e
   isso se recalcula aqui, do zero, a partir do volume digitado.

   Então a mesma conta existe duas vezes, de propósito. MEXEU AQUI, MEXA LÁ.
   O arquivo docs/CALCULO.md descreve a conta em português, e é o documento
   que vale quando os dois discordarem.

   ---------------------------------------------------------------------------
   A CONTA, em quatro linhas:

     1. Cada produto diz COMO cobra (tarifa por unidade ou taxa percentual)
        e em que PERIODICIDADE (mensal ou anual).
     2. Receita de uma linha = volume x fator, aplicado conforme o tipo.
     3. Projetado = o que o cliente já dá hoje + o que o incremento traz.
     4. O veredito compara projetado com atual e cai numa das três faixas.

   Compatível com PHP 5.6+.
   ========================================================================== */


/* ===========================================================================
   Uma linha: volume x fator, respeitando o tipo do produto.

   Devolve SEMPRE o par mensal/anual, mesmo para produto anual, para que
   qualquer soma depois consiga misturar produtos de periodicidades
   diferentes sem se perder. É por isso que TPV (anual) e Pix (mensal)
   conseguem entrar no mesmo total.
   ========================================================================= */
function pricingReceitaDaLinha($produto, $volume, $fator, $meses)
{
    $vazio = array('mes' => 0.0, 'ano' => 0.0);

    /* Contexto não é receita. Prazo de contrato entra na conversa, não na
       soma — ver o comentário de dim_produto no esquema. */
    if ($produto['tipo_volume'] === 'CONTEXTO' || $produto['tipo_fator'] === 'NENHUM') {
        return $vazio;
    }

    $volume = (float) $volume;
    $fator  = (float) $fator;
    if ($volume == 0.0 || $fator == 0.0) { return $vazio; }
    if ($meses <= 0) { $meses = 12; }

    /* TARIFA  -> o fator já está em reais por unidade.
       TAXA    -> o fator está em pontos percentuais; daí o /100.
                  0,35 quer dizer 0,35%, e não 35%. */
    $bruto = ($produto['tipo_fator'] === 'TARIFA')
        ? $volume * $fator
        : $volume * ($fator / 100.0);

    if ($produto['periodicidade'] === 'ANUAL') {
        /* O volume digitado já é o do ano inteiro (o caso do TPV). A receita
           calculada, portanto, também é anual — e o mensal sai dividindo. */
        return array(
            'mes' => round($bruto / $meses, 2),
            'ano' => round($bruto, 2),
        );
    }

    return array(
        'mes' => round($bruto, 2),
        'ano' => round($bruto * $meses, 2),
    );
}


/* ===========================================================================
   O fator que vale para esta linha.

   O gerente pode negociar, quando a área permite, mas nunca para fora do
   piso e do teto cadastrados. O limite é aplicado aqui, no servidor, e não
   só na tela: campo desabilitado no navegador é sugestão, não regra.
   ========================================================================= */
function pricingFatorEfetivo($produto, $fatorPedido, $podeNegociar)
{
    $padrao = (float) $produto['fator'];

    if (!$podeNegociar || $fatorPedido === null || $fatorPedido === '') {
        return array('fator' => $padrao, 'negociado' => false, 'ajustado' => false);
    }

    $pedido = (float) $fatorPedido;
    if ($pedido == $padrao) {
        return array('fator' => $padrao, 'negociado' => false, 'ajustado' => false);
    }

    $ajustado = false;

    if ($produto['fator_piso'] !== null && $pedido < (float) $produto['fator_piso']) {
        $pedido = (float) $produto['fator_piso'];
        $ajustado = true;
    }
    if ($produto['fator_teto'] !== null && $pedido > (float) $produto['fator_teto']) {
        $pedido = (float) $produto['fator_teto'];
        $ajustado = true;
    }
    if ($pedido < 0) { $pedido = 0.0; $ajustado = true; }

    return array(
        'fator'     => $pedido,
        'negociado' => ($pedido != $padrao),
        /* ajustado = o gerente pediu um fator fora da alçada e o motor puxou
           de volta para o limite. A tela avisa; o número não é silenciado. */
        'ajustado'  => $ajustado,
    );
}


/* ===========================================================================
   A simulação inteira.

   Entradas:
     $produtos   catálogo ativo, na ordem de exibição
     $atual      o que o cliente já tem hoje, indexado por código de produto:
                   array('invest_facil' => array('volume_atual'=>…, 'receita_atual'=>…))
     $entradas   o que o gerente digitou, indexado por código de produto:
                   array('invest_facil' => array('incremento'=>…, 'fator'=>…))
     $cfg        parâmetros já lidos do banco

   Saída: as linhas calculadas, os totais e o veredito.
   ========================================================================= */
function pricingCalcular($produtos, $atual, $entradas, $cfg)
{
    $meses         = isset($cfg['meses']) && $cfg['meses'] > 0 ? (int) $cfg['meses'] : 12;
    $podeNegociar  = !empty($cfg['permitirNegociar']);
    $margemAlerta  = isset($cfg['alertaDivergenciaPct']) ? (float) $cfg['alertaDivergenciaPct'] : 10.0;

    $linhas = array();

    $totalReceitaAtual      = 0.0;
    $totalReceitaIncremento = 0.0;
    $totalReceitaAno        = 0.0;
    $houveEntrada           = false;

    foreach ($produtos as $p) {
        $codigo = $p['codigo'];

        $hoje = isset($atual[$codigo]) ? $atual[$codigo] : null;
        $volumeAtual  = $hoje ? (float) $hoje['volume_atual']  : 0.0;
        $receitaAtual = $hoje ? (float) $hoje['receita_atual'] : 0.0;

        $entrada    = isset($entradas[$codigo]) ? $entradas[$codigo] : array();
        $incremento = isset($entrada['incremento']) ? (float) $entrada['incremento'] : 0.0;
        $fatorDito  = isset($entrada['fator']) && $entrada['fator'] !== '' ? $entrada['fator'] : null;

        $f = pricingFatorEfetivo($p, $fatorDito, $podeNegociar);

        /* O incremento rende pelo fator efetivo. O que o cliente já paga NÃO
           é recalculado: vem do banco como está, porque pode carregar acordo
           antigo ou condição especial que o fator padrão não reproduz. */
        $receitaIncremento = pricingReceitaDaLinha($p, $incremento, $f['fator'], $meses);

        /* Quanto o "hoje" renderia se fosse cobrado pela tabela de agora.
           Só serve para comparar e acender o alerta de divergência. */
        $receitaTabela = pricingReceitaDaLinha($p, $volumeAtual, (float) $p['fator'], $meses);

        $divergente = false;
        if ($receitaAtual > 0 && $receitaTabela['mes'] > 0) {
            $dif = abs($receitaAtual - $receitaTabela['mes']) / $receitaTabela['mes'] * 100.0;
            $divergente = ($dif > $margemAlerta);
        }

        $contexto = ($p['tipo_volume'] === 'CONTEXTO' || $p['tipo_fator'] === 'NENHUM');

        $receitaProjetadaMes = $contexto ? 0.0 : round($receitaAtual + $receitaIncremento['mes'], 2);
        $receitaProjetadaAno = $contexto ? 0.0 : round($receitaProjetadaMes * $meses, 2);

        /* Produto anual já tem o ano calculado direto do volume anual; passar
           pelo x12 do mensal introduziria o erro de arredondamento da divisão
           feita lá em cima. */
        if (!$contexto && $p['periodicidade'] === 'ANUAL') {
            $receitaProjetadaAno = round(($receitaAtual * $meses) + $receitaIncremento['ano'], 2);
        }

        if ($incremento != 0.0) { $houveEntrada = true; }

        $linhas[] = array(
            'codigo'              => $codigo,
            'nome'                => $p['nome'],
            'grupo'               => $p['grupo'],
            'tipo_volume'         => $p['tipo_volume'],
            'tipo_fator'          => $p['tipo_fator'],
            'periodicidade'       => $p['periodicidade'],
            'unidade'             => $p['unidade'],
            'contexto'            => $contexto,

            'volume_atual'        => $volumeAtual,
            'receita_atual'       => round($receitaAtual, 2),

            'incremento'          => $incremento,
            'fator_padrao'        => (float) $p['fator'],
            'fator_usado'         => $f['fator'],
            'fator_negociado'     => $f['negociado'],
            'fator_ajustado'      => $f['ajustado'],

            'receita_incremento'  => $receitaIncremento['mes'],
            'receita_projetada'   => $receitaProjetadaMes,
            'receita_ano'         => $receitaProjetadaAno,
            'divergente'          => $divergente,
        );

        if (!$contexto) {
            $totalReceitaAtual      += round($receitaAtual, 2);
            $totalReceitaIncremento += $receitaIncremento['mes'];
            $totalReceitaAno        += $receitaProjetadaAno;
        }
    }

    /* Somar os valores JÁ arredondados, e não arredondar a soma no fim.
       Assim o total da tela é exatamente a soma das linhas que a pessoa vê —
       e ninguém precisa explicar um centavo de diferença numa reunião. */
    $totalReceitaAtual      = round($totalReceitaAtual, 2);
    $totalReceitaIncremento = round($totalReceitaIncremento, 2);
    $totalProjetadaMes      = round($totalReceitaAtual + $totalReceitaIncremento, 2);
    $totalReceitaAno        = round($totalReceitaAno, 2);

    $variacao = ($totalReceitaAtual > 0)
        ? round($totalReceitaIncremento / $totalReceitaAtual * 100.0, 4)
        : 0.0;

    $veredito = pricingVeredito(
        $totalReceitaAtual, $totalProjetadaMes, $totalReceitaIncremento, $variacao, $houveEntrada, $cfg
    );

    return array(
        'linhas' => $linhas,
        'totais' => array(
            'receita_atual_mes'     => $totalReceitaAtual,
            'receita_incremento_mes'=> $totalReceitaIncremento,
            'receita_projetada_mes' => $totalProjetadaMes,
            'receita_ano'           => $totalReceitaAno,
            'variacao_pct'          => $variacao,
            'houve_entrada'         => $houveEntrada,
            'meses'                 => $meses,
        ),
        'veredito' => $veredito,
    );
}


/* ===========================================================================
   O veredito

   Dois caminhos, porque são duas perguntas diferentes:

     CLIENTE QUE JÁ RENDE  "cresceu o suficiente?"   -> régua percentual
     CLIENTE QUE NÃO RENDE "vale abrir?"             -> régua em reais

   O segundo caminho não é detalhe: prospect e cliente sem produto contratado
   têm receita atual zero, e percentual sobre zero não existe. Sem régua
   própria, todo cliente novo cairia no mesmo veredito sem sentido.
   ========================================================================= */
function pricingVeredito($atual, $projetado, $incremento, $variacao, $houveEntrada, $cfg)
{
    if (!$houveEntrada) {
        return array(
            'status'  => 'VAZIO',
            'titulo'  => 'Aguardando a proposta',
            'texto'   => 'Preencha o que o cliente traz na negociação para ver o resultado.',
            'regua'   => '',
        );
    }

    $pctAprovado = isset($cfg['pctAprovado']) ? (float) $cfg['pctAprovado'] : 15.0;
    $pctAtencao  = isset($cfg['pctAtencao'])  ? (float) $cfg['pctAtencao']  : 5.0;
    $pisoAprovado = isset($cfg['prospectPisoAprovado']) ? (float) $cfg['prospectPisoAprovado'] : 5000.0;
    $pisoAtencao  = isset($cfg['prospectPisoAtencao'])  ? (float) $cfg['prospectPisoAtencao']  : 1500.0;

    /* ---- caminho do cliente novo, ou sem receita hoje -------------------- */
    if ($atual <= 0) {
        if ($projetado >= $pisoAprovado) {
            return array(
                'status' => 'APROVADO',
                'titulo' => 'Vale a pena',
                'texto'  => 'Cliente sem receita hoje. A proposta gera ' . pricingDinheiro($projetado)
                          . ' por mês, acima do mínimo de ' . pricingDinheiro($pisoAprovado) . '.',
                'regua'  => 'Régua de cliente novo: mínimo de ' . pricingDinheiro($pisoAprovado) . '/mês.',
            );
        }
        if ($projetado >= $pisoAtencao) {
            return array(
                'status' => 'ATENCAO',
                'titulo' => 'Precisa de análise',
                'texto'  => 'A proposta gera ' . pricingDinheiro($projetado) . ' por mês. Fica entre o mínimo '
                          . 'aceitável de ' . pricingDinheiro($pisoAtencao) . ' e o ideal de '
                          . pricingDinheiro($pisoAprovado) . '.',
                'regua'  => 'Régua de cliente novo: ideal ' . pricingDinheiro($pisoAprovado)
                          . '/mês, mínimo ' . pricingDinheiro($pisoAtencao) . '/mês.',
            );
        }
        return array(
            'status' => 'REPROVADO',
            'titulo' => 'Não compensa',
            'texto'  => 'A proposta gera ' . pricingDinheiro($projetado) . ' por mês, abaixo do mínimo de '
                      . pricingDinheiro($pisoAtencao) . ' para abrir relacionamento.',
            'regua'  => 'Régua de cliente novo: mínimo ' . pricingDinheiro($pisoAtencao) . '/mês.',
        );
    }

    /* ---- caminho do cliente que já rende --------------------------------- */
    $pct = pricingPercentual($variacao);

    if ($variacao >= $pctAprovado) {
        return array(
            'status' => 'APROVADO',
            'titulo' => 'Vale a pena',
            'texto'  => 'A receita cresce ' . $pct . ', o equivalente a ' . pricingDinheiro($incremento)
                      . ' a mais por mês. Acima da meta de ' . pricingPercentual($pctAprovado) . '.',
            'regua'  => 'Régua: crescimento de ' . pricingPercentual($pctAprovado) . ' sobre a receita atual.',
        );
    }
    if ($variacao >= $pctAtencao) {
        return array(
            'status' => 'ATENCAO',
            'titulo' => 'Precisa de análise',
            'texto'  => 'A receita cresce ' . $pct . ' (' . pricingDinheiro($incremento) . ' por mês). '
                      . 'Fica abaixo da meta de ' . pricingPercentual($pctAprovado) . ', mas acima do mínimo de '
                      . pricingPercentual($pctAtencao) . '.',
            'regua'  => 'Régua: meta ' . pricingPercentual($pctAprovado) . ', mínimo '
                      . pricingPercentual($pctAtencao) . '.',
        );
    }
    return array(
        'status' => 'REPROVADO',
        'titulo' => 'Não compensa',
        'texto'  => 'A receita cresce apenas ' . $pct . ' (' . pricingDinheiro($incremento) . ' por mês), '
                  . 'abaixo do mínimo de ' . pricingPercentual($pctAtencao) . '.',
        'regua'  => 'Régua: mínimo de ' . pricingPercentual($pctAtencao) . ' de crescimento.',
    );
}


/* ===========================================================================
   Formatação para os textos do veredito

   Ficam aqui, e não no JavaScript, porque esses textos também vão para o
   banco (simulacao.veredito_texto) e para o resumo copiado. Um lugar só.
   ========================================================================= */
function pricingDinheiro($v)
{
    return 'R$ ' . number_format((float) $v, 2, ',', '.');
}

function pricingPercentual($v)
{
    $v = (float) $v;
    /* Casa decimal só quando ela diz alguma coisa: "15%" lê melhor que
       "15,0%", mas "5,4%" não pode virar "5%". */
    $casas = (abs($v - round($v)) < 0.05) ? 0 : 1;
    return number_format($v, $casas, ',', '.') . '%';
}


/* ===========================================================================
   Os parâmetros do motor, lidos do banco no formato que pricingCalcular quer
   ========================================================================= */
function pricingConfig()
{
    return array(
        'meses'                => (int) parametroNumero('meses_projecao', 12),
        'pctAprovado'          => parametroNumero('veredito_pct_aprovado', 15),
        'pctAtencao'           => parametroNumero('veredito_pct_atencao', 5),
        'prospectPisoAprovado' => parametroNumero('prospect_piso_aprovado', 5000),
        'prospectPisoAtencao'  => parametroNumero('prospect_piso_atencao', 1500),
        'permitirNegociar'     => parametroBooleano('permitir_negociar_fator', true),
        'alertaDivergenciaPct' => parametroNumero('alerta_divergencia_pct', 10),
    );
}
