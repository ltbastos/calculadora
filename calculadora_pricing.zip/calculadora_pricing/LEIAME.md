# Calculadora de Pricing PJ

Ferramenta interna para simular o que uma negociação com um cliente pessoa
jurídica traria de receita, e dizer se vale a pena.

O gerente digita um CNPJ, uma conta ou um número de grupo econômico. A
ferramenta traz o que o cliente já rende hoje, produto a produto, e abre uma
coluna para ele preencher o que o cliente promete trazer. O resultado aparece
**enquanto se digita** — receita nova, incremento, projeção do ano e o
veredito.

---

## Como isso se monta

```
index.html          a calculadora
admin.html          a tela onde a área mexe nos fatores

src/config.js       O ÚNICO ARQUIVO A EDITAR ao levar para o trabalho
src/identity.js     descobre quem é o usuário (ver docs/IDENTIFICACAO.md)
src/formato.js      lê e escreve número em português
src/motor.js        o cálculo, versão da tela
src/app.js          a calculadora
src/admin.js        a administração

api/comum.php       conexão, identidade, resposta
api/motor.php       o cálculo, versão do servidor  ← gêmeo de src/motor.js
api/sessao.php      quem sou, catálogo e parâmetros
api/carteira.php    os clientes do gerente
api/cliente.php     a busca por CNPJ / conta / grupo
api/simulacao.php   grava e lista simulações
api/admin.php       lê e grava fatores e régua

banco/              os scripts SQL, na ordem 01, 02, 03
config/             credenciais do banco (não vai para o Git)
docs/               a conta explicada e o guia de identificação
testes/             a comparação entre os dois motores
mock/               o perfil fictício do modo de desenvolvimento
```

---

## Rodar na sua máquina

### 1. A pasta precisa estar sem acento no caminho

Isto não é preciosismo:

> **O PHP 7.1 no Windows não abre arquivos em caminhos com acento.**
> Em `C:\Users\...\Área de Trabalho\...` o `require` falha com "No such file
> or directory", e a tela morre sem explicação.

Então o lugar de rodar é o `htdocs`:

```
C:\xampp\htdocs\calculadora_pricing
```

Se você edita no OneDrive (que tem "Área de Trabalho" no caminho), use o
script de sincronização depois de cada mudança:

```
sincronizar.cmd
```

Ele copia a pasta inteira para o `htdocs`, preservando `config/segredos.php`.

### 2. Ligar o XAMPP

Abra o painel do XAMPP e ligue **Apache** e **MySQL**.

### 3. Criar o banco

No phpMyAdmin (`http://localhost/phpmyadmin`) ou no terminal, rode na ordem:

```
banco/01-esquema.sql     as tabelas
banco/02-produtos.sql    o catálogo e a régua do veredito
banco/03-exemplo.sql     cinco clientes fictícios, para ver a tela funcionando
```

Pelo terminal:

```
C:\xampp\mysql\bin\mysql -u root < banco\01-esquema.sql
C:\xampp\mysql\bin\mysql -u root < banco\02-produtos.sql
C:\xampp\mysql\bin\mysql -u root < banco\03-exemplo.sql
```

### 4. As credenciais

Copie `config/segredos.exemplo.php` para `config/segredos.php`. No XAMPP
recém-instalado não precisa mudar nada: usuário `root`, senha vazia.

### 5. Seu e-mail

Em `mock/perfil.json`, troque o e-mail pelo seu — ele precisa bater com
`gerente_email` na tabela `encarteiramento` para a carteira aparecer.

O `banco/03-exemplo.sql` já vem com `luantbastos@gmail.com`; se mudar em um,
mude no outro.

### 6. Abrir

```
http://localhost/calculadora_pricing/
```

---

## O que testar primeiro

O `03-exemplo.sql` foi montado para exercitar os quatro casos que a
calculadora precisa acertar. Vale passar por todos:

| Digite | O que deve acontecer |
|---|---|
| `11222333000181` | cliente grande, R$ 47.190 de receita. A régua fica exigente |
| `6692` | grupo econômico — e a tela oferece "ver no CNPJ" |
| `00345678` | uma conta, com atalho para subir ao CNPJ e ao grupo |
| `44555666000154` | é cliente do banco, mas sem produto nenhum: cai na régua de prospect |
| `19131243000197` | CNPJ válido fora da base: prospect, simulação do zero |
| `11222333000199` | CNPJ com dígito errado: a tela recusa antes de simular |

---

## Os dois motores precisam concordar

O cálculo existe duas vezes: `src/motor.js` calcula na tela a cada tecla,
`api/motor.php` recalcula na hora de gravar. Se divergirem, a pessoa vê um
número na tela e outro no comprovante — e descobre isso na frente do cliente.

Depois de mexer em **qualquer um dos dois**, rode:

```
node testes/gemeos.js
```

São 14 cenários, incluindo produto anual, linha de contexto, prospect,
alçada de fator e arredondamento de centavos. O Node é usado só pelo teste;
a aplicação não depende dele para nada.

---

## Mexer nos fatores

Não se mexe no código nem no SQL. Quem administra abre `admin.html` e edita
na tela — fator, piso, teto, nome, grupo, e a régua do veredito.

Toda alteração vira registro em `fator_historico`, com quem mudou, de quanto
para quanto, quando e por quê. Fator é preço; preço sem rastro vira
discussão.

Para alguém poder abrir essa tela, o e-mail precisa estar em `app_admin`:

```sql
INSERT INTO app_admin (email, nome, ativo, criado_em)
VALUES ('fulano@bradesco.com.br', 'Fulano', 1, NOW());
```

---

## Para levar ao trabalho

Leia `DEPLOY.md`. O resumo:

1. `src/config.js` → `MODO: 'powerapps'` e a URL do app
2. `config/segredos.php` → o banco de lá
3. as três tabelas de carga vêm da fonte real, não do `03-exemplo.sql`
4. `banco/02-produtos.sql` roda uma vez; depois é tudo pela tela de fatores

E `docs/IDENTIFICACAO.md` explica, com passo a passo, por que a identificação
passa pelo Power Apps e não pelo Power Automate.

---

## Decisões que valem saber

**Sem framework, sem build, sem npm.** O arquivo que você escreve é o que
roda no servidor. Quando algo quebrar numa sexta às 18h, dá para abrir no
Bloco de Notas e consertar.

**Sem CDN.** Fontes e ícones são locais, porque a máquina do trabalho pode
não ter saída para a internet.

**O vermelho não é a cor de trabalho.** Numa calculadora que dá veredito,
verde, âmbar e vermelho precisam significar só isso. O azul-petróleo é a cor
funcional; a marca aparece no filete do topo. Está explicado no começo de
`assets/theme.css`.

**Um botão só para fechar a simulação.** "Salvar em PDF" registra no banco e
gera o documento na mesma ação. Dois botões — um de salvar, outro de salvar
em PDF — obrigariam a uma escolha que ninguém sabe fazer, e abririam a porta
para o caso pior: o PDF na mão do cliente sem registro nenhum do lado de cá.
O protocolo sai impresso no papel, e é por ele que se reencontra a simulação
meses depois.

**O PDF é um documento próprio, não a tela impressa.** A tela tem catorze
produtos e campos de digitação; o papel tem uma página com o que sobreviveu à
negociação. Entram só as linhas com história — as que o cliente já usa ou vai
passar a usar. É o corte que faz tudo caber numa folha só. Ver `montarFolha()`
em `src/app.js` e o bloco `.folha` em `assets/theme.css`.

**A receita de hoje nunca é recalculada.** Vem do banco como está, porque
pode carregar acordo antigo que o fator padrão não reproduz. Quando ela não
bate com a tabela, a tela sinaliza em vez de corrigir — essa diferença
costuma ser o assunto da reunião.
