/* ============================================================================
   Adaptador de entrada — descobre quem é o usuário.

   Trocar de ambiente = trocar PRICING_CONFIG.MODO. Nada aqui precisa mudar.

   ---------------------------------------------------------------------------
   POR QUE O POWER AUTOMATE GRATUITO NÃO RESOLVE ISSO

   Vale a leitura antes de tentar, porque a conclusão não é óbvia e custa uma
   tarde para descobrir sozinho.

   Para esta página perguntar algo a um fluxo, o fluxo precisa de um GATILHO
   que atenda uma chamada HTTP — o "Quando uma solicitação HTTP é recebida".
   Esse gatilho é premium. As ações chamadas "Enviar uma solicitação HTTP",
   que aparecem em vários conectores da lista gratuita, são o contrário: elas
   fazem o FLUXO chamar alguém de fora. Não servem para alguém de fora chamar
   o fluxo.

   E mesmo com o premium não resolveria, por um motivo mais fundo: um fluxo
   acionado por HTTP roda sob a identidade de QUEM CRIOU o fluxo. Se ele
   chamasse "Obter meu perfil (V2)", devolveria sempre o perfil do dono — o
   mesmo nome para todo mundo que abrisse a página. O fluxo não tem como
   saber quem chamou, porque a única coisa que poderia contar isso a ele é
   justamente o que estamos tentando descobrir.

   O Power Apps resolve porque é o oposto: o app roda sob a identidade de
   QUEM ABRE. User().Email é a pessoa de verdade, sem conector nenhum e sem
   licença premium. É por isso que 'powerapps' é o caminho recomendado.

   O modo 'flow' fica implementado mesmo assim — um dia pode existir premium,
   e nesse dia o fluxo teria que receber o token do Entra ID por cabeçalho.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PRICING_CONFIG;

  /* Lê a identidade que o Power App deixou na URL:
       ?nome=...&email=...&funcional=...&cargo=...                           */
  function daUrl() {
    var q = new URLSearchParams(window.location.search);
    var P = CFG.PARAMS;

    var email = (q.get(P.email) || '').trim();
    if (!email) { return null; }

    return {
      nome:      (q.get(P.nome)      || '').trim(),
      email:     email.toLowerCase(),
      funcional: (q.get(P.funcional) || '').trim(),
      cargo:     (q.get(P.cargo)     || '').trim(),
      sig:       (q.get(P.sig)       || '').trim()
    };
  }

  function buscarJson(url) {
    return fetch(url, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) { throw new Error('HTTP ' + r.status + ' em ' + url); }
      return r.json();
    });
  }

  window.Identidade = {

    /* Resolve quem é. Devolve sempre um destes dois formatos:
         { ok: true,  usuario: {nome, email, funcional, cargo, sig} }
         { ok: false, motivo: 'sem-identidade' | 'falhou', detalhe: '...' }  */
    resolver: function () {
      var modo = CFG.MODO;

      /* Mesmo em produção, a URL tem prioridade: é assim que o Power App
         entrega, e é assim que se testa outra pessoa sem mudar o modo. */
      var naUrl = daUrl();
      if (naUrl) { return Promise.resolve({ ok: true, usuario: naUrl }); }

      if (modo === 'mock') {
        return buscarJson(CFG.PERFIL_MOCK_URL).then(function (d) {
          return {
            ok: true,
            usuario: {
              nome:      d.nome      || '',
              email:     (d.email    || '').toLowerCase(),
              funcional: d.funcional || '',
              cargo:     d.cargo     || '',
              sig:       ''
            }
          };
        }).catch(function (e) {
          return { ok: false, motivo: 'falhou', detalhe: e.message };
        });
      }

      if (modo === 'powerapps') {
        /* Chegou aqui sem nada na URL: a pessoa abriu o endereço direto, em
           vez de passar pelo Power App. A tela explica e oferece o caminho. */
        return Promise.resolve({ ok: false, motivo: 'sem-identidade' });
      }

      if (modo === 'flow') {
        if (!CFG.FLOW_URL) {
          return Promise.resolve({
            ok: false, motivo: 'falhou',
            detalhe: 'MODO "flow" exige FLOW_URL preenchida em src/config.js.'
          });
        }
        return buscarJson(CFG.FLOW_URL).then(function (d) {
          if (!d || !d.email) { throw new Error('O fluxo respondeu sem e-mail.'); }
          return {
            ok: true,
            usuario: {
              nome:      d.nome      || d.displayName || '',
              email:     (d.email    || d.mail || '').toLowerCase(),
              funcional: d.funcional || d.employeeId || '',
              cargo:     d.cargo     || d.jobTitle || '',
              sig:       d.sig       || ''
            }
          };
        }).catch(function (e) {
          return { ok: false, motivo: 'falhou', detalhe: e.message };
        });
      }

      return Promise.resolve({
        ok: false, motivo: 'falhou',
        detalhe: 'MODO desconhecido em src/config.js: ' + modo
      });
    },

    /* Os campos de identidade prontos para entrar numa querystring. Todo
       endpoint precisa deles, então vale ter num lugar só. */
    comoParams: function (usuario) {
      var p = new URLSearchParams();
      p.set('email',     usuario.email     || '');
      p.set('nome',      usuario.nome      || '');
      p.set('funcional', usuario.funcional || '');
      if (usuario.cargo) { p.set('cargo', usuario.cargo); }
      if (usuario.sig)   { p.set('sig',   usuario.sig); }
      return p;
    }
  };
})();
