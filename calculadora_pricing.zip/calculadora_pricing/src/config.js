/* ============================================================================
   Calculadora de Pricing PJ — configuração

   ESTE É O ÚNICO ARQUIVO QUE VOCÊ PRECISA EDITAR ao levar para o trabalho.
   (O outro é config/segredos.php, com a senha do banco — mas esse o Apache
   nunca entrega para o navegador.)
   ========================================================================== */

window.PRICING_CONFIG = {

  /* --------------------------------------------------------------------------
     MODO — de onde vem a identidade de quem abriu a página.

       'mock'      desenvolvimento na sua máquina. Lê mock/perfil.json.
                   Troque o e-mail de lá para testar carteiras diferentes.

       'powerapps' produção. O Power App autentica, descobre quem é a pessoa
                   e abre esta página passando os dados na URL.

       'flow'      a página pergunta a um fluxo do Power Automate quem é o
                   usuário. NÃO FUNCIONA com licença gratuita, e o motivo
                   está escrito por extenso em src/identity.js — leia antes
                   de tentar. Fica aqui pronto caso um dia haja premium.

     Por que a página nunca descobre isso sozinha: ela roda no Apache do
     XAMPP, não no IIS. Sem autenticação integrada do Windows, perguntar ao
     servidor "quem é o usuário?" devolveria sempre o dono da máquina que
     hospeda — o mesmo nome para todo mundo.
     ------------------------------------------------------------------------ */
  MODO: 'mock',

  /* --------------------------------------------------------------------------
     O link do Power App, usado quando MODO = 'powerapps'.

     Copie de: Power Apps > seu app > ... > Detalhes > URL da Web.
     Serve para a tela oferecer "abrir pelo caminho certo" quando alguém
     chegar aqui direto, sem identificação.
     ------------------------------------------------------------------------ */
  POWERAPP_URL: 'https://apps.powerapps.com/play/e/SEU-AMBIENTE/a/SEU-APP-ID',

  /* Endpoint do fluxo, usado quando MODO = 'flow'. */
  FLOW_URL: '',

  /* --------------------------------------------------------------------------
     Os parâmetros que o Power App põe na URL.

     Um parâmetro por campo, de propósito: o Power Fx não tem função para
     codificar nem decodificar base64, então um payload empacotado obrigaria
     a gambiarra dos dois lados. Assim o Power App monta a URL com EncodeUrl()
     e esta página lê com URLSearchParams — que é o caminho suportado.
     ------------------------------------------------------------------------ */
  PARAMS: {
    nome:      'nome',
    email:     'email',
    funcional: 'funcional',
    cargo:     'cargo',
    /* Assinatura, só quando ASSINATURA_SEGREDO estiver ligado no PHP. */
    sig:       'sig'
  },

  /* --------------------------------------------------------------------------
     Onde ficam os endpoints. Caminho relativo: a pasta pode ser renomeada ou
     movida dentro do htdocs sem ninguém mexer aqui.
     ------------------------------------------------------------------------ */
  API: {
    sessao:    'api/sessao.php',
    carteira:  'api/carteira.php',
    cliente:   'api/cliente.php',
    simulacao: 'api/simulacao.php',
    admin:     'api/admin.php'
  },

  /* Perfil fictício usado quando MODO = 'mock'. */
  PERFIL_MOCK_URL: 'mock/perfil.json',

  /* --------------------------------------------------------------------------
     Quantos clientes a lista da carteira mostra de uma vez. A carteira real
     de um gerente PJ passa fácil de 300 — a busca é que resolve, e não uma
     lista gigante que ninguém rola até o fim.
     ------------------------------------------------------------------------ */
  CARTEIRA_QUANTOS: 60,

  /* Quantas simulações recentes aparecem na tela inicial. */
  HISTORICO_QUANTOS: 8,

  /* --------------------------------------------------------------------------
     Quanto tempo a tela espera antes de recalcular depois de uma tecla.

     Zero seria recalcular a cada dígito: com 14 produtos a conta é
     instantânea, então o custo não é a máquina — é a leitura. O número do
     painel piscando a cada tecla enquanto alguém digita "1500000" cansa.
     120ms é o intervalo em que a pessoa termina de digitar e o número já
     está lá quando ela olha.
     ------------------------------------------------------------------------ */
  ESPERA_CALCULO: 120,

  /* Segundos que o recado flutuante fica na tela. */
  RECADO_SEGUNDOS: 4
};
