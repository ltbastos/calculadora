/* ============================================================================
   Calculadora de Pricing PJ — tela de administração

   Aqui a área responsável mexe nos fatores sem pedir nada para a TI. É o
   ponto do projeto em que "fácil de mudar" deixa de ser promessa.

   ---------------------------------------------------------------------------
   TRÊS DECISÕES QUE MOLDAM ESTA TELA:

   1. NADA SALVA SOZINHO. A pessoa edita à vontade, vê as linhas mexidas
      ficarem marcadas, e só então salva tudo de uma vez. Salvar a cada tecla
      num campo de PREÇO seria gravar meio número — "2,4" a caminho de "2,45"
      é uma tarifa válida e errada.

   2. O QUE MUDOU FICA VISÍVEL. Linha alterada ganha fundo e barra lateral, e
      o rodapé conta quantas são. Sem isso, quem mexeu em três campos no meio
      de catorze produtos não tem como conferir antes de gravar.

   3. SAIR COM ALTERAÇÃO PENDENTE AVISA. É o único jeito de impedir que meia
      hora de trabalho vá embora num fechar de aba sem querer.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PRICING_CONFIG;
  var Fmt = window.Fmt;

  var S = {
    usuario: null,
    produtos: [],     /* como veio do servidor — a base de comparação   */
    edicao: {},       /* o que está na tela agora, por código           */
    parametros: [],
    paramEdicao: {},
    salvando: false
  };

  window.__pricingAdmin = S;


  /* ===================================================== atalhos de DOM === */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function el(tag, classe, texto) {
    var n = document.createElement(tag);
    if (classe) { n.className = classe; }
    if (texto !== undefined && texto !== null) { n.textContent = texto; }
    return n;
  }

  function icone(nome, classe) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'ic' + (classe ? ' ' + classe : ''));
    svg.setAttribute('aria-hidden', 'true');
    var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#' + nome);
    svg.appendChild(use);
    return svg;
  }

  function mostrar(n, sim) { if (n) { n.hidden = !sim; } }
  function limpar(n) { while (n && n.firstChild) { n.removeChild(n.firstChild); } }


  /* ======================================================= progresso ====== */
  var progresso = { barra: null, contador: 0 };

  function comecouAlgo() {
    progresso.contador++;
    if (progresso.barra) { progresso.barra.className = 'progresso andando'; }
  }
  function acabouAlgo() {
    progresso.contador = Math.max(0, progresso.contador - 1);
    if (progresso.contador === 0 && progresso.barra) {
      progresso.barra.className = 'progresso pronto';
      setTimeout(function () {
        if (progresso.contador === 0) { progresso.barra.className = 'progresso'; }
      }, 300);
    }
  }

  var recadoTimer = null;
  function recado(texto, tipo) {
    var caixa = $('#recado');
    limpar(caixa);
    caixa.className = 'recado' + (tipo ? ' recado--' + tipo : '');
    caixa.appendChild(icone(tipo === 'erro' ? 'i-alert' : 'i-check-circle'));
    caixa.appendChild(el('span', null, texto));
    void caixa.offsetWidth;
    caixa.classList.add('aberto');

    clearTimeout(recadoTimer);
    recadoTimer = setTimeout(function () { caixa.classList.remove('aberto'); },
      (CFG.RECADO_SEGUNDOS || 4) * 1000);
  }


  /* ============================================================= API ====== */
  function pegar(url) {
    comecouAlgo();
    var p = window.Identidade.comoParams(S.usuario);
    return fetch(url + '?' + p.toString(), { cache: 'no-store' })
      .then(lerResposta)
      .then(function (d) { acabouAlgo(); return d; })
      .catch(function (e) { acabouAlgo(); throw e; });
  }

  function mandar(url, corpo) {
    comecouAlgo();
    corpo.usuario = S.usuario;
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(corpo)
    })
      .then(lerResposta)
      .then(function (d) { acabouAlgo(); return d; })
      .catch(function (e) { acabouAlgo(); throw e; });
  }

  function lerResposta(r) {
    return r.text().then(function (txt) {
      var d;
      try { d = JSON.parse(txt); }
      catch (e) {
        throw { motivo: 'resposta-invalida',
                mensagem: 'O servidor respondeu algo que não é JSON (HTTP ' + r.status + '). '
                        + 'Confira o log do Apache.' };
      }
      if (!r.ok || d.ok === false) {
        throw { motivo: d.motivo || 'erro', mensagem: d.mensagem || ('Erro HTTP ' + r.status + '.') };
      }
      return d;
    });
  }

  function explicarErro(e) {
    if (e && e.mensagem) { return e.mensagem; }
    if (e && e.message) {
      if (/fetch|network/i.test(e.message)) {
        return 'Não consegui falar com o servidor. Confira se o Apache do XAMPP está ligado.';
      }
      return e.message;
    }
    return 'Algo deu errado.';
  }


  /* ========================================================= arranque ===== */
  function iniciar() {
    progresso.barra = $('#progresso');

    window.Identidade.resolver().then(function (r) {
      if (!r.ok) { return bloquear('Preciso saber quem é você', 'Abra esta tela pelo atalho oficial.'); }

      S.usuario = r.usuario;
      $('#eu-nome').textContent = S.usuario.nome || S.usuario.email;
      $('#eu-inicial').textContent = Fmt.iniciais(S.usuario.nome || S.usuario.email);

      return pegar(CFG.API.admin).then(function (d) {
        S.produtos   = d.produtos || [];
        S.parametros = d.parametros || [];

        montarProdutos();
        montarParametros();
        montarHistorico(d.historico || []);
        montarAdmins(d.admins || []);

        ligarEventos();
        mostrar($('#app'), true);
      });

    }).catch(function (e) {
      if (e && e.motivo === 'sem-permissao') {
        bloquear('Tela restrita',
          'Só quem está na lista de administradores da calculadora pode mexer nos fatores. '
        + 'Se você deveria estar nessa lista, peça a inclusão do seu e-mail na tabela app_admin.');
      } else {
        bloquear('Não consegui abrir', explicarErro(e));
      }
    });
  }

  function bloquear(titulo, texto) {
    mostrar($('#app'), false);
    mostrar($('#bloqueio'), true);
    $('#bloqueio-titulo').textContent = titulo;
    $('#bloqueio-texto').textContent = texto;
  }


  /* ================================================ tabela de produtos ==== */
  function montarProdutos() {
    var corpo = $('#prod-tbody');
    limpar(corpo);
    S.edicao = {};

    S.produtos.forEach(function (p) {
      S.edicao[p.codigo] = copiar(p);
      corpo.appendChild(linhaProduto(p));
    });

    atualizarBarra();
  }

  function copiar(o) {
    var c = {};
    Object.keys(o).forEach(function (k) { c[k] = o[k]; });
    return c;
  }

  function linhaProduto(p) {
    var tr = el('tr');
    tr.setAttribute('data-codigo', p.codigo);
    if (!p.ativo) { tr.className = 'desligado'; }

    /* --- nome + código --------------------------------------------------- */
    var tdNome = el('td', 'c-prod');
    tdNome.appendChild(campoTexto(p.codigo, 'nome', p.nome));
    var cod = el('div', 'campo__dica', p.codigo);
    cod.style.marginTop = '3px';
    cod.style.fontFamily = 'var(--mono)';
    tdNome.appendChild(cod);
    tr.appendChild(tdNome);

    /* --- grupo ----------------------------------------------------------- */
    var tdGrupo = el('td');
    tdGrupo.setAttribute('data-rot', 'Grupo');
    tdGrupo.appendChild(campoTexto(p.codigo, 'grupo', p.grupo));
    tr.appendChild(tdGrupo);

    /* --- como cobra -------------------------------------------------------
       Os dois selects juntos porque só fazem sentido lidos em par: é a
       resposta a "esse produto cobra por unidade ou por percentual?".     */
    var tdVol = el('td');
    tdVol.setAttribute('data-rot', 'Volume é');
    tdVol.appendChild(campoSelect(p.codigo, 'tipo_volume', p.tipo_volume, [
      ['QUANTIDADE', 'Quantidade'],
      ['VALOR',      'Valor R$'],
      ['CONTEXTO',   'Só contexto']
    ]));
    tr.appendChild(tdVol);

    var tdFat = el('td');
    tdFat.setAttribute('data-rot', 'Fator é');
    tdFat.appendChild(campoSelect(p.codigo, 'tipo_fator', p.tipo_fator, [
      ['TARIFA', 'Tarifa R$'],
      ['TAXA',   'Taxa %'],
      ['NENHUM', 'Não cobra']
    ]));
    tr.appendChild(tdFat);

    /* --- periodicidade --------------------------------------------------- */
    var tdPer = el('td');
    tdPer.setAttribute('data-rot', 'Período');
    tdPer.appendChild(campoSelect(p.codigo, 'periodicidade', p.periodicidade, [
      ['MENSAL', 'Mensal'],
      ['ANUAL',  'Anual']
    ]));
    tr.appendChild(tdPer);

    /* --- unidade --------------------------------------------------------- */
    var tdUni = el('td');
    tdUni.setAttribute('data-rot', 'Unidade');
    tdUni.appendChild(campoTexto(p.codigo, 'unidade', p.unidade || ''));
    tr.appendChild(tdUni);

    /* --- o fator e a alçada ----------------------------------------------- */
    tr.appendChild(celulaNumero(p, 'fator'));
    tr.appendChild(celulaNumero(p, 'fator_piso'));
    tr.appendChild(celulaNumero(p, 'fator_teto'));

    /* --- ativo ------------------------------------------------------------ */
    var tdAtivo = el('td', 'c-ativo');
    tdAtivo.setAttribute('data-rot', 'Ativo');
    var lab = el('label', 'interruptor');
    var chk = el('input');
    chk.type = 'checkbox';
    chk.checked = !!p.ativo;
    chk.addEventListener('change', function () {
      S.edicao[p.codigo].ativo = chk.checked;
      tr.classList.toggle('desligado', !chk.checked);
      marcarSujo(p.codigo);
    });
    lab.appendChild(chk);
    tdAtivo.appendChild(lab);
    tr.appendChild(tdAtivo);

    return tr;
  }

  /* A célula de número mostra, abaixo do campo, como aquele valor é lido —
     "R$ 2,45" ou "0,35%". É a defesa contra o erro mais fácil desta tela:
     digitar 35 quando se queria dizer 0,35. */
  function celulaNumero(p, campo) {
    var td = el('td', 'c-num');
    td.setAttribute('data-rot', {
      fator: 'Fator', fator_piso: 'Piso', fator_teto: 'Teto'
    }[campo] || campo);
    var caixa = el('div', 'ent ent--fator');

    var input = el('input');
    input.type = 'text';
    input.inputMode = 'decimal';
    input.className = 'num-in';
    input.value = (p[campo] === null || p[campo] === undefined) ? '' : Fmt.numero(p[campo], casasDe(p[campo]));
    input.setAttribute('data-campo', campo);
    input.setAttribute('data-codigo', p.codigo);
    input.setAttribute('aria-label', campo + ' de ' + p.nome);
    /* "livre" e não "sem limite": com o espaço que o sufixo ocupa, o texto
       maior era cortado no meio e aparecia como "sem li" — o que não quer
       dizer nada para quem lê. */
    if (campo !== 'fator') { input.placeholder = 'livre'; }

    caixa.appendChild(input);
    caixa.appendChild(el('span', 'ent__sufixo', Fmt.sufixoFator(p.tipo_fator)));
    td.appendChild(caixa);

    var leitura = el('div', 'campo__dica');
    leitura.setAttribute('data-leitura', campo);
    leitura.style.marginTop = '3px';
    leitura.textContent = leituraDe(p[campo], S.edicao[p.codigo] ? S.edicao[p.codigo].tipo_fator : p.tipo_fator);
    td.appendChild(leitura);

    input.addEventListener('input', function () {
      var n = input.value.trim() === '' ? null : Fmt.paraNumero(input.value, true);
      S.edicao[p.codigo][campo] = n;
      leitura.textContent = leituraDe(n, S.edicao[p.codigo].tipo_fator);
      marcarSujo(p.codigo);
    });

    input.addEventListener('blur', function () {
      var n = S.edicao[p.codigo][campo];
      input.value = (n === null || n === undefined) ? '' : Fmt.numero(n, casasDe(n));
    });

    return td;
  }

  function casasDe(v) {
    if (v === null || v === undefined || v === 0) { return 2; }
    return (Math.abs(v) < 0.01) ? 4 : 2;
  }

  function leituraDe(v, tipoFator) {
    if (v === null || v === undefined || v === '') { return '—'; }
    if (tipoFator === 'NENHUM') { return 'não cobra'; }
    return 'lê-se ' + Fmt.fator(v, tipoFator);
  }

  function campoTexto(codigo, campo, valor) {
    var i = el('input');
    i.type = 'text';
    i.value = valor || '';
    i.setAttribute('aria-label', campo);
    i.addEventListener('input', function () {
      S.edicao[codigo][campo] = i.value;
      marcarSujo(codigo);
    });
    return i;
  }

  function campoSelect(codigo, campo, valor, opcoes) {
    var s = el('select');
    s.setAttribute('aria-label', campo);

    opcoes.forEach(function (o) {
      var op = el('option', null, o[1]);
      op.value = o[0];
      if (o[0] === valor) { op.selected = true; }
      s.appendChild(op);
    });

    s.addEventListener('change', function () {
      S.edicao[codigo][campo] = s.value;
      marcarSujo(codigo);

      /* Trocar o tipo do fator muda a leitura dos três números da linha:
         2,45 era "R$ 2,45" e passa a ser "2,45%". Repintar na hora evita a
         linha mostrar a leitura antiga com o tipo novo. */
      if (campo === 'tipo_fator') {
        var tr = $('#prod-tbody tr[data-codigo="' + codigo + '"]');
        $$('.ent__sufixo', tr).forEach(function (n) { n.textContent = Fmt.sufixoFator(s.value); });
        $$('[data-leitura]', tr).forEach(function (n) {
          n.textContent = leituraDe(S.edicao[codigo][n.getAttribute('data-leitura')], s.value);
        });
      }
    });

    return s;
  }


  /* ==================================================== parâmetros ======== */
  function montarParametros() {
    var alvo = $('#param-lista');
    limpar(alvo);
    S.paramEdicao = {};

    var grupoAtual = null;

    S.parametros.forEach(function (p) {
      S.paramEdicao[p.chave] = p.valor;

      if (p.grupo !== grupoAtual) {
        grupoAtual = p.grupo;

        var h = el('div', 'card__titulo', grupoAtual);
        h.style.marginTop = alvo.children.length ? '22px' : '0';
        h.style.marginBottom = '12px';
        alvo.appendChild(h);

        /* Uma grade por grupo. Sem ela, um campo que guarda "15" ocupava a
           largura inteira da tela — e um campo enorme para dois dígitos faz
           a pessoa procurar o que mais deveria caber ali. */
        var grade = el('div', 'grade-param');
        grade.setAttribute('data-grupo', grupoAtual);
        alvo.appendChild(grade);
      }

      alvo.lastChild.appendChild(campoParametro(p));
    });

    /* Precisa vir aqui: a barra é montada junto com os produtos, ANTES desta
       função rodar, e naquele momento S.paramEdicao ainda está vazio. Sem
       esta chamada a tela abria anunciando "9 alterações pendentes" — uma
       para cada parâmetro — sem ninguém ter tocado em nada. */
    atualizarBarra();
  }

  function campoParametro(p) {
    var campo = el('label', 'campo');
    campo.style.marginBottom = '12px';
    campo.appendChild(el('span', 'campo__rot', p.rotulo || p.chave));

    if (p.tipo === 'BOOLEANO') {
      var lab = el('label', 'interruptor');
      var chk = el('input');
      chk.type = 'checkbox';
      chk.checked = (p.valor === '1');
      chk.addEventListener('change', function () {
        S.paramEdicao[p.chave] = chk.checked ? '1' : '0';
        marcarSujoParam();
      });
      lab.appendChild(chk);
      lab.appendChild(el('span', null, chk.checked ? 'Ligado' : 'Desligado'));
      chk.addEventListener('change', function () {
        lab.lastChild.textContent = chk.checked ? 'Ligado' : 'Desligado';
      });
      campo.appendChild(lab);

    } else {
      var i = el('input');
      i.type = 'text';
      i.value = p.valor;
      if (p.tipo === 'NUMERO' || p.tipo === 'PERCENTUAL' || p.tipo === 'DINHEIRO') {
        i.inputMode = 'decimal';
        campo.classList.add('campo--num');
      }
      i.addEventListener('input', function () {
        S.paramEdicao[p.chave] = i.value;
        marcarSujoParam();
        if (leitura) { leitura.textContent = lerParametro(i.value, p); }
      });
      campo.appendChild(i);

      var leitura = null;
      if (p.tipo === 'PERCENTUAL' || p.tipo === 'DINHEIRO') {
        leitura = el('span', 'campo__dica', lerParametro(p.valor, p));
        campo.appendChild(leitura);
      }
    }

    if (p.ajuda) { campo.appendChild(el('span', 'campo__dica', p.ajuda)); }
    return campo;
  }

  function lerParametro(valor, p) {
    var n = Fmt.paraNumero(valor, p.tipo === 'PERCENTUAL');
    if (p.tipo === 'DINHEIRO')   { return 'lê-se ' + Fmt.dinheiro(n); }
    if (p.tipo === 'PERCENTUAL') { return 'lê-se ' + Fmt.percentual(n); }
    return '';
  }


  /* ====================================================== histórico ======= */
  function montarHistorico(hist) {
    var alvo = $('#hist-lista');
    limpar(alvo);

    if (!hist.length) {
      alvo.appendChild(el('div', 'campo__dica', 'Nenhuma alteração registrada ainda.'));
      return;
    }

    hist.forEach(function (h) {
      var item = el('div', 'hist__item');
      item.appendChild(el('span', 'hist__pino'));

      var txt = el('div', 'hist__txt');

      var cabeca = el('div');
      cabeca.appendChild(el('strong', null, h.produto_nome || h.produto_codigo));
      cabeca.appendChild(document.createTextNode(' · ' + rotuloCampo(h.campo)));
      txt.appendChild(cabeca);

      var dePara = el('div', 'hist__de-para');
      if (h.valor_antes !== null && h.valor_antes !== '') {
        dePara.appendChild(el('span', 'hist__antes', h.valor_antes));
        dePara.appendChild(document.createTextNode('  →  '));
      }
      dePara.appendChild(el('span', 'hist__depois', h.valor_depois === null ? '(vazio)' : h.valor_depois));
      txt.appendChild(dePara);

      var pe = el('div', 'campo__dica',
        (h.usuario_nome || 'alguém') + ' · ' + Fmt.quando(h.criado_em)
        + (h.motivo ? ' · ' + h.motivo : ''));
      txt.appendChild(pe);

      item.appendChild(txt);
      alvo.appendChild(item);
    });
  }

  function rotuloCampo(c) {
    var mapa = {
      fator: 'fator', fator_piso: 'piso da alçada', fator_teto: 'teto da alçada',
      nome: 'nome', grupo: 'grupo', ativo: 'ativo', ordem: 'ordem',
      unidade: 'unidade', tipo_volume: 'tipo de volume', tipo_fator: 'tipo de fator',
      periodicidade: 'periodicidade', criado: 'produto criado'
    };
    return mapa[c] || c;
  }

  function montarAdmins(admins) {
    var alvo = $('#admin-lista');
    limpar(alvo);

    admins.forEach(function (a) {
      var c = el('span', 'chip');
      c.appendChild(icone('i-user'));
      c.appendChild(el('span', null, a.nome || a.email));
      c.title = a.email;
      alvo.appendChild(c);
    });

    if (!admins.length) {
      alvo.appendChild(el('span', 'campo__dica', 'Ninguém cadastrado.'));
    }
  }


  /* ================================================= o que mudou ========== */
  function marcarSujo(codigo) {
    var tr = $('#prod-tbody tr[data-codigo="' + codigo + '"]');
    if (tr) { tr.classList.toggle('sujo', produtoMudou(codigo)); }
    atualizarBarra();
  }

  function marcarSujoParam() { atualizarBarra(); }

  function produtoMudou(codigo) {
    var antes = null;
    for (var i = 0; i < S.produtos.length; i++) {
      if (S.produtos[i].codigo === codigo) { antes = S.produtos[i]; break; }
    }
    if (!antes) { return true; }

    var agora = S.edicao[codigo];
    var campos = ['nome','grupo','ordem','tipo_volume','tipo_fator','periodicidade',
                  'unidade','fator','fator_piso','fator_teto','ativo'];

    for (var j = 0; j < campos.length; j++) {
      var c = campos[j];
      var a = antes[c], b = agora[c];

      if (c === 'fator' || c === 'fator_piso' || c === 'fator_teto') {
        var na = (a === null || a === undefined) ? null : Number(a);
        var nb = (b === null || b === undefined) ? null : Number(b);
        if (na === null && nb === null) { continue; }
        if (na === null || nb === null) { return true; }
        if (Math.abs(na - nb) > 0.00000001) { return true; }
      } else if (c === 'ativo') {
        if (!!a !== !!b) { return true; }
      } else {
        if (String(a === null || a === undefined ? '' : a) !== String(b === null || b === undefined ? '' : b)) {
          return true;
        }
      }
    }
    return false;
  }

  function contarMudancas() {
    var n = 0;

    Object.keys(S.edicao).forEach(function (c) { if (produtoMudou(c)) { n++; } });

    S.parametros.forEach(function (p) {
      var agora = S.paramEdicao[p.chave];

      /* Parâmetro que a tela ainda não desenhou não está alterado, está
         ausente. Sem esta guarda, undefined virava "0" ou "undefined" na
         comparação e contava como mudança. */
      if (agora === undefined) { return; }

      if (p.tipo === 'NUMERO' || p.tipo === 'PERCENTUAL' || p.tipo === 'DINHEIRO') {
        if (Fmt.paraNumero(agora, true) !== Fmt.paraNumero(p.valor, true)) { n++; }
      } else if (String(agora) !== String(p.valor)) { n++; }
    });

    return n;
  }

  function atualizarBarra() {
    var n = contarMudancas();

    $('#barra-txt').textContent = n === 0
      ? 'Nada alterado.'
      : (n === 1 ? '1 alteração pendente.' : n + ' alterações pendentes.');

    $('#btn-salvar').disabled = (n === 0) || S.salvando;
    $('#btn-descartar').disabled = (n === 0);
  }


  /* ================================================= salvar =============== */
  function ligarEventos() {
    $('#btn-salvar').addEventListener('click', function () {
      $('#motivo-texto').value = '';
      $('#motivo-conta').textContent = $('#barra-txt').textContent;
      $('#modal-motivo').classList.add('aberto');
      setTimeout(function () { $('#motivo-texto').focus(); }, 60);
    });

    $('#motivo-confirmar').addEventListener('click', salvar);
    $('#btn-descartar').addEventListener('click', descartar);
    $('#btn-novo').addEventListener('click', abrirNovo);
    $('#novo-confirmar').addEventListener('click', criarProduto);

    $$('[data-fechar-modal]').forEach(function (b) {
      b.addEventListener('click', function () {
        $$('.modal').forEach(function (m) { m.classList.remove('aberto'); });
      });
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') {
        $$('.modal').forEach(function (m) { m.classList.remove('aberto'); });
      }
    });

    /* O aviso de saída. O navegador mostra o texto dele, não o nosso — mas
       sem isto meia hora de ajuste some num fechar de aba sem querer. */
    window.addEventListener('beforeunload', function (ev) {
      if (contarMudancas() > 0 && !S.salvando) {
        ev.preventDefault();
        ev.returnValue = '';
        return '';
      }
    });
  }

  function salvar() {
    if (S.salvando) { return; }
    S.salvando = true;
    $('#motivo-confirmar').disabled = true;

    var produtos = [];
    Object.keys(S.edicao).forEach(function (c) {
      if (produtoMudou(c)) { produtos.push(S.edicao[c]); }
    });

    var parametros = {};
    S.parametros.forEach(function (p) { parametros[p.chave] = S.paramEdicao[p.chave]; });

    mandar(CFG.API.admin, {
      produtos: produtos,
      parametros: parametros,
      motivo: $('#motivo-texto').value
    }).then(function (d) {
      $$('.modal').forEach(function (m) { m.classList.remove('aberto'); });
      recado(d.mensagem || 'Salvo.');

      /* Recarrega do servidor em vez de confiar no que está na tela: é a
         única forma de a base de comparação ser o que REALMENTE ficou
         gravado — inclusive os limites que o servidor tenha corrigido. */
      return pegar(CFG.API.admin).then(function (novo) {
        S.produtos   = novo.produtos || [];
        S.parametros = novo.parametros || [];
        montarProdutos();
        montarParametros();
        montarHistorico(novo.historico || []);
      });

    }).catch(function (e) {
      recado(explicarErro(e), 'erro');
    }).then(function () {
      S.salvando = false;
      $('#motivo-confirmar').disabled = false;
      atualizarBarra();
    });
  }

  function descartar() {
    if (contarMudancas() === 0) { return; }
    if (!window.confirm('Descartar as alterações que ainda não foram salvas?')) { return; }

    montarProdutos();
    montarParametros();
    recado('Alterações descartadas.');
  }


  /* ================================================ produto novo ========== */
  function abrirNovo() {
    $('#novo-codigo').value = '';
    $('#novo-nome').value = '';
    $('#novo-grupo').value = 'Outros';
    $('#modal-novo').classList.add('aberto');
    setTimeout(function () { $('#novo-nome').focus(); }, 60);
  }

  function criarProduto() {
    var nome = $('#novo-nome').value.trim();
    if (!nome) { recado('Dê um nome ao produto.', 'erro'); return; }

    var codigo = $('#novo-codigo').value.trim() || sugerirCodigo(nome);

    if (!/^[a-z0-9_]{2,40}$/.test(codigo)) {
      recado('O código só aceita letras minúsculas, números e sublinhado.', 'erro');
      return;
    }
    if (S.edicao[codigo]) {
      recado('Já existe um produto com o código "' + codigo + '".', 'erro');
      return;
    }

    var novo = {
      codigo: codigo,
      nome: nome,
      grupo: $('#novo-grupo').value.trim() || 'Outros',
      ordem: 990,
      tipo_volume: $('#novo-tipo-volume').value,
      tipo_fator: $('#novo-tipo-fator').value,
      periodicidade: $('#novo-periodicidade').value,
      unidade: $('#novo-unidade').value.trim(),
      ajuda: null,
      fator: Fmt.paraNumero($('#novo-fator').value, true),
      fator_piso: null,
      fator_teto: null,
      ativo: true
    };

    /* Entra só na tela. Só existe no banco depois do Salvar — assim criar um
       produto por engano se desfaz com "Descartar", como qualquer outra
       alteração desta tela. */
    S.edicao[codigo] = novo;
    $('#prod-tbody').appendChild(linhaProduto(novo));
    $('#prod-tbody').lastChild.classList.add('sujo');

    $$('.modal').forEach(function (m) { m.classList.remove('aberto'); });
    atualizarBarra();
    recado('Produto adicionado à tela. Clique em Salvar para gravar.');

    $('#prod-tbody').lastChild.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  /* "Emissão de Cobrança" -> "emissao_de_cobranca" */
  function sugerirCodigo(nome) {
    return nome.toLowerCase()
      .replace(/[áàãâä]/g, 'a').replace(/[éèêë]/g, 'e').replace(/[íìîï]/g, 'i')
      .replace(/[óòõôö]/g, 'o').replace(/[úùûü]/g, 'u').replace(/ç/g, 'c')
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 40);
  }


  /* ======================================================================= */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
})();
