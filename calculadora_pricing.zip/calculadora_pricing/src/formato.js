/* ============================================================================
   Formatação e leitura de números

   ---------------------------------------------------------------------------
   O PROBLEMA DE LER NÚMERO DIGITADO POR GENTE, que é onde calculadora erra:

   A mesma pessoa digita "1.500.000", "1500000" e "1,5" na mesma tabela, e as
   três estão certas do ponto de vista dela. O ponto às vezes é separador de
   milhar e às vezes é decimal — e chutar errado não dá erro nenhum: dá um
   número mil vezes maior ou menor, que entra na conta calado.

   A regra que usamos:

     tem vírgula          a vírgula é o decimal e o ponto é milhar.
                          "1.500.000,50" -> 1500000.5

     dois pontos ou mais  são todos milhar, porque decimal só tem um.
                          "1.500.000"    -> 1500000

     um ponto só          ambíguo, e aqui o campo decide:
                            campo de VOLUME  "1.500" -> 1500  (milhar)
                            campo de FATOR   "0.350" -> 0.35  (decimal)
                          Faz sentido: volume é grande e redondo, fator é
                          pequeno e quebrado. Um fator de 350% não existe;
                          um volume de 1,5 real também não.

   O número só é formatado quando o campo PERDE o foco. Enquanto a pessoa
   digita, o que está na tela é exatamente o que ela escreveu — formatar
   durante a digitação embaralha o cursor e é o jeito mais rápido de fazer
   alguém odiar um formulário.
   ========================================================================== */
(function () {
  'use strict';

  /* Intl existe em todo navegador desde 2015 e resolve milhar, decimal e
     moeda com as regras do pt-BR sem tabela nossa. */
  var fmtDinheiro = new Intl.NumberFormat('pt-BR', {
    style: 'currency', currency: 'BRL',
    minimumFractionDigits: 2, maximumFractionDigits: 2
  });

  var fmtNumero0 = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 });
  var fmtNumero2 = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  function ehNumero(v) {
    return typeof v === 'number' && isFinite(v);
  }

  /* --------------------------------------------------------------------------
     O Intl separa "R$" do número com ESPAÇO NÃO-QUEBRÁVEL (U+00A0), e em
     algumas versões com o estreito (U+202F). Parece um espaço comum na tela e
     não é — o que dá dois problemas de verdade:

       · o PHP formata com espaço comum, então os textos do veredito gerados
         nos dois lados ficariam diferentes byte a byte. O teste
         testes/gemeos.js pega isso na hora, e foi assim que apareceu.

       · colado num e-mail ou no Teams, o não-quebrável às vezes chega como
         "Â " ou como quadradinho, dependendo da codificação do destino.

     Então toda saída formatada passa por aqui e sai com espaço comum.
     ------------------------------------------------------------------------ */
  function espacoComum(s) {
    return String(s).replace(/[\u00A0\u202F]/g, ' ');
  }

  window.Fmt = {

    /* ---------------------------------------------------------- leitura -- */

    /* Texto digitado -> número.
       preferirDecimal = true nos campos de fator. Ver o bloco do topo. */
    paraNumero: function (texto, preferirDecimal) {
      if (ehNumero(texto)) { return texto; }
      if (texto === null || texto === undefined) { return 0; }

      var s = String(texto).trim();
      if (s === '') { return 0; }

      var negativo = s.indexOf('-') === 0;

      /* Fora tudo que não é dígito, vírgula ou ponto: "R$", espaços,
         espaço fino, o que a pessoa tiver colado de uma planilha. */
      s = s.replace(/[^\d,.]/g, '');
      if (s === '') { return 0; }

      var temVirgula = s.indexOf(',') >= 0;
      var pontos = (s.match(/\./g) || []).length;

      if (temVirgula) {
        s = s.replace(/\./g, '').replace(/,/g, '.');

      } else if (pontos > 1) {
        s = s.replace(/\./g, '');

      } else if (pontos === 1) {
        var partes = s.split('.');
        var inteira = partes[0];
        var resto = partes[1];

        /* Milhar só quando o desenho é de milhar: exatamente três dígitos
           depois do ponto, parte inteira curta e não começando em zero.
           "0.350" continua sendo três décimos e meio, e não trezentos. */
        var pareceMilhar = (resto.length === 3)
                        && (inteira.length >= 1 && inteira.length <= 3)
                        && (inteira !== '0')
                        && !preferirDecimal;

        if (pareceMilhar) { s = inteira + resto; }
      }

      var n = parseFloat(s);
      if (isNaN(n)) { return 0; }
      return negativo ? -n : n;
    },

    /* ------------------------------------------------------- formatação -- */

    dinheiro: function (v) {
      if (!ehNumero(v)) { v = 0; }
      return espacoComum(fmtDinheiro.format(v));
    },

    /* Versão curta, para o cartão de métricas do cliente. Faturamento de
       oito milhões e meio vira "R$ 8,5 mi": o que importa ali é a ordem de
       grandeza, e o número inteiro só ocuparia a linha sem dizer mais. */
    dinheiroCurto: function (v) {
      if (!ehNumero(v)) { v = 0; }
      var abs = Math.abs(v);

      if (abs >= 1000000000) { return espacoComum('R$ ' + fmtNumero2.format(v / 1000000000).replace(',00', '') + ' bi'); }
      if (abs >= 1000000)    { return espacoComum('R$ ' + fmtNumero2.format(v / 1000000).replace(',00', '') + ' mi'); }
      if (abs >= 10000)      { return espacoComum('R$ ' + fmtNumero0.format(v)); }
      return espacoComum(fmtDinheiro.format(v));
    },

    numero: function (v, casas) {
      if (!ehNumero(v)) { v = 0; }
      if (casas === undefined) { casas = 0; }
      return espacoComum(new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: casas, maximumFractionDigits: casas
      }).format(v));
    },

    /* Quantidade sem casas quando é inteira, com duas quando não é. Serve
       para "8.000 boletos" e "420 funcionários" ficarem limpos. */
    quantidade: function (v) {
      if (!ehNumero(v)) { v = 0; }
      return espacoComum((Math.abs(v - Math.round(v)) < 0.0001)
        ? fmtNumero0.format(v)
        : fmtNumero2.format(v));
    },

    /* Casa decimal só quando ela diz alguma coisa: "15%" lê melhor que
       "15,0%", mas "5,4%" não pode virar "5%".
       Espelha pricingPercentual() do api/motor.php. */
    percentual: function (v, sinal) {
      if (!ehNumero(v)) { v = 0; }
      var casas = (Math.abs(v - Math.round(v)) < 0.05) ? 0 : 1;
      var txt = espacoComum(new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: casas, maximumFractionDigits: casas
      }).format(v)) + '%';
      return (sinal && v > 0) ? '+' + txt : txt;
    },

    /* O fator, escrito do jeito que a área fala dele. */
    fator: function (v, tipoFator) {
      if (!ehNumero(v)) { v = 0; }
      if (tipoFator === 'TARIFA') { return espacoComum(fmtDinheiro.format(v)); }
      if (tipoFator === 'NENHUM') { return '—'; }

      /* Taxa tem casas variáveis: 0,89% e 0,025% convivem na mesma tabela.
         Mostrar sempre duas casas esconderia a segunda. */
      var casas = 2;
      if (Math.abs(v) > 0 && Math.abs(v) < 0.01) { casas = 4; }
      else if (Math.abs(v * 100) % 1 !== 0) { casas = 3; }

      return espacoComum(new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: 2, maximumFractionDigits: casas
      }).format(v)) + '%';
    },

    /* O sufixo que aparece dentro do campo de fator. */
    sufixoFator: function (tipoFator) {
      if (tipoFator === 'TARIFA') { return 'R$'; }
      if (tipoFator === 'TAXA')   { return '%'; }
      return '';
    },

    /* O volume, formatado conforme o produto cobra por unidade ou por valor. */
    volume: function (v, tipoVolume) {
      if (!ehNumero(v)) { v = 0; }
      if (v === 0) { return '—'; }
      return (tipoVolume === 'QUANTIDADE') ? this.quantidade(v) : this.dinheiroCurto(v);
    },

    cnpj: function (v) {
      var d = String(v || '').replace(/\D/g, '');
      if (d.length !== 14) { return v || ''; }
      return d.slice(0, 2) + '.' + d.slice(2, 5) + '.' + d.slice(5, 8)
           + '/' + d.slice(8, 12) + '-' + d.slice(12, 14);
    },

    soDigitos: function (v) {
      return String(v || '').replace(/\D/g, '');
    },

    /* '2026-08' -> 'ago/2026'. A referência dos dados aparece assim porque
       "agosto de 2026" ocuparia a linha toda num rodapé de tabela. */
    referencia: function (v) {
      if (!v) { return ''; }
      var p = String(v).split('-');
      if (p.length < 2) { return v; }

      var meses = ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
      var m = parseInt(p[1], 10);
      if (isNaN(m) || m < 1 || m > 12) { return v; }
      return meses[m - 1] + '/' + p[0];
    },

    /* '2026-09-16 14:32:00' -> '16/09 às 14:32'. Sem o ano quando é deste
       ano: no histórico, todas as linhas seriam iguais nessa parte. */
    quando: function (v) {
      if (!v) { return ''; }

      /* Trocar o espaço por 'T' porque o Safari recusa o formato do MySQL. */
      var d = new Date(String(v).replace(' ', 'T'));
      if (isNaN(d.getTime())) { return v; }

      var dois = function (n) { return (n < 10 ? '0' : '') + n; };
      var base = dois(d.getDate()) + '/' + dois(d.getMonth() + 1);

      if (d.getFullYear() !== new Date().getFullYear()) {
        base += '/' + d.getFullYear();
      }
      return base + ' às ' + dois(d.getHours()) + ':' + dois(d.getMinutes());
    },

    /* As iniciais para o avatar. Primeira e última palavra, ignorando as
       partículas — "Luan Teixeira de Bastos" vira LB, e não LD. */
    iniciais: function (nome) {
      var partes = String(nome || '').trim().split(/\s+/).filter(function (p) {
        return p.length > 2 || /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ]/.test(p);
      });
      if (!partes.length) { return '?'; }
      if (partes.length === 1) { return partes[0].slice(0, 2).toUpperCase(); }
      return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
    },

    /* Razão social em caixa alta é como o banco guarda, mas cansa de ler numa
       tela inteira. Isto devolve "Transportadora Rota Norte Ltda", mantendo
       as siglas de porte jurídico em caixa. */
    nomeBonito: function (nome) {
      var s = String(nome || '').trim();
      if (!s) { return ''; }
      if (s !== s.toUpperCase()) { return s; }

      var minusculas = ['de','da','do','das','dos','e','em','a','o','para','com'];
      var siglas = ['LTDA','ME','EPP','EIRELI','S/A','SA','S.A.','MEI','CIA'];

      return s.toLowerCase().split(/\s+/).map(function (p, i) {
        var limpo = p.replace(/[^\wÀ-ÿ/.]/g, '');
        if (siglas.indexOf(limpo.toUpperCase()) >= 0) { return p.toUpperCase(); }
        if (i > 0 && minusculas.indexOf(limpo) >= 0) { return p; }
        return p.charAt(0).toUpperCase() + p.slice(1);
      }).join(' ');
    }
  };
})();
