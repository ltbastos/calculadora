/* ============================================================================
   Calculadora de Pricing PJ — a tela

   O caminho da pessoa, e é nessa ordem que o código está organizado:

     1. quem é você          identidade + sessão
     2. qual cliente         busca por número, ou escolha na carteira
     3. o que ele traz       a tabela, que recalcula a cada tecla
     4. vale a pena?         o painel, que nunca sai da vista
     5. guardar              simulação gravada com protocolo

   ES5 de propósito: sem build, sem npm, sem transpilador. O arquivo que você
   escreve é o arquivo que roda no servidor — e quando algo quebrar às 18h de
   uma sexta, dá para abrir o Bloco de Notas e consertar.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.PRICING_CONFIG;
  var Fmt = window.Fmt;


  /* =========================================================================
     ESTADO

     Tudo que a tela sabe num objeto só. Quando algo aparece errado, é aqui
     que se olha primeiro — e dá para inspecionar no console com
     `window.__pricing`.
     ======================================================================= */
  var S = {
    usuario:  null,   /* quem abriu                                         */
    config:   {},     /* parâmetros vindos do banco                         */
    produtos: [],     /* catálogo ativo, na ordem de exibição               */

    cliente:  null,   /* o cliente escolhido                                */
    atual:    {},     /* o que ele tem hoje, por código de produto          */
    entradas: {},     /* o que a pessoa digitou, por código de produto      */
    outrosNiveis: [],

    resultado: null,  /* a última conta feita                               */
    salvando: false
  };

  window.__pricing = S;


  /* =========================================================================
     ATALHOS DE DOM
     ======================================================================= */
  function $(sel, raiz) { return (raiz || document).querySelector(sel); }
  function $$(sel, raiz) { return Array.prototype.slice.call((raiz || document).querySelectorAll(sel)); }

  function el(tag, classe, texto) {
    var n = document.createElement(tag);
    if (classe) { n.className = classe; }
    if (texto !== undefined && texto !== null) { n.textContent = texto; }
    return n;
  }

  /* Ícone do sprite. Sempre por aqui, para nunca sair um <svg> torto. */
  function icone(nome, classe) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'ic' + (classe ? ' ' + classe : ''));
    svg.setAttribute('aria-hidden', 'true');
    var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#' + nome);
    svg.appendChild(use);
    return svg;
  }

  function mostrar(node, sim) { if (node) { node.hidden = !sim; } }
  function limpar(node) { while (node && node.firstChild) { node.removeChild(node.firstChild); } }


  /* =========================================================================
     PROGRESSO E RECADOS
     ======================================================================= */
  var progresso = { barra: null, contador: 0 };

  function comecouAlgo() {
    progresso.contador++;
    if (progresso.barra) { progresso.barra.className = 'progresso andando'; }
  }
  function acabouAlgo() {
    progresso.contador = Math.max(0, progresso.contador - 1);
    if (progresso.contador === 0 && progresso.barra) {
      progresso.barra.className = 'progresso pronto';
      setTimeout(function () {
        if (progresso.contador === 0) { progresso.barra.className = 'progresso'; }
      }, 300);
    }
  }

  var recadoTimer = null;
  function recado(texto, tipo) {
    var caixa = $('#recado');
    if (!caixa) { return; }

    limpar(caixa);
    caixa.className = 'recado' + (tipo ? ' recado--' + tipo : '');
    caixa.appendChild(icone(tipo === 'erro' ? 'i-alert' : 'i-check-circle'));
    caixa.appendChild(el('span', null, texto));

    /* Força o reflow antes de animar: sem isso, dois recados seguidos não
       reanimam porque a classe some e volta no mesmo quadro. */
    void caixa.offsetWidth;
    caixa.classList.add('aberto');

    clearTimeout(recadoTimer);
    recadoTimer = setTimeout(function () {
      caixa.classList.remove('aberto');
    }, (CFG.RECADO_SEGUNDOS || 4) * 1000);
  }


  /* =========================================================================
     API

     Toda chamada leva a identidade junto. Não existe sessão no servidor —
     cada requisição se apresenta, e é o que permite a ferramenta funcionar
     sem cookie, sem login e sem estado guardado em lugar nenhum.
     ======================================================================= */
  function comIdentidade(url, extras) {
    var p = window.Identidade.comoParams(S.usuario);
    if (extras) {
      Object.keys(extras).forEach(function (k) {
        if (extras[k] !== undefined && extras[k] !== null && extras[k] !== '') {
          p.set(k, extras[k]);
        }
      });
    }
    return url + '?' + p.toString();
  }

  function pegar(url, extras) {
    comecouAlgo();
    return fetch(comIdentidade(url, extras), { cache: 'no-store' })
      .then(lerResposta)
      .then(function (d) { acabouAlgo(); return d; })
      .catch(function (e) { acabouAlgo(); throw e; });
  }

  function mandar(url, corpo) {
    comecouAlgo();
    corpo = corpo || {};
    corpo.usuario = S.usuario;

    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(corpo)
    })
      .then(lerResposta)
      .then(function (d) { acabouAlgo(); return d; })
      .catch(function (e) { acabouAlgo(); throw e; });
  }

  /* Uma resposta que não é JSON quase sempre é erro do PHP vazando como
     HTML. Dizer "resposta inesperada" não ajuda ninguém; dizer que provável
     mente é o Apache/MySQL ajuda. */
  function lerResposta(r) {
    return r.text().then(function (txt) {
      var dados;
      try {
        dados = JSON.parse(txt);
      } catch (e) {
        throw {
          motivo: 'resposta-invalida',
          mensagem: 'O servidor respondeu algo que não é JSON (HTTP ' + r.status + '). '
                  + 'Isso costuma ser erro de PHP — confira o log do Apache.'
        };
      }
      if (!r.ok || dados.ok === false) {
        throw {
          motivo: dados.motivo || 'erro',
          mensagem: dados.mensagem || ('Erro HTTP ' + r.status + '.')
        };
      }
      return dados;
    });
  }

  function explicarErro(e) {
    if (e && e.mensagem) { return e.mensagem; }
    if (e && e.message) {
      /* "Failed to fetch" é o que o navegador diz quando o Apache está
         parado. A mensagem crua não diz nada para quem não é da área. */
      if (/fetch|network/i.test(e.message)) {
        return 'Não consegui falar com o servidor. Confira se o Apache do XAMPP está ligado.';
      }
      return e.message;
    }
    return 'Algo deu errado.';
  }


  /* =========================================================================
     1. ARRANQUE
     ======================================================================= */
  function iniciar() {
    progresso.barra = $('#progresso');

    window.Identidade.resolver().then(function (r) {
      if (!r.ok) { return bloquear(r); }

      S.usuario = r.usuario;
      pintarUsuario();

      return pegar(CFG.API.sessao).then(function (d) {
        S.config   = d.config || {};
        S.produtos = d.produtos || [];

        S.usuario.admin = !!(d.usuario && d.usuario.admin);
        if (d.usuario && d.usuario.nome) { S.usuario.nome = d.usuario.nome; }

        aplicarConfig(d);
        pintarUsuario();
        ligarEventos();

        mostrar($('#app'), true);

        if (!d.carteira || d.carteira.contas === 0) { avisarCarteiraVazia(); }

        carregarHistorico();
        $('#busca-input').focus();
      });
    }).catch(function (e) {
      bloquear({ motivo: 'falhou', detalhe: explicarErro(e) });
    });
  }

  function aplicarConfig(d) {
    var titulo = S.config.titulo || 'Calculadora de Pricing';
    var sub    = S.config.subtitulo || '';

    $('#marca-nome').textContent = titulo;
    $('#marca-sub').textContent  = sub;
    document.title = titulo + (sub ? ' · ' + sub : '');

    mostrar($('#btn-admin'), S.usuario.admin);
  }

  function pintarUsuario() {
    if (!S.usuario) { return; }
    $('#eu-nome').textContent    = S.usuario.nome || S.usuario.email || 'sem nome';
    $('#eu-inicial').textContent = Fmt.iniciais(S.usuario.nome || S.usuario.email);
    $('#eu-papel').textContent   = S.usuario.admin ? 'Administrador' : (S.usuario.cargo || 'Gerente');
  }

  /* --- a tela de bloqueio ------------------------------------------------
     Aparece quando não sabemos quem é a pessoa. Explica o motivo em vez de
     mostrar "acesso negado", que não diz o que fazer a seguir. */
  function bloquear(r) {
    mostrar($('#app'), false);
    var caixa = $('#bloqueio');
    mostrar(caixa, true);

    var titulo = $('#bloqueio-titulo');
    var texto  = $('#bloqueio-texto');
    var acao   = $('#bloqueio-acao');

    if (r.motivo === 'sem-identidade') {
      titulo.textContent = 'Preciso saber quem é você';
      texto.textContent  = 'Esta página não consegue descobrir sozinha quem está usando — ela roda no '
                         + 'Apache, que não tem autenticação do Windows. Abra a calculadora pelo '
                         + 'atalho oficial, que passa a sua identificação.';
      if (CFG.POWERAPP_URL && CFG.POWERAPP_URL.indexOf('SEU-APP-ID') < 0) {
        acao.href = CFG.POWERAPP_URL;
        mostrar(acao, true);
      }
    } else {
      titulo.textContent = 'Não consegui iniciar';
      texto.textContent  = r.detalhe || 'Erro desconhecido.';
      mostrar(acao, false);
    }
  }

  function avisarCarteiraVazia() {
    var alvo = $('#aviso-carteira');
    limpar(alvo);
    alvo.appendChild(icone('i-alert'));

    var txt = el('div');
    txt.appendChild(el('strong', null, 'Nenhum cliente na sua carteira. '));
    txt.appendChild(document.createTextNode(
      'A tabela de encarteiramento não tem nenhuma linha com o seu e-mail (' + S.usuario.email
      + ') nem com a sua funcional. Você ainda consegue simular digitando o CNPJ, mas confira a '
      + 'carga do encarteiramento com quem cuida dela.'
    ));
    alvo.appendChild(txt);

    alvo.className = 'aviso aviso--aviso';
    mostrar(alvo, true);
    mostrar($('#btn-carteira'), false);
  }


  /* =========================================================================
     2. BUSCA E CARTEIRA
     ======================================================================= */
  function ligarEventos() {
    $('#form-busca').addEventListener('submit', function (ev) {
      ev.preventDefault();
      buscarCliente($('#busca-input').value);
    });

    $('#btn-carteira').addEventListener('click', abrirCarteira);
    $('#carteira-fechar').addEventListener('click', function () { mostrar($('#carteira-card'), false); });

    var t = null;
    $('#carteira-busca').addEventListener('input', function () {
      clearTimeout(t);
      var v = this.value;
      t = setTimeout(function () { listarCarteira(v); }, 220);
    });

    $('#btn-limpar').addEventListener('click', limparSimulacao);
    $('#btn-pdf').addEventListener('click', abrirSalvar);

    $('#salvar-confirmar').addEventListener('click', gerarPdf);
    $$('[data-fechar-modal]').forEach(function (b) {
      b.addEventListener('click', function () { fecharModais(); });
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { fecharModais(); }
    });
  }

  function buscarCliente(termo) {
    termo = (termo || '').trim();
    if (!termo) { $('#busca-input').focus(); return; }

    /* Texto sem número nenhum é nome de empresa: em vez de devolver erro,
       a tela abre a carteira já filtrada. É o que a pessoa queria. */
    if (!Fmt.soDigitos(termo)) {
      abrirCarteira();
      $('#carteira-busca').value = termo;
      listarCarteira(termo);
      return;
    }

    pegar(CFG.API.cliente, { termo: termo }).then(function (d) {
      marcarBuscaComErro(false);
      if (d.escolher) { return escolherNivel(d); }
      aplicarCliente(d);
    }).catch(function (e) {
      /* Uma busca que falha deixa na tela o cliente ANTERIOR. Sem um sinal
         no próprio campo, é fácil ler os números do cliente velho achando
         que são do novo — e simular a negociação errada inteira. O recado
         some em quatro segundos; a borda vermelha fica até a busca dar
         certo. */
      marcarBuscaComErro(true);
      recado(explicarErro(e), 'erro');
    });
  }

  function marcarBuscaComErro(sim) {
    var campo = $('#busca-input');
    campo.classList.toggle('com-erro', !!sim);
    if (sim) { campo.focus(); campo.select(); }
  }

  function abrirCarteira() {
    var card = $('#carteira-card');
    mostrar(card, true);
    $('#carteira-busca').focus();
    if (!$('#carteira-lista').children.length) { listarCarteira(''); }
  }

  function listarCarteira(q) {
    var lista = $('#carteira-lista');

    pegar(CFG.API.carteira, { q: q, limite: CFG.CARTEIRA_QUANTOS }).then(function (d) {
      limpar(lista);

      if (!d.clientes.length) {
        var v = el('div', 'vazio');
        v.appendChild(el('div', 'vazio__titulo', 'Nenhum cliente encontrado'));
        v.appendChild(el('div', 'vazio__texto',
          q ? 'Nada na sua carteira bate com "' + q + '".' : 'Sua carteira está vazia.'));
        lista.appendChild(v);
        return;
      }

      d.clientes.forEach(function (c) { lista.appendChild(itemDeCliente(c)); });

      $('#carteira-conta').textContent = d.total + (d.truncado ? '+ clientes' : ' clientes');
    }).catch(function (e) {
      recado(explicarErro(e), 'erro');
    });
  }

  function itemDeCliente(c) {
    var b = el('button', 'cliente-item');
    b.type = 'button';

    b.appendChild(el('div', 'cliente-item__ini', Fmt.iniciais(c.razao_social)));

    var txt = el('div', 'cliente-item__txt');
    txt.appendChild(el('div', 'cliente-item__nome', Fmt.nomeBonito(c.razao_social)));

    var meta = [c.cnpj_exibicao];
    if (c.contas.length === 1) { meta.push(c.contas[0].exibicao); }
    else if (c.contas.length > 1) { meta.push(c.contas.length + ' contas'); }
    if (c.grupo_numero) { meta.push('grupo ' + c.grupo_numero); }

    txt.appendChild(el('div', 'cliente-item__meta', meta.join('  ·  ')));
    b.appendChild(txt);
    b.appendChild(icone('i-right', 'ic--sm'));

    b.addEventListener('click', function () {
      mostrar($('#carteira-card'), false);
      $('#busca-input').value = c.cnpj_exibicao;
      pegar(CFG.API.cliente, { nivel: 'CNPJ', chave: c.cnpj })
        .then(aplicarCliente)
        .catch(function (e) { recado(explicarErro(e), 'erro'); });
    });

    return b;
  }

  /* --- quando o mesmo número existe em mais de um nível ------------------ */
  function escolherNivel(d) {
    var corpo = $('#nivel-lista');
    limpar(corpo);

    d.alvos.forEach(function (a) {
      var b = el('button', 'cliente-item');
      b.type = 'button';

      b.appendChild(el('div', 'cliente-item__ini',
        a.nivel === 'GRUPO' ? 'GE' : (a.nivel === 'CNPJ' ? 'CJ' : 'CC')));

      var txt = el('div', 'cliente-item__txt');
      txt.appendChild(el('div', 'cliente-item__nome', Fmt.nomeBonito(a.razao_social) || a.rotulo));

      var meta = a.rotulo;
      if (a.tem_dados) { meta += '  ·  receita hoje ' + Fmt.dinheiro(a.receita_atual); }
      else { meta += '  ·  sem números na base'; }
      txt.appendChild(el('div', 'cliente-item__meta', meta));

      b.appendChild(txt);
      b.appendChild(icone('i-right', 'ic--sm'));

      b.addEventListener('click', function () {
        fecharModais();
        pegar(CFG.API.cliente, { nivel: a.nivel, chave: a.chave })
          .then(aplicarCliente)
          .catch(function (e) { recado(explicarErro(e), 'erro'); });
      });

      corpo.appendChild(b);
    });

    abrirModal('#modal-nivel');
  }


  /* =========================================================================
     3. O CLIENTE
     ======================================================================= */
  function aplicarCliente(d) {
    S.cliente      = d.cliente;
    S.atual        = d.produtos || {};
    S.outrosNiveis = d.outros_niveis || [];
    S.entradas     = {};

    pintarCliente(d);
    montarTabela();
    recalcular();

    mostrar($('#cliente-card'), true);
    mostrar($('#sim-card'), true);
    mostrar($('#painel'), true);
    mostrar($('#carteira-card'), false);

    /* Leva a pessoa para onde ela vai trabalhar. Sem isso, em tela pequena
       ela buscaria o cliente e continuaria vendo a caixa de busca. */
    $('#cliente-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function pintarCliente(d) {
    var c = S.cliente;

    $('#cliente-nome').textContent = Fmt.nomeBonito(c.razao_social) || c.chave_exibicao;

    /* --- os chips de identificação --------------------------------------- */
    var chips = $('#cliente-chips');
    limpar(chips);

    chips.appendChild(chip(
      c.nivel === 'GRUPO' ? 'i-layers' : (c.nivel === 'CNPJ' ? 'i-bank' : 'i-hash'),
      (c.nivel === 'GRUPO' ? 'Grupo ' : (c.nivel === 'CNPJ' ? 'CNPJ ' : 'Conta ')) + c.chave_exibicao,
      'chip--mono'
    ));

    if (c.segmento) { chips.appendChild(chip('i-briefcase', c.segmento)); }

    if (c.contas_abrangidas > 1) {
      chips.appendChild(chip('i-layers', c.contas_abrangidas + ' contas'
        + (c.cnpjs_abrangidos > 1 ? ' · ' + c.cnpjs_abrangidos + ' CNPJs' : '')));
    }

    if (c.na_carteira) {
      chips.appendChild(chip('i-check-circle', 'Sua carteira', 'chip--ok'));
    } else if (c.gerente_nome) {
      chips.appendChild(chip('i-user', 'Carteira de ' + c.gerente_nome, 'chip--aviso'));
    }

    /* Trocar de nível sem refazer a busca. */
    S.outrosNiveis.forEach(function (n) {
      var b = chip('i-right', 'Ver no ' + (n.nivel === 'GRUPO' ? 'grupo' : 'CNPJ'), 'chip--acao');
      b.addEventListener('click', function () {
        pegar(CFG.API.cliente, { nivel: n.nivel, chave: n.chave })
          .then(aplicarCliente)
          .catch(function (e) { recado(explicarErro(e), 'erro'); });
      });
      chips.appendChild(b);
    });

    /* --- as métricas ------------------------------------------------------ */
    var m = $('#cliente-metricas');
    limpar(m);

    m.appendChild(metrica('Faturamento médio', Fmt.dinheiroCurto(c.faturamento_mensal_medio),
      c.faturamento_mensal_medio ? 'por mês' : 'sem informação'));

    m.appendChild(metrica('Receita hoje', Fmt.dinheiro(c.receita_mensal_atual),
      c.referencia ? 'base ' + Fmt.referencia(c.referencia) : 'por mês'));

    m.appendChild(metrica('Receita no ano', Fmt.dinheiroCurto(c.receita_projetada_ano), 'projeção atual'));

    var produtos = Object.keys(S.atual).length;
    m.appendChild(metrica('Produtos hoje', String(produtos),
      produtos === 0 ? 'nenhum contratado' : 'em uso'));

    /* --- o aviso, quando há --------------------------------------------- */
    var aviso = $('#cliente-aviso');
    if (d.aviso) {
      limpar(aviso);
      aviso.appendChild(icone('i-alert'));
      aviso.appendChild(el('div', null, d.aviso));
      aviso.className = 'aviso aviso--aviso';
      mostrar(aviso, true);
    } else {
      mostrar(aviso, false);
    }
  }

  function chip(ic, texto, classe) {
    var c = el('span', 'chip' + (classe ? ' ' + classe : ''));
    if (ic) { c.appendChild(icone(ic)); }
    c.appendChild(el('span', null, texto));
    return c;
  }

  function metrica(rotulo, valor, nota) {
    var m = el('div', 'metrica');
    m.appendChild(el('div', 'metrica__rot', rotulo));
    m.appendChild(el('div', 'metrica__val', valor));
    if (nota) { m.appendChild(el('div', 'metrica__nota', nota)); }
    return m;
  }


  /* =========================================================================
     4. A TABELA

     Uma linha por produto, agrupada pelo campo `grupo` do catálogo. A ordem
     e os grupos vêm do banco, então mudar a cara da tabela é mexer no
     cadastro — não aqui.
     ======================================================================= */
  function montarTabela() {
    var corpo = $('#sim-tbody');
    limpar(corpo);

    var grupoAtual = null;

    S.produtos.forEach(function (p) {
      if (p.grupo !== grupoAtual) {
        grupoAtual = p.grupo;

        var tr = el('tr', 'grupo');
        var td = el('td', null, grupoAtual);
        td.colSpan = 7;
        tr.appendChild(td);
        corpo.appendChild(tr);
      }
      corpo.appendChild(linhaDeProduto(p));
    });

    ligarNavegacaoPorTeclado();
  }

  function linhaDeProduto(p) {
    var hoje = S.atual[p.codigo] || { volume_atual: 0, receita_atual: 0 };
    var contexto = (p.tipo_volume === 'CONTEXTO' || p.tipo_fator === 'NENHUM');

    var tr = el('tr', contexto ? 'contexto' : null);
    tr.setAttribute('data-produto', p.codigo);

    /* Marca a linha que já tem número hoje. No celular, onde a tabela vira
       cartão, é o que permite esconder "Volume hoje: —" nos produtos que o
       cliente ainda não contratou — dez linhas de traço não informam nada e
       empurram para baixo as três que informam. */
    if (!contexto && (hoje.volume_atual || hoje.receita_atual)) {
      tr.classList.add('tem-hoje');
    }

    /* --- 1. o produto ----------------------------------------------------- */
    var tdProd = el('td', 'c-prod');
    var box = el('div', 'prod');
    box.appendChild(el('span', 'prod__nome', p.nome));
    if (p.unidade) { box.appendChild(el('span', 'prod__uni', p.unidade)); }
    tdProd.appendChild(box);
    tr.appendChild(tdProd);

    /* --- 2 e 3. o que ele tem hoje ---------------------------------------- */
    var tdVol = el('td', 'c-hoje num');
    tdVol.setAttribute('data-rot', 'Volume hoje');
    tdVol.textContent = contexto ? '—' : Fmt.volume(hoje.volume_atual, p.tipo_volume);
    tr.appendChild(tdVol);

    var tdRec = el('td', 'c-hoje num');
    tdRec.setAttribute('data-rot', 'Receita hoje');
    tdRec.textContent = contexto ? '—' : (hoje.receita_atual ? Fmt.dinheiro(hoje.receita_atual) : '—');
    tr.appendChild(tdRec);

    /* --- 4. o incremento: o campo principal ------------------------------- */
    var tdInc = el('td', 'c-nego');
    tdInc.setAttribute('data-rot', 'Incremento');
    var caixaInc = el('div', 'ent');
    var inc = el('input');
    inc.type = 'text';
    inc.inputMode = 'decimal';
    inc.autocomplete = 'off';
    /* Campo vazio fica vazio mesmo. Um "0" de espaço reservado em catorze
       linhas vira uma coluna de zeros que parece preenchida — e o gerente
       não distingue de relance o que ele já digitou do que ainda falta. A
       exceção é a linha de contexto, onde a unidade ("meses") é a única
       pista do que se espera ali. */
    inc.placeholder = contexto ? (p.unidade || '') : '';
    inc.setAttribute('data-campo', 'incremento');
    inc.setAttribute('data-produto', p.codigo);
    inc.setAttribute('aria-label', 'Incremento de ' + p.nome);
    caixaInc.appendChild(inc);
    tdInc.appendChild(caixaInc);
    tr.appendChild(tdInc);

    /* --- 5. o fator ------------------------------------------------------- */
    var tdFat = el('td', 'c-nego');
    tdFat.setAttribute('data-rot', 'Fator');
    if (contexto) {
      tdFat.className += ' num num--zero';
      tdFat.textContent = '—';
    } else {
      var caixaFat = el('div', 'ent ent--fator');
      var fat = el('input');
      fat.type = 'text';
      fat.inputMode = 'decimal';
      fat.autocomplete = 'off';
      fat.value = valorDeFator(p.fator, p.tipo_fator);
      fat.setAttribute('data-campo', 'fator');
      fat.setAttribute('data-produto', p.codigo);
      fat.setAttribute('aria-label', 'Fator de ' + p.nome);
      if (!S.config.permitirNegociar) {
        fat.disabled = true;
        fat.title = 'A área desativou a negociação de fator nesta calculadora.';
      } else if (p.fator_piso !== null || p.fator_teto !== null) {
        fat.title = 'Alçada: '
          + (p.fator_piso !== null ? 'mínimo ' + Fmt.fator(p.fator_piso, p.tipo_fator) : 'sem mínimo')
          + ' · '
          + (p.fator_teto !== null ? 'máximo ' + Fmt.fator(p.fator_teto, p.tipo_fator) : 'sem máximo');
      }
      caixaFat.appendChild(fat);
      caixaFat.appendChild(el('span', 'ent__sufixo', Fmt.sufixoFator(p.tipo_fator)));
      tdFat.appendChild(caixaFat);
    }
    tr.appendChild(tdFat);

    /* --- 6 e 7. o resultado ----------------------------------------------- */
    var tdGanho = el('td', 'c-result num');
    tdGanho.setAttribute('data-rot', 'Ganho/mês');
    tdGanho.setAttribute('data-saida', 'incremento');
    tdGanho.textContent = '—';
    tr.appendChild(tdGanho);

    var tdTotal = el('td', 'c-result num num--forte');
    tdTotal.setAttribute('data-rot', 'Receita/mês');
    tdTotal.setAttribute('data-saida', 'projetada');
    tdTotal.textContent = contexto ? '—' : (hoje.receita_atual ? Fmt.dinheiro(hoje.receita_atual) : '—');
    tr.appendChild(tdTotal);

    return tr;
  }

  /* O fator aparece no campo como número simples, sem "%" nem "R$" — o
     sufixo já está desenhado ao lado. Com o símbolo dentro, toda edição
     começaria com a pessoa apagando o símbolo. */
  function valorDeFator(v, tipoFator) {
    if (!v) { return ''; }
    var casas = (tipoFator === 'TARIFA') ? 2 : ((Math.abs(v) < 0.01) ? 4 : 2);
    return Fmt.numero(v, casas);
  }


  /* --- os eventos dos campos ---------------------------------------------
     Delegados no <tbody>: uma escuta só para catorze linhas x dois campos, e
     linha nova já nasce funcionando sem ninguém religar nada. */
  function ligarNavegacaoPorTeclado() {
    var corpo = $('#sim-tbody');
    if (corpo.getAttribute('data-ligado')) { return; }
    corpo.setAttribute('data-ligado', '1');

    corpo.addEventListener('input', function (ev) {
      var alvo = ev.target;
      if (alvo.tagName !== 'INPUT') { return; }
      anotarEntrada(alvo);
      alvo.classList.toggle('tem-valor', alvo.value.trim() !== '');
      agendarCalculo();
    });

    /* Ao SAIR do campo é que o número ganha formatação. Formatar durante a
       digitação embaralha o cursor — a pessoa digita 1500 e vê o cursor
       pular para o meio quando o ponto de milhar entra. */
    corpo.addEventListener('focusout', function (ev) {
      var alvo = ev.target;
      if (alvo.tagName !== 'INPUT') { return; }

      var campo = alvo.getAttribute('data-campo');
      var codigo = alvo.getAttribute('data-produto');
      var p = produtoPor(codigo);
      if (!p) { return; }

      if (alvo.value.trim() === '') {
        if (campo === 'fator') { alvo.value = valorDeFator(p.fator, p.tipo_fator); }
        anotarEntrada(alvo);
        recalcular();
        return;
      }

      var n = Fmt.paraNumero(alvo.value, campo === 'fator');
      alvo.value = (campo === 'fator')
        ? valorDeFator(n, p.tipo_fator)
        : Fmt.quantidade(n);

      anotarEntrada(alvo);
      recalcular();
    });

    /* Ao ENTRAR no campo, o número volta a ser cru: "R$ 1.500.000" vira
       "1500000", que é o que dá para editar. A formatação volta ao sair. */
    corpo.addEventListener('focusin', function (ev) {
      var alvo = ev.target;
      if (alvo.tagName !== 'INPUT') { return; }

      var campo = alvo.getAttribute('data-campo');
      var bruto = Fmt.paraNumero(alvo.value, campo === 'fator');
      if (bruto) {
        alvo.value = String(bruto).replace('.', ',');
      }
    });

    /* ------------------------------------------------------------------
       SELECIONAR TUDO AO CLICAR, e por que isto não é um setTimeout.

       Quem clica num campo que já tem valor quer digitar por cima. A
       receita comum para isso é chamar select() dentro de um setTimeout,
       porque o clique posiciona o cursor depois do focus e desfaria uma
       seleção feita ali.

       Só que esse setTimeout corre contra a digitação. Se a pessoa clica e
       já começa a digitar — ou dá um duplo-clique e digita —, o select()
       cai no meio: num campo com "2,45", digitar "0,50" terminava em
       "20,50". Num campo de VOLUME isso é um susto; num campo de FATOR é
       um preço errado que entra calado na conta e sai no comprovante.

       Fazer no mouseup resolve porque ele acontece DEPOIS de o navegador
       posicionar o cursor e ANTES de qualquer tecla — sem espera, sem
       corrida. O preventDefault impede o próprio clique de desfazer a
       seleção que acabamos de fazer.

       Só no clique que TRAZ o foco: se o campo já estava focado, a pessoa
       está posicionando o cursor de propósito, e aí selecionar tudo seria
       atrapalhar.
       ------------------------------------------------------------------ */
    corpo.addEventListener('mousedown', function (ev) {
      var alvo = ev.target;
      if (alvo.tagName !== 'INPUT') { return; }
      alvo.setAttribute('data-trouxe-foco', alvo === document.activeElement ? '0' : '1');
    });

    corpo.addEventListener('mouseup', function (ev) {
      var alvo = ev.target;
      if (alvo.tagName !== 'INPUT') { return; }
      if (alvo.getAttribute('data-trouxe-foco') !== '1') { return; }

      alvo.setAttribute('data-trouxe-foco', '0');
      if (alvo.value === '') { return; }

      ev.preventDefault();
      alvo.select();
    });

    /* Enter e setas descem a coluna. Quem preenche catorze produtos seguidos
       não quer tirar a mão do teclado para clicar no próximo campo. */
    corpo.addEventListener('keydown', function (ev) {
      var alvo = ev.target;
      if (alvo.tagName !== 'INPUT') { return; }

      if (ev.key === 'Enter' || ev.key === 'ArrowDown') {
        ev.preventDefault();
        irPara(alvo, 1);
      } else if (ev.key === 'ArrowUp') {
        ev.preventDefault();
        irPara(alvo, -1);
      }
    });
  }

  function irPara(deQuem, passo) {
    var campo = deQuem.getAttribute('data-campo');
    var todos = $$('#sim-tbody input[data-campo="' + campo + '"]:not([disabled])');
    var i = todos.indexOf(deQuem);
    if (i < 0) { return; }

    var prox = todos[i + passo];
    if (!prox) { return; }

    prox.focus();
    /* focus() por código não seleciona o conteúdo — o Tab do navegador
       seleciona, mas o nosso Enter não. Sem este select(), descer a coluna
       com Enter deixaria o cursor no fim de um valor já preenchido, e o
       número novo sairia grudado no antigo. */
    prox.select();
  }

  function anotarEntrada(input) {
    var codigo = input.getAttribute('data-produto');
    var campo  = input.getAttribute('data-campo');
    var p = produtoPor(codigo);
    if (!p) { return; }

    if (!S.entradas[codigo]) { S.entradas[codigo] = { incremento: 0, fator: '' }; }

    var texto = input.value.trim();

    if (campo === 'incremento') {
      S.entradas[codigo].incremento = texto === '' ? 0 : Fmt.paraNumero(texto, false);
    } else {
      /* Fator igual ao padrão não conta como negociado — assim a linha não
         fica marcada de laranja só porque alguém clicou no campo e saiu. */
      if (texto === '') {
        S.entradas[codigo].fator = '';
      } else {
        var n = Fmt.paraNumero(texto, true);
        S.entradas[codigo].fator = (Math.abs(n - p.fator) < 0.00000001) ? '' : n;
      }
      input.classList.toggle('negociado', S.entradas[codigo].fator !== '');
    }
  }

  function produtoPor(codigo) {
    for (var i = 0; i < S.produtos.length; i++) {
      if (S.produtos[i].codigo === codigo) { return S.produtos[i]; }
    }
    return null;
  }


  /* =========================================================================
     5. O CÁLCULO E O PAINEL
     ======================================================================= */
  var timerCalculo = null;

  function agendarCalculo() {
    clearTimeout(timerCalculo);
    timerCalculo = setTimeout(recalcular, CFG.ESPERA_CALCULO || 120);
  }

  function recalcular() {
    if (!S.cliente) { return; }

    S.resultado = window.Motor.calcular(S.produtos, S.atual, S.entradas, S.config);

    pintarLinhas(S.resultado.linhas);
    pintarTotais(S.resultado.totais);
    pintarVeredito(S.resultado);
  }

  function pintarLinhas(linhas) {
    linhas.forEach(function (l) {
      var tr = $('#sim-tbody tr[data-produto="' + l.codigo + '"]');
      if (!tr) { return; }

      var ganho = $('[data-saida="incremento"]', tr);
      var total = $('[data-saida="projetada"]', tr);

      if (l.contexto) { return; }

      if (l.receita_incremento > 0) {
        ganho.textContent = '+' + Fmt.dinheiro(l.receita_incremento);
        ganho.className = 'c-result num num--ok';
      } else {
        ganho.textContent = '—';
        ganho.className = 'c-result num num--zero';
      }

      total.textContent = l.receita_projetada > 0 ? Fmt.dinheiro(l.receita_projetada) : '—';
      total.className = 'c-result num ' + (l.receita_projetada > 0 ? 'num--forte' : 'num--zero');

      /* Mesma ideia da marca acima, agora para o resultado. */
      tr.classList.toggle('tem-valor', l.receita_projetada > 0 || l.receita_incremento > 0);

      /* O alerta de divergência: a receita que o cliente paga hoje não bate
         com o que o fator da tabela daria. Não é erro — costuma ser acordo
         antigo — mas é exatamente o assunto que vale levar para a reunião. */
      var jaTem = $('.flag-div', tr);
      if (l.divergente && !jaTem) {
        var flag = el('span', 'flag-div');
        flag.appendChild(icone('i-alert'));
        flag.title = 'A receita atual desta linha não bate com o fator da tabela. '
                   + 'Pela tabela daria outro valor — pode haver condição negociada.';
        $('.prod', tr).appendChild(flag);
      } else if (!l.divergente && jaTem) {
        jaTem.parentNode.removeChild(jaTem);
      }
    });
  }

  function pintarTotais(t) {
    $('#tot-receita-hoje').textContent = Fmt.dinheiro(t.receita_atual_mes);
    $('#tot-incremento').textContent   = t.receita_incremento_mes > 0
      ? '+' + Fmt.dinheiro(t.receita_incremento_mes) : '—';
    $('#tot-projetada').textContent    = Fmt.dinheiro(t.receita_projetada_mes);
  }

  function pintarVeredito(r) {
    var v = r.veredito;
    var t = r.totais;

    var caixa = $('#veredito');
    var mapa = { APROVADO: 'ok', ATENCAO: 'aviso', REPROVADO: 'erro', VAZIO: '' };
    caixa.className = 'veredito' + (mapa[v.status] ? ' veredito--' + mapa[v.status] : '');

    var icones = { APROVADO: 'i-check-circle', ATENCAO: 'i-alert', REPROVADO: 'i-x', VAZIO: 'i-calc' };
    var alvoIcone = $('#veredito-icone');
    limpar(alvoIcone);
    alvoIcone.appendChild(icone(icones[v.status] || 'i-calc', 'ic--lg'));

    $('#veredito-titulo').textContent = v.titulo;
    $('#veredito-sub').textContent = t.houve_entrada
      ? (t.variacao_pct !== 0 ? Fmt.percentual(t.variacao_pct, true) + ' sobre a receita atual' : 'cliente novo')
      : 'nada informado ainda';

    $('#veredito-texto').textContent = v.texto;
    $('#veredito-regua').textContent = v.regua;

    $('#res-hoje').textContent      = Fmt.dinheiro(t.receita_atual_mes);
    $('#res-projetada').textContent = Fmt.dinheiro(t.receita_projetada_mes);
    $('#res-incremento').textContent= t.receita_incremento_mes > 0
      ? '+' + Fmt.dinheiro(t.receita_incremento_mes) : Fmt.dinheiro(0);
    $('#res-ano').textContent       = Fmt.dinheiro(t.receita_ano);
    $('#res-ano-rot').textContent   = 'Receita em ' + t.meses + ' meses';

    var delta = $('#res-delta');
    if (t.houve_entrada && t.receita_atual_mes > 0) {
      delta.textContent = Fmt.percentual(t.variacao_pct, true);
      delta.className = 'res__delta ' + (t.variacao_pct >= 0 ? 'res__delta--sobe' : 'res__delta--desce');
      mostrar(delta, true);
    } else {
      mostrar(delta, false);
    }

    $('#btn-pdf').disabled = !(t.houve_entrada && !S.salvando);
  }


  /* =========================================================================
     6. LIMPAR, SALVAR, COPIAR
     ======================================================================= */
  function limparSimulacao() {
    S.entradas = {};

    $$('#sim-tbody input').forEach(function (i) {
      var p = produtoPor(i.getAttribute('data-produto'));
      if (i.getAttribute('data-campo') === 'fator') {
        i.value = p ? valorDeFator(p.fator, p.tipo_fator) : '';
        i.classList.remove('negociado');
      } else {
        i.value = '';
        i.classList.remove('tem-valor');
      }
    });

    recalcular();
    recado('Simulação limpa. Os dados do cliente continuam carregados.');
  }

  function abrirSalvar() {
    if (!S.resultado || !S.resultado.totais.houve_entrada) { return; }

    $('#salvar-resumo').textContent =
      Fmt.nomeBonito(S.cliente.razao_social) + ' · ' + S.resultado.veredito.titulo
      + ' · ' + Fmt.dinheiro(S.resultado.totais.receita_projetada_mes) + '/mês';

    $('#salvar-obs').value = '';
    abrirModal('#modal-salvar');
    setTimeout(function () { $('#salvar-obs').focus(); }, 60);
  }

  /* =========================================================================
     GERAR O PDF

     Um botão só, e ele faz as duas coisas que sempre andaram juntas: registra
     a simulação e produz o documento. Separá-las em dois botões criava uma
     escolha que ninguém quer fazer — "salvar" e "salvar em PDF" lado a lado
     não dizem em que diferem —, e abria a porta para o caso pior: o PDF na
     mão do cliente sem registro nenhum do lado de cá.

     Gravando antes, o protocolo sai impresso no documento. É o que permite
     alguém pegar o papel meses depois e reencontrar a simulação exata.
     ======================================================================= */
  function gerarPdf() {
    if (S.salvando) { return; }
    S.salvando = true;
    $('#salvar-confirmar').disabled = true;

    /* Só o volume e o fator sobem. Os totais que a tela calculou ficam aqui —
       o servidor refaz a conta do zero, e é ele quem decide o resultado
       gravado. Ver o cabeçalho de api/simulacao.php. */
    var entradas = {};
    Object.keys(S.entradas).forEach(function (codigo) {
      var e = S.entradas[codigo];
      if (e.incremento || e.fator !== '') {
        entradas[codigo] = { incremento: e.incremento, fator: e.fator === '' ? null : e.fator };
      }
    });

    var observacao = $('#salvar-obs').value;

    mandar(CFG.API.simulacao, {
      nivel: S.cliente.nivel,
      chave: S.cliente.chave,
      razao_social: S.cliente.razao_social,
      entradas: entradas,
      observacao: observacao
    }).then(function (d) {
      fecharModais();

      /* O que vai para o papel é o que o servidor calculou, não o que a tela
         tinha. Se os dois discordarem — e não deveriam —, quem vale é o
         gravado, porque é ele que alguém vai reencontrar pelo protocolo. */
      if (d.resultado) {
        S.resultado = d.resultado;
        pintarLinhas(d.resultado.linhas);
        pintarTotais(d.resultado.totais);
        pintarVeredito(d.resultado);
      }

      montarFolha(d.protocolo, observacao);
      carregarHistorico();

      recado('Simulação ' + d.protocolo + ' registrada. Escolha "Salvar como PDF" em Destino.');

      /* Um instante para o recado aparecer antes de o diálogo travar a tela.
         Sem isso o navegador abre a janela por cima e ninguém lê o aviso. */
      setTimeout(function () { window.print(); }, 450);

    }).catch(function (e) {
      recado(explicarErro(e), 'erro');
    }).then(function () {
      S.salvando = false;
      $('#salvar-confirmar').disabled = false;
    });
  }


  /* -------------------------------------------------------------------------
     A FOLHA

     Monta o documento de uma página. Não é a tela reaproveitada: a tela tem
     catorze produtos, campos de digitação e um painel que acompanha a
     rolagem, tudo útil enquanto se negocia e nenhum deles útil no papel.

     O corte que faz caber em uma página é este: entram só as linhas que têm
     história — as que o cliente já usa ou as que ele vai passar a usar. Um
     produto zerado dos dois lados não diz nada e ocuparia a linha que falta
     para o veredito caber na mesma página.
     ----------------------------------------------------------------------- */
  function montarFolha(protocolo, observacao) {
    var r = S.resultado, c = S.cliente, t = r.totais;

    /* --- cabeçalho -------------------------------------------------------- */
    $('#folha-titulo').textContent = (S.config.titulo || 'Calculadora de Pricing');
    $('#folha-sub').textContent    = (S.config.subtitulo || '') + ' · simulação de negociação';
    $('#folha-protocolo').textContent = protocolo || '';
    $('#folha-data').textContent = new Date().toLocaleString('pt-BR');

    /* --- cliente ---------------------------------------------------------- */
    $('#folha-cliente').textContent = Fmt.nomeBonito(c.razao_social) || c.chave_exibicao;

    var ident = [];
    ident.push((c.nivel === 'GRUPO' ? 'Grupo econômico ' : (c.nivel === 'CNPJ' ? 'CNPJ ' : 'Conta '))
               + c.chave_exibicao);
    if (c.nivel !== 'CNPJ' && c.cnpj_exibicao) { ident.push('CNPJ ' + c.cnpj_exibicao); }
    if (c.segmento) { ident.push(c.segmento); }
    if (c.contas_abrangidas > 1) { ident.push(c.contas_abrangidas + ' contas'); }
    if (c.referencia) { ident.push('dados de ' + Fmt.referencia(c.referencia)); }
    $('#folha-ident').textContent = ident.join('  ·  ');

    /* --- veredito --------------------------------------------------------- */
    var mapa = { APROVADO: 'ok', ATENCAO: 'aviso', REPROVADO: 'erro', VAZIO: '' };
    $('#folha-veredito').className = 'folha__veredito'
      + (mapa[r.veredito.status] ? ' folha__veredito--' + mapa[r.veredito.status] : '');
    $('#folha-vtitulo').textContent = r.veredito.titulo;
    $('#folha-vvar').textContent = (t.receita_atual_mes > 0)
      ? Fmt.percentual(t.variacao_pct, true) + ' sobre a receita atual'
      : 'cliente sem receita hoje';
    $('#folha-vtexto').textContent = r.veredito.texto + ' ' + r.veredito.regua;

    /* --- os quatro números ------------------------------------------------ */
    var nums = $('#folha-numeros');
    limpar(nums);

    [
      ['Receita hoje',                    Fmt.dinheiro(t.receita_atual_mes),      false],
      ['Receita projetada',               Fmt.dinheiro(t.receita_projetada_mes),  false],
      ['Incremento por mês',              Fmt.dinheiro(t.receita_incremento_mes), true ],
      ['Receita em ' + t.meses + ' meses', Fmt.dinheiro(t.receita_ano),           false]
    ].forEach(function (n) {
      var bloco = el('div', 'folha__num' + (n[2] ? ' folha__num--forte' : ''));
      bloco.appendChild(el('div', 'folha__num-rot', n[0]));
      bloco.appendChild(el('div', 'folha__num-val', n[1]));
      nums.appendChild(bloco);
    });

    /* --- as linhas -------------------------------------------------------- */
    var corpo = $('#folha-linhas');
    limpar(corpo);

    var contexto = [];

    r.linhas.forEach(function (l) {
      /* Contexto não tem receita: vira uma nota de rodapé, não uma linha de
         tabela com cinco traços. */
      if (l.contexto) {
        if (l.incremento) {
          contexto.push(l.nome + ': ' + Fmt.quantidade(l.incremento) + (l.unidade ? ' ' + l.unidade : ''));
        }
        return;
      }
      /* O corte que faz caber em uma página. */
      if (!l.incremento && !l.receita_atual) { return; }

      var tr = el('tr');
      if (l.incremento) { tr.className = 'folha__tab-nova'; }

      tr.appendChild(el('td', 'folha__tab-prod', l.nome));
      tr.appendChild(el('td', null, l.volume_atual ? Fmt.volume(l.volume_atual, l.tipo_volume) : '—'));
      tr.appendChild(el('td', null, l.receita_atual ? Fmt.dinheiro(l.receita_atual) : '—'));

      var inc = el('td', 'folha__tab-inc');
      inc.textContent = l.incremento ? Fmt.quantidade(l.incremento) : '—';
      tr.appendChild(inc);

      var fat = el('td', 'folha__tab-inc');
      fat.textContent = Fmt.fator(l.fator_usado, l.tipo_fator);
      /* Fator negociado é a informação que a mesa vai querer conferir: sai
         marcado, e não misturado com os que vieram da tabela. */
      if (l.fator_negociado) { fat.className += ' folha__tab-neg'; fat.textContent += ' *'; }
      tr.appendChild(fat);

      tr.appendChild(el('td', 'folha__tab-ganho',
        l.receita_incremento ? '+' + Fmt.dinheiro(l.receita_incremento) : '—'));
      tr.appendChild(el('td', 'folha__tab-total',
        l.receita_projetada ? Fmt.dinheiro(l.receita_projetada) : '—'));

      corpo.appendChild(tr);
    });

    /* --- o total ---------------------------------------------------------- */
    var pe = $('#folha-total');
    limpar(pe);

    var trT = el('tr');
    trT.appendChild(el('td', 'folha__tab-prod', 'Total'));
    trT.appendChild(el('td', null, ''));
    trT.appendChild(el('td', null, Fmt.dinheiro(t.receita_atual_mes)));
    trT.appendChild(el('td', null, ''));
    trT.appendChild(el('td', null, ''));
    trT.appendChild(el('td', 'folha__tab-ganho', '+' + Fmt.dinheiro(t.receita_incremento_mes)));
    trT.appendChild(el('td', 'folha__tab-total', Fmt.dinheiro(t.receita_projetada_mes)));
    pe.appendChild(trT);

    /* --- contexto e observação -------------------------------------------- */
    var ctx = $('#folha-contexto');
    limpar(ctx);
    if (contexto.length) {
      ctx.appendChild(el('span', 'folha__rot', 'Contexto da negociação: '));
      ctx.appendChild(document.createTextNode(contexto.join('  ·  ')));
    }
    mostrar(ctx, contexto.length > 0);

    var obs = $('#folha-obs');
    limpar(obs);
    if (observacao && observacao.trim()) {
      obs.appendChild(el('span', 'folha__rot', 'Observação: '));
      obs.appendChild(document.createTextNode(observacao.trim()));
    }
    mostrar(obs, !!(observacao && observacao.trim()));

    /* --- rodapé ------------------------------------------------------------ */
    var temNegociado = r.linhas.some(function (l) { return l.fator_negociado; });
    $('#folha-pe').textContent =
      'Simulado por ' + (S.usuario.nome || S.usuario.email)
      + (S.usuario.funcional ? ' (' + S.usuario.funcional + ')' : '')
      + '.  Valores simulados, sem compromisso contratual.'
      + (temNegociado ? '  (*) fator negociado fora da tabela padrão.' : '');
  }

  /* =========================================================================
     7. HISTÓRICO
     ======================================================================= */
  function carregarHistorico() {
    pegar(CFG.API.simulacao, { limite: CFG.HISTORICO_QUANTOS }).then(function (d) {
      var lista = $('#hist-lista');
      limpar(lista);

      if (!d.simulacoes.length) { mostrar($('#hist-card'), false); return; }
      mostrar($('#hist-card'), true);

      d.simulacoes.forEach(function (s) {
        var b = el('button', 'sim-card');
        b.type = 'button';

        var topo = el('div', 'sim-card__topo');
        topo.appendChild(el('span', 'sim-card__prot', s.protocolo));

        var mapa = { APROVADO: 'chip--ok', ATENCAO: 'chip--aviso', REPROVADO: 'chip--erro' };
        var rot  = { APROVADO: 'Vale', ATENCAO: 'Analisar', REPROVADO: 'Não vale' };
        topo.appendChild(chip(null, rot[s.veredito] || s.veredito, mapa[s.veredito]));
        b.appendChild(topo);

        b.appendChild(el('div', 'sim-card__nome', Fmt.nomeBonito(s.razao_social) || s.chave));
        b.appendChild(el('div', 'sim-card__num', Fmt.dinheiro(s.receita_projetada_mes) + '/mês'));
        b.appendChild(el('div', 'sim-card__meta',
          (s.receita_atual_mes > 0 ? Fmt.percentual(s.variacao_pct, true) + '  ·  ' : '')
          + Fmt.quando(s.criado_em)));

        b.addEventListener('click', function () {
          pegar(CFG.API.cliente, { nivel: s.nivel, chave: s.chave })
            .then(aplicarCliente)
            .catch(function (e) { recado(explicarErro(e), 'erro'); });
        });

        lista.appendChild(b);
      });
    }).catch(function () {
      /* O histórico é conveniência: se falhar, a calculadora continua
         inteira. Não vale interromper o trabalho com um erro por causa
         de uma lista de consulta. */
      mostrar($('#hist-card'), false);
    });
  }


  /* =========================================================================
     MODAIS
     ======================================================================= */
  function abrirModal(sel) {
    fecharModais();
    var m = $(sel);
    if (m) { m.classList.add('aberto'); }
  }
  function fecharModais() {
    $$('.modal').forEach(function (m) { m.classList.remove('aberto'); });
  }


  /* ======================================================================= */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
})();
