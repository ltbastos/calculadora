/* ============================================================================
   O motor de cálculo — versão da tela

   ---------------------------------------------------------------------------
   ESTE ARQUIVO TEM UM GÊMEO: api/motor.php

   A tela calcula a cada tecla, porque a graça da ferramenta é ver o veredito
   mudar enquanto se negocia. O servidor recalcula tudo de novo na hora de
   gravar, porque uma simulação salva é uma decisão comercial e não pode
   depender do que uma aba aberta desde ontem achava que era o fator.

   MEXEU AQUI, MEXA LÁ. E confira docs/CALCULO.md, que descreve a conta em
   português e é quem decide quando os dois discordarem.

   ---------------------------------------------------------------------------
   O ARREDONDAMENTO, que é onde os dois gêmeos brigam se ninguém cuidar:

   JavaScript guarda números em binário, e 1.005 na verdade está guardado como
   1.00499999999999989. Math.round(1.005 * 100) devolve 100, não 101 — e o PHP,
   que corrige isso internamente, devolveria 1.01. Um centavo de diferença
   entre a tela e o comprovante gravado é o tipo de coisa que ninguém consegue
   explicar numa reunião.

   Por isso todo arredondamento daqui passa por arredondar(), que empurra o
   número um epsilon para cima antes de arredondar. É a correção padrão para
   esse caso e deixa os dois lados dando o mesmo resultado.
   ========================================================================== */
(function () {
  'use strict';

  function arredondar(v, casas) {
    if (typeof v !== 'number' || !isFinite(v)) { return 0; }
    if (casas === undefined) { casas = 2; }

    var f = Math.pow(10, casas);
    return Math.round((v * f) * (1 + Number.EPSILON)) / f;
  }


  /* =========================================================================
     Uma linha: volume x fator, respeitando o tipo do produto.
     Espelha pricingReceitaDaLinha().
     ======================================================================= */
  function receitaDaLinha(produto, volume, fator, meses) {
    var vazio = { mes: 0, ano: 0 };

    if (produto.tipo_volume === 'CONTEXTO' || produto.tipo_fator === 'NENHUM') { return vazio; }

    volume = Number(volume) || 0;
    fator  = Number(fator)  || 0;
    if (volume === 0 || fator === 0) { return vazio; }
    if (!meses || meses <= 0) { meses = 12; }

    /* TARIFA -> reais por unidade. TAXA -> pontos percentuais, daí o /100.
       0,35 quer dizer 0,35% e não 35%. */
    var bruto = (produto.tipo_fator === 'TARIFA')
      ? volume * fator
      : volume * (fator / 100);

    if (produto.periodicidade === 'ANUAL') {
      /* O volume digitado já é o do ano (o caso do TPV): a receita calculada
         também é anual, e o mensal sai da divisão. */
      return { mes: arredondar(bruto / meses), ano: arredondar(bruto) };
    }

    return { mes: arredondar(bruto), ano: arredondar(bruto * meses) };
  }


  /* =========================================================================
     O fator que vale para a linha, preso ao piso e ao teto.
     Espelha pricingFatorEfetivo().
     ======================================================================= */
  function fatorEfetivo(produto, fatorPedido, podeNegociar) {
    var padrao = Number(produto.fator) || 0;

    if (!podeNegociar || fatorPedido === null || fatorPedido === undefined || fatorPedido === '') {
      return { fator: padrao, negociado: false, ajustado: false };
    }

    var pedido = Number(fatorPedido);
    if (!isFinite(pedido)) { return { fator: padrao, negociado: false, ajustado: false }; }
    if (pedido === padrao) { return { fator: padrao, negociado: false, ajustado: false }; }

    var ajustado = false;

    if (produto.fator_piso !== null && produto.fator_piso !== undefined && pedido < produto.fator_piso) {
      pedido = produto.fator_piso; ajustado = true;
    }
    if (produto.fator_teto !== null && produto.fator_teto !== undefined && pedido > produto.fator_teto) {
      pedido = produto.fator_teto; ajustado = true;
    }
    if (pedido < 0) { pedido = 0; ajustado = true; }

    return { fator: pedido, negociado: (pedido !== padrao), ajustado: ajustado };
  }


  /* =========================================================================
     A simulação inteira. Espelha pricingCalcular().
     ======================================================================= */
  function calcular(produtos, atual, entradas, cfg) {
    var meses         = (cfg && cfg.meses > 0) ? cfg.meses : 12;
    var podeNegociar  = !!(cfg && cfg.permitirNegociar);
    var margemAlerta  = (cfg && cfg.alertaDivergenciaPct !== undefined) ? Number(cfg.alertaDivergenciaPct) : 10;

    var linhas = [];
    var totalAtual = 0, totalIncremento = 0, totalAno = 0;
    var houveEntrada = false;

    produtos.forEach(function (p) {
      var hoje = atual[p.codigo] || null;
      var volumeAtual  = hoje ? Number(hoje.volume_atual)  || 0 : 0;
      var receitaAtual = hoje ? Number(hoje.receita_atual) || 0 : 0;

      var entrada    = entradas[p.codigo] || {};
      var incremento = Number(entrada.incremento) || 0;
      var fatorDito  = (entrada.fator === '' || entrada.fator === undefined) ? null : entrada.fator;

      var f = fatorEfetivo(p, fatorDito, podeNegociar);

      /* O incremento rende pelo fator efetivo. O "hoje" NÃO é recalculado:
         vem do banco como está, porque pode carregar acordo antigo que o
         fator padrão não reproduz. */
      var receitaIncremento = receitaDaLinha(p, incremento, f.fator, meses);

      /* Quanto o "hoje" renderia pela tabela de agora. Só para acender o
         alerta de divergência — não entra em soma nenhuma. */
      var receitaTabela = receitaDaLinha(p, volumeAtual, Number(p.fator) || 0, meses);

      var divergente = false;
      if (receitaAtual > 0 && receitaTabela.mes > 0) {
        var dif = Math.abs(receitaAtual - receitaTabela.mes) / receitaTabela.mes * 100;
        divergente = (dif > margemAlerta);
      }

      var contexto = (p.tipo_volume === 'CONTEXTO' || p.tipo_fator === 'NENHUM');

      var projetadaMes = contexto ? 0 : arredondar(receitaAtual + receitaIncremento.mes);
      var projetadaAno = contexto ? 0 : arredondar(projetadaMes * meses);

      /* Produto anual já tem o ano calculado direto do volume anual; passar
         pelo x12 do mensal traria de volta o erro da divisão feita lá em cima. */
      if (!contexto && p.periodicidade === 'ANUAL') {
        projetadaAno = arredondar((receitaAtual * meses) + receitaIncremento.ano);
      }

      if (incremento !== 0) { houveEntrada = true; }

      linhas.push({
        codigo: p.codigo,
        nome: p.nome,
        grupo: p.grupo,
        tipo_volume: p.tipo_volume,
        tipo_fator: p.tipo_fator,
        periodicidade: p.periodicidade,
        unidade: p.unidade,
        contexto: contexto,

        volume_atual: volumeAtual,
        receita_atual: arredondar(receitaAtual),

        incremento: incremento,
        fator_padrao: Number(p.fator) || 0,
        fator_usado: f.fator,
        fator_negociado: f.negociado,
        fator_ajustado: f.ajustado,

        receita_incremento: receitaIncremento.mes,
        receita_projetada: projetadaMes,
        receita_ano: projetadaAno,
        divergente: divergente
      });

      if (!contexto) {
        totalAtual      += arredondar(receitaAtual);
        totalIncremento += receitaIncremento.mes;
        totalAno        += projetadaAno;
      }
    });

    /* Somar valores JÁ arredondados, e não arredondar a soma no fim: assim o
       total é exatamente a soma das linhas que a pessoa vê na tela. */
    totalAtual      = arredondar(totalAtual);
    totalIncremento = arredondar(totalIncremento);
    totalAno        = arredondar(totalAno);

    var totalProjetada = arredondar(totalAtual + totalIncremento);

    var variacao = (totalAtual > 0)
      ? arredondar(totalIncremento / totalAtual * 100, 4)
      : 0;

    return {
      linhas: linhas,
      totais: {
        receita_atual_mes: totalAtual,
        receita_incremento_mes: totalIncremento,
        receita_projetada_mes: totalProjetada,
        receita_ano: totalAno,
        variacao_pct: variacao,
        houve_entrada: houveEntrada,
        meses: meses
      },
      veredito: veredito(totalAtual, totalProjetada, totalIncremento, variacao, houveEntrada, cfg)
    };
  }


  /* =========================================================================
     O veredito. Espelha pricingVeredito().

     Dois caminhos, porque são duas perguntas:
       cliente que já rende   "cresceu o suficiente?"  -> régua percentual
       cliente que não rende  "vale abrir?"            -> régua em reais

     O segundo não é detalhe: percentual sobre zero não existe, e sem régua
     própria todo prospect cairia no mesmo veredito sem sentido.
     ======================================================================= */
  function veredito(atual, projetado, incremento, variacao, houveEntrada, cfg) {
    var D = window.Fmt.dinheiro;
    var P = window.Fmt.percentual;

    if (!houveEntrada) {
      return {
        status: 'VAZIO',
        titulo: 'Aguardando a proposta',
        texto: 'Preencha o que o cliente traz na negociação para ver o resultado.',
        regua: ''
      };
    }

    cfg = cfg || {};
    var pctAprovado  = Number(cfg.pctAprovado)  || 15;
    var pctAtencao   = Number(cfg.pctAtencao)   || 5;
    var pisoAprovado = Number(cfg.prospectPisoAprovado) || 5000;
    var pisoAtencao  = Number(cfg.prospectPisoAtencao)  || 1500;

    /* ---- cliente novo, ou sem receita hoje ----------------------------- */
    if (atual <= 0) {
      if (projetado >= pisoAprovado) {
        return {
          status: 'APROVADO',
          titulo: 'Vale a pena',
          texto: 'Cliente sem receita hoje. A proposta gera ' + D(projetado)
               + ' por mês, acima do mínimo de ' + D(pisoAprovado) + '.',
          regua: 'Régua de cliente novo: mínimo de ' + D(pisoAprovado) + '/mês.'
        };
      }
      if (projetado >= pisoAtencao) {
        return {
          status: 'ATENCAO',
          titulo: 'Precisa de análise',
          texto: 'A proposta gera ' + D(projetado) + ' por mês. Fica entre o mínimo aceitável de '
               + D(pisoAtencao) + ' e o ideal de ' + D(pisoAprovado) + '.',
          regua: 'Régua de cliente novo: ideal ' + D(pisoAprovado) + '/mês, mínimo ' + D(pisoAtencao) + '/mês.'
        };
      }
      return {
        status: 'REPROVADO',
        titulo: 'Não compensa',
        texto: 'A proposta gera ' + D(projetado) + ' por mês, abaixo do mínimo de '
             + D(pisoAtencao) + ' para abrir relacionamento.',
        regua: 'Régua de cliente novo: mínimo ' + D(pisoAtencao) + '/mês.'
      };
    }

    /* ---- cliente que já rende ------------------------------------------ */
    if (variacao >= pctAprovado) {
      return {
        status: 'APROVADO',
        titulo: 'Vale a pena',
        texto: 'A receita cresce ' + P(variacao) + ', o equivalente a ' + D(incremento)
             + ' a mais por mês. Acima da meta de ' + P(pctAprovado) + '.',
        regua: 'Régua: crescimento de ' + P(pctAprovado) + ' sobre a receita atual.'
      };
    }
    if (variacao >= pctAtencao) {
      return {
        status: 'ATENCAO',
        titulo: 'Precisa de análise',
        texto: 'A receita cresce ' + P(variacao) + ' (' + D(incremento) + ' por mês). '
             + 'Fica abaixo da meta de ' + P(pctAprovado) + ', mas acima do mínimo de ' + P(pctAtencao) + '.',
        regua: 'Régua: meta ' + P(pctAprovado) + ', mínimo ' + P(pctAtencao) + '.'
      };
    }
    return {
      status: 'REPROVADO',
      titulo: 'Não compensa',
      texto: 'A receita cresce apenas ' + P(variacao) + ' (' + D(incremento) + ' por mês), '
           + 'abaixo do mínimo de ' + P(pctAtencao) + '.',
      regua: 'Régua: mínimo de ' + P(pctAtencao) + ' de crescimento.'
    };
  }


  window.Motor = {
    calcular: calcular,
    receitaDaLinha: receitaDaLinha,
    fatorEfetivo: fatorEfetivo,
    arredondar: arredondar
  };
})();
