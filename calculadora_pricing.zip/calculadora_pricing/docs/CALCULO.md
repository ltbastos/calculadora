# A conta, explicada

Este documento é a **fonte da verdade** do cálculo. Existem duas
implementações dele — `src/motor.js`, que calcula na tela enquanto a pessoa
digita, e `api/motor.php`, que recalcula tudo na hora de gravar. Quando as
duas discordarem, é este texto que decide qual está errada.

`testes/gemeos.js` compara as duas automaticamente. Rode depois de mexer em
qualquer uma:

```
node testes/gemeos.js
```

---

## 1. Cada produto declara como cobra

Não existe uma fórmula só, porque os produtos do banco não cobram do mesmo
jeito. Boleto cobra **por unidade emitida**; Invest Fácil cobra **um
percentual sobre o saldo**. Por isso cada produto guarda dois tipos:

| Campo | Valores | O que significa |
|---|---|---|
| `tipo_volume` | `QUANTIDADE` | o gerente digita unidades (boletos, funcionários) |
| | `VALOR` | o gerente digita reais |
| | `CONTEXTO` | não gera receita nenhuma (ex.: prazo de contrato) |
| `tipo_fator` | `TARIFA` | o fator está **em reais por unidade** |
| | `TAXA` | o fator está **em pontos percentuais** |
| | `NENHUM` | não cobra |
| `periodicidade` | `MENSAL` | o volume digitado é de um mês |
| | `ANUAL` | o volume digitado já é o do ano inteiro (ex.: TPV) |

### O formato do fator, que é onde se erra

```
TARIFA   2.45  =  R$ 2,45 por boleto
TAXA     0.35  =  0,35 %        (e NÃO 35%)
```

A tela de administração mostra, embaixo de cada campo, como o número está
sendo lido — "lê-se R$ 2,45", "lê-se 0,35%". Essa linha existe só para evitar
que alguém digite `35` quando queria dizer `0,35`.

---

## 2. A receita de uma linha

```
TARIFA:   receita = volume × fator
TAXA:     receita = volume × (fator ÷ 100)
CONTEXTO: receita = 0          (não entra em soma nenhuma)
```

E então, conforme a periodicidade:

```
MENSAL:   receita_mês = receita
          receita_ano = receita × meses

ANUAL:    receita_ano = receita          (o volume já era do ano)
          receita_mês = receita ÷ meses
```

`meses` é o parâmetro `meses_projecao`, normalmente 12.

Todo produto devolve **sempre o par mês/ano**, mesmo o anual. É isso que
permite somar o TPV (anual) junto com o Pix (mensal) sem confundir as bases.

### Exemplos conferíveis

```
Invest Fácil    R$ 2.000.000 × 0,35%   = R$ 7.000,00 /mês
Cobrança qtde        3.000  × R$ 2,45  = R$ 7.350,00 /mês
Pix             R$ 2.000.000 × 0,02%   =   R$ 400,00 /mês

TPV (anual)     R$ 6.000.000 × 0,89%   = R$ 53.400,00 /ano
                                        =  R$ 4.450,00 /mês
```

---

## 3. O que o cliente já tem hoje **não** é recalculado

A receita atual vem do banco (`fdados_produto.receita_atual`) e é usada como
está. Ela **não** é refeita a partir do volume × fator.

Isso é proposital: o que o cliente paga hoje pode ter desconto, acordo antigo
ou condição especial que o fator padrão da tabela não reproduz. Recalcular
apagaria essa realidade.

Quando os dois números divergem além do parâmetro `alerta_divergencia_pct`
(padrão 10%), a tela **sinaliza a linha** com um triângulo — mas não muda o
valor. Essa diferença costuma ser justamente o assunto da reunião.

---

## 4. O fator negociado, e a alçada

Quando `permitir_negociar_fator` está ligado, o gerente pode alterar o fator
de cada linha. O valor é preso ao piso e ao teto do produto:

```
pedido < fator_piso  ->  usa fator_piso,  ajustado = true
pedido > fator_teto  ->  usa fator_teto,  ajustado = true
pedido < 0           ->  usa 0,           ajustado = true
```

O limite é aplicado **nos dois motores**, não só na tela: campo desabilitado
no navegador é sugestão, não regra.

Piso ou teto vazios (`NULL`) significam "sem limite" — e é diferente de zero.
Piso zero quer dizer "não pode negociar abaixo de zero"; piso vazio quer
dizer "não tem piso".

---

## 5. Os totais

```
receita_atual_mes      = Σ receita_atual de cada linha
receita_incremento_mes = Σ receita do incremento de cada linha
receita_projetada_mes  = receita_atual_mes + receita_incremento_mes
receita_ano            = Σ receita_ano de cada linha
variacao_pct           = receita_incremento_mes ÷ receita_atual_mes × 100
```

Linhas de `CONTEXTO` ficam fora de todas as somas.

### Por que somamos valores já arredondados

Cada linha é arredondada para centavos **antes** de entrar na soma, e a soma
não é arredondada de novo. Assim o total da tela é exatamente a soma das
linhas que a pessoa está vendo — e ninguém precisa explicar um centavo de
diferença numa reunião.

### O arredondamento, e a armadilha entre as linguagens

JavaScript guarda `1.005` como `1.00499999999999989`, então
`Math.round(1.005 * 100)` devolve `100` e não `101`. O PHP, que corrige isso
internamente, devolveria `1.01`.

Por isso `src/motor.js` arredonda através de uma função própria que empurra o
número um epsilon para cima antes de arredondar. Sem ela, a tela e o
comprovante gravado divergiriam em centavos.

---

## 6. O veredito

São **duas réguas**, porque são duas perguntas diferentes.

### Cliente que já rende (`receita_atual_mes > 0`)

A pergunta é *"cresceu o suficiente?"*, e a régua é percentual:

```
variacao ≥ veredito_pct_aprovado   ->  APROVADO    "Vale a pena"
variacao ≥ veredito_pct_atencao    ->  ATENCAO     "Precisa de análise"
abaixo disso                       ->  REPROVADO   "Não compensa"
```

### Cliente sem receita hoje (`receita_atual_mes = 0`)

Vale para prospect e também para quem é cliente do banco mas não tem produto
contratado. A pergunta é *"vale abrir?"*, e a régua é em reais — porque
percentual sobre zero não existe:

```
projetada ≥ prospect_piso_aprovado  ->  APROVADO
projetada ≥ prospect_piso_atencao   ->  ATENCAO
abaixo disso                        ->  REPROVADO
```

Sem essa segunda régua, **todo cliente novo cairia no mesmo veredito sem
sentido** — é o caso que uma calculadora de pricing precisa acertar, não o
que ela pode ignorar.

### Nada preenchido

Status `VAZIO`: a tela mostra "Aguardando a proposta" e o botão de salvar
fica desligado. Não é um veredito, é a ausência dele.

---

## 7. Os parâmetros, e onde mexer neles

Todos moram na tabela `parametro` e são editados na tela de administração
(`admin.html`) — nunca no código.

| Chave | Padrão | O que faz |
|---|---|---|
| `veredito_pct_aprovado` | 15 | crescimento a partir do qual aprova |
| `veredito_pct_atencao` | 5 | abaixo disso, reprova |
| `prospect_piso_aprovado` | 5000 | receita/mês mínima para aprovar cliente novo |
| `prospect_piso_atencao` | 1500 | abaixo disso, reprova cliente novo |
| `meses_projecao` | 12 | meses usados para anualizar |
| `permitir_negociar_fator` | 1 | gerente pode ajustar o fator |
| `alerta_divergencia_pct` | 10 | margem para sinalizar receita fora da tabela |

---

## 8. O servidor sempre refaz a conta

Ao salvar, `api/simulacao.php` **ignora os totais que a tela mandou**. Sobem
só o volume digitado e o fator negociado; o resto é recalculado do zero com os
fatores que estão no banco naquele momento.

Não é desconfiança de quem usa. É que uma simulação gravada é uma decisão
comercial com nome e data, e precisa poder ser reproduzida: se o número viesse
do navegador, uma aba aberta desde ontem gravaria hoje um resultado calculado
com a tarifa de ontem, sem ninguém perceber.

Por isso `simulacao_item` guarda o `fator_usado` de cada linha. Se a área
reajustar a tarifa amanhã, a simulação de ontem continua contando a mesma
história.
