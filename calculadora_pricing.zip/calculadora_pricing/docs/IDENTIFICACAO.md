# Como a calculadora sabe quem é você

## O problema, em uma frase

A página roda no Apache do XAMPP. Sem autenticação integrada do Windows —
que é coisa do IIS —, o servidor **não tem como saber quem está do outro
lado**. Se perguntasse "quem é o usuário?", a resposta seria sempre o dono da
máquina que hospeda o Apache, igual para todo mundo.

Então alguém de fora precisa contar. Este documento explica quem, e por quê.

---

## Por que o Power Automate gratuito não resolve

Vale ler antes de tentar, porque a conclusão não é óbvia e custa uma tarde
para descobrir sozinho.

### As ações "Enviar uma solicitação HTTP" são o contrário do que precisamos

Na lista gratuita aparecem várias ações com esse nome — em Usuários do
Office 365, Outlook, Teams, Grupos. Todas elas fazem **o fluxo chamar alguém
de fora**.

O que precisaríamos é do inverso: **alguém de fora chamar o fluxo**. Isso é o
*gatilho* "Quando uma solicitação HTTP é recebida", e esse gatilho é premium.

### E mesmo com premium não resolveria

Este é o ponto mais importante, e é o que economiza o dinheiro da licença.

Um fluxo acionado por HTTP roda sob a identidade de **quem criou o fluxo**.
Se ele chamasse "Obter meu perfil (V2)", devolveria o perfil do dono — o
mesmo nome para todo mundo que abrisse a página.

O fluxo não tem como saber quem o chamou, porque a única coisa capaz de
contar isso a ele é justamente a informação que estamos tentando descobrir.
É um círculo.

> **Sobre a licença:** quem precisa do premium é só o dono do fluxo, não quem
> chama a URL — uma chamada ao gatilho HTTP nem é "um usuário do Power
> Automate", é só uma URL com chave. Mas, pelo motivo acima, isso não muda
> nada aqui.

---

## Por que o Power Apps resolve

Um app canvas é o oposto: ele roda sob a identidade de **quem abre**.

`User().Email` devolve a pessoa de verdade, sem conector nenhum, sem licença
premium. É uma função nativa do Power Fx.

O app não precisa ter tela nenhuma de verdade. Ele é um trampolim: descobre
quem é a pessoa e abre a calculadora já com os dados na URL.

---

## Passo a passo do Power App

### 1. Criar

Power Apps → **Criar** → **Aplicativo em branco** → formato **Tablet**.
Nome sugerido: `Calculadora de Pricing PJ`.

### 2. Adicionar o conector de usuários (opcional, mas recomendado)

Só é preciso se você quiser a **funcional** (`employeeId`) além do e-mail.

Painel esquerdo → **Dados** → **Adicionar dados** → procure
**Office 365 Users** → adicione.

É um conector **padrão**, incluído no Microsoft 365. Não é premium.

### 3. Montar a tela

Coloque um rótulo com o nome da ferramenta e um botão grande.
No botão, propriedade **OnSelect**:

```powerfx
Set(
    varPerfil,
    Office365Users.MyProfileV2(
        {'$select': "displayName,mail,jobTitle,department,employeeId"}
    )
);

Launch(
    "http://SERVIDOR/calculadora_pricing/index.html"
    & "?email="     & EncodeUrl( Lower( User().Email ) )
    & "&nome="      & EncodeUrl( User().FullName )
    & "&funcional=" & EncodeUrl( Coalesce( varPerfil.employeeId, "" ) )
    & "&cargo="     & EncodeUrl( Coalesce( varPerfil.jobTitle,  "" ) )
)
```

Troque `SERVIDOR` pelo nome ou IP da máquina que hospeda o XAMPP.

### 4. Se `employeeId` vier vazio

Acontece: nem todo tenant preenche esse campo, e alguns não o expõem pelo
conector. **Não é problema.**

A carteira é encontrada pelo **e-mail**, que é o caminho principal. A
funcional é só um segundo caminho, para o caso de o extrato de
encarteiramento não trazer e-mail.

Se `employeeId` não vier, simplifique — o app funciona sem o conector nenhum:

```powerfx
Launch(
    "http://SERVIDOR/calculadora_pricing/index.html"
    & "?email=" & EncodeUrl( Lower( User().Email ) )
    & "&nome="  & EncodeUrl( User().FullName )
)
```

E garanta que a coluna `gerente_email` do encarteiramento esteja preenchida.

### 5. Deixar quase invisível

Se você quiser que a pessoa clique no atalho e caia direto na calculadora,
sem passar por tela nenhuma, ponha o mesmo código em **OnVisible** da tela.

Recomendo **manter o botão também**: quando o `Launch` automático é bloqueado
pelo navegador — e às vezes é, porque não partiu de um clique —, a pessoa
fica olhando para uma tela vazia sem saber o que fazer. Com o botão ali, ela
resolve sozinha.

### 6. Publicar e compartilhar

**Salvar** → **Publicar** → **Compartilhar** com o time.
Copie a **URL da Web** (em `...` → Detalhes) e cole em
`src/config.js`, no campo `POWERAPP_URL`. É para lá que a tela de bloqueio
manda quem abrir o endereço direto.

### 7. Virar a chave

Em `src/config.js`:

```js
MODO: 'powerapps',
```

---

## O que isso protege, e o que não protege

Vale dizer com todas as letras: a identidade que chega é **declarada, não
provada**. Quem conhecer o endereço pode trocar o e-mail na barra de
endereços e ver a carteira de outro gerente.

Três coisas seguram o risco:

1. **A carteira é filtrada no banco pelo e-mail.** O estrago máximo é ver a
   carteira de alguém de quem já se sabe o e-mail — não a base inteira.
2. **A tela de administração confere a lista `app_admin`.** Mudar fator exige
   estar lá, e toda alteração fica registrada com nome, e-mail e data.
3. **Toda simulação é gravada com o autor.** Nada acontece anonimamente.

Se um dia isso não bastar, existe o campo `ASSINATURA_SEGREDO` em
`config/segredos.php`. Ligado, a página passa a exigir uma assinatura HMAC
junto da identidade. O preço de ligar: **o Power Fx não tem função de hash**,
então quem monta a URL precisaria ser um fluxo do Power Automate — que sabe
assinar, mas exige o gatilho premium. Enquanto for Power Apps puro, deixe
vazio.

---

## Os outros modos

Em `src/config.js`, o campo `MODO`:

| Modo | Quando usar |
|---|---|
| `mock` | desenvolvimento na sua máquina. Lê `mock/perfil.json` — troque o e-mail de lá para testar a carteira de outra pessoa |
| `powerapps` | produção. É o recomendado |
| `flow` | a página pergunta a um fluxo quem é o usuário. **Não funciona com licença gratuita** — está implementado caso um dia haja premium |

A identidade que vem na URL tem prioridade em qualquer modo. É assim que o
Power App entrega, e é assim que você testa outra pessoa sem mudar o modo:

```
index.html?email=fulano@bradesco.com.br&nome=Fulano&funcional=1234567
```

---

## Se o Power Apps não for possível

Existe um caminho que não depende de nada externo, e ele pode ser suficiente
dependendo de onde a ferramenta ficar hospedada: **autenticação integrada no
Apache**, via módulo `mod_authnz_sspi`. É o equivalente ao que o IIS faz
nativamente.

Exige colocar uma DLL no Apache e mexer no `httpd.conf`, então depende de
permissão no servidor. Se conseguir, a identidade passa a ser **provada** e
não declarada — e aí o `ASSINATURA_SEGREDO` deixa de fazer falta.

Nesse caso, o PHP passa a receber `$_SERVER['REMOTE_USER']`, e a função
`identidade()` em `api/comum.php` é o único lugar a mudar.
