﻿// ===============================
// JAVASCRIPT FUNCIONAL COM RESUMO E COMPARATIVO DE EQUIPAMENTOS (ATUALIZADO)
// ===============================

const grupos = ["debito", "credito"];
const bandeiras = ["visa", "master", "elo", "amex"];
const detalhesTabela = {};
const totalTexto = {};
const CONFIGURACAO_RA = {
  percentualComRA: 0.003,
  percentualSemRA: 0.0015
};

// Inicializa objetos para cada grupo
grupos.forEach(grupo => {
  detalhesTabela[grupo] = [];
  totalTexto[grupo] = "";
});

// Máscara para campos numéricos
["agencia", "conta", "cnpj-empresa"].forEach(id => {
  const campo = document.getElementById(id);
  if (campo) {
    campo.addEventListener("input", () => {
      campo.value = campo.value.replace(/\D/g, "");
    });
  }
});

function criarSecao(grupo, titulo) {
  const isParcelamento = grupo.startsWith("parcelamento");

  const tooltipHtml = `
    <div class="tooltip-wrapper" style="margin-left: 10px;">
  <span class="tooltip-icon">i</span>
  <span class="tooltip-text">
    Com base no <strong>faturamento mensal</strong> informado e nas <strong>taxas da Cielo</strong> e do <strong>concorrente</strong>, 
    o sistema calcula a <strong>diferença mensal</strong> e <strong>anual</strong> de custos.
  </span>
</div>

  `;

  let tituloHtml;

  if (isParcelamento) {
    tituloHtml = `
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2 style="display: flex; align-items: center; gap: 10px;">
          <div>
            Parcelamento 
            <span contenteditable="true" class="editable-titulo" data-grupo="${grupo}">${titulo}</span>
            <small class="dica-edicao">← (clique para editar)</small>
          </div>
        </h2>
        <div style="display: flex; align-items: center; gap: 10px;">
          <button type="button" class="remove-btn" data-remover="${grupo}">🗑 Remover</button>
          ${tooltipHtml}
        </div>
      </div>
    `;
  } else {
    tituloHtml = `
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2>${titulo}</h2>
        ${tooltipHtml}
      </div>
    `;
  }

  const listaBandeiras = grupo === "debito" ? ["visa", "master", "elo"] : [...bandeiras];

  let tabela = `<section class="comparativo-bandeiras" style='margin-bottom:60px'>
      <form id="form-${grupo}">
        ${tituloHtml}
        <table class="tabela-comparativa">
          <thead>
            <tr>
              <th>Bandeira</th>
              <th>Faturamento Mês (R$)</th>
              <th>Taxa Cielo (%)</th>
              <th>Taxa Conc (%)</th>
              <th>Custo Cielo</th>
              <th>Custo Conc</th>
              <th>Diferença</th>
            </tr>
          </thead>
          <tbody>`;

  listaBandeiras.forEach(b => {
    const label = b.toUpperCase();
    const imagem = `<img src="img/${b}.png" alt="${label}" class="logo-bandeira">`;

    tabela += `<tr>
      <td>${imagem} ${label}</td>
      <td><input type="number" name="${grupo}-faturamento-${b}" placeholder="R$"></td>
      <td><input type="number" name="${grupo}-taxaCielo-${b}"></td>
      <td><input type="number" name="${grupo}-taxaConc-${b}"></td>
      <td><input type="text" name="${grupo}-custoCielo-${b}" disabled></td>
      <td><input type="text" name="${grupo}-custoConc-${b}" disabled></td>
      <td><input type="text" name="${grupo}-dif-reais-${b}" disabled></td>
    </tr>`;
  });

  tabela += `</tbody></table>
    <div class="form-actions">
      <button type="button" class="add-btn green" data-grupo="${grupo}" data-action="calcular">Calcular Diferença</button>
      <button type="button" class="add-btn red" data-grupo="${grupo}" data-action="limpar">Limpar Tudo</button>
    </div>
    <div id="resumo-${grupo}" class="resumo-visual" style="margin-top: 40px;"></div>
  </form></section>`;

  return tabela;
}


// Função utilitária para extrair número de string
function formatarParaNumero(texto) {
  return parseFloat((texto || "0").replace(/[^\d.\-]/g, "")) || 0;
}

// Calcula os valores da linha para cada bandeira
function calcularLinha(grupo, bandeira) {
  const faturamento = formatarParaNumero(document.querySelector(`[name='${grupo}-faturamento-${bandeira}']`).value);
  const taxaCielo = formatarParaNumero(document.querySelector(`[name='${grupo}-taxaCielo-${bandeira}']`).value);
  const taxaConc = formatarParaNumero(document.querySelector(`[name='${grupo}-taxaConc-${bandeira}']`).value);

  const custoCielo = faturamento * (taxaCielo / 100);
  const custoConc = faturamento * (taxaConc / 100);
  const diffReais = custoCielo - custoConc;

  // 👉 Atualiza os campos da tabela
  const campoCielo = document.querySelector(`[name='${grupo}-custoCielo-${bandeira}']`);
  const campoConc = document.querySelector(`[name='${grupo}-custoConc-${bandeira}']`);
  const campoDif = document.querySelector(`[name='${grupo}-dif-reais-${bandeira}']`);

  if (campoCielo) campoCielo.value = `R$ ${formatarMoeda(custoCielo)}`;
  if (campoConc) campoConc.value = `R$ ${formatarMoeda(custoConc)}`;
  if (campoDif) campoDif.value = `${diffReais >= 0 ? "+" : "-"}R$ ${formatarMoeda(Math.abs(diffReais))}`;

  return {
    bandeira,
    custoCielo,
    custoConc,
    diffReais,
    faturamento
  };
}



function calcularResumo(grupo) {
  const listaBandeiras = grupo === "debito" ? ["visa", "master", "elo"] : [...bandeiras];
  const resultados = listaBandeiras.map(b => calcularLinha(grupo, b));

  let totalCieloMensal = 0;
  let totalConcMensal = 0;

  resultados.forEach(r => {
    totalCieloMensal += r.custoCielo;
    totalConcMensal += r.custoConc;
  });

  const totalCieloAnual = totalCieloMensal * 12;
  const totalConcAnual = totalConcMensal * 12;

  const diferencaMensalTotal = totalConcMensal - totalCieloMensal;
  const diferencaAnualTotal = totalConcAnual - totalCieloAnual;
  const diferencaConcVsCielo = totalCieloMensal - totalConcMensal;

  const corTotalMensal = diferencaMensalTotal >= 0 ? "positivo" : "negativo";
  const corTotalAnual = diferencaAnualTotal >= 0 ? "positivo" : "negativo";

  let textoComparativo = "A taxa do concorrente esta igual a da Cielo.";
  if (diferencaConcVsCielo > 0) {
    textoComparativo = `A taxa do concorrente esta R$ ${formatarMoeda(Math.abs(diferencaConcVsCielo))} menor que a da Cielo.`;
  } else if (diferencaConcVsCielo < 0) {
    textoComparativo = `A taxa do concorrente esta R$ ${formatarMoeda(Math.abs(diferencaConcVsCielo))} maior que a da Cielo.`;
  }

  const html = `
    <div class="resumo-taxas-matriz">
      <div class="card-total">
        <h4>Resultado Total</h4>
        <p>Custo Cielo Mensal: <strong>R$ ${formatarMoeda(totalCieloMensal)}</strong></p>
        <p>Custo Concorrente Mensal: <strong>R$ ${formatarMoeda(totalConcMensal)}</strong></p>
        <p class="valor ${corTotalMensal}">Diferenca Mensal Total: ${diferencaMensalTotal >= 0 ? "+" : "-"}R$ ${formatarMoeda(Math.abs(diferencaMensalTotal))}</p>
        <p class="valor ${corTotalAnual}">Diferenca Anual Total: ${diferencaAnualTotal >= 0 ? "+" : "-"}R$ ${formatarMoeda(Math.abs(diferencaAnualTotal))}</p>
        <p style="margin-top: 10px;"><strong>${textoComparativo}</strong></p>
      </div>
    </div>`;

  document.getElementById(`resumo-${grupo}`).innerHTML = html;
}






function limparTabela(grupo) {
  const todasBandeiras = [...bandeiras];
  todasBandeiras.forEach(b => {
    ["faturamento", "taxaCielo", "taxaConc", "custoCielo", "custoConc", "dif-reais"].forEach(campo => {
  const el = document.querySelector(`[name='${grupo}-${campo}-${b}']`);
  if (el) el.value = "";
  });
  });
  document.getElementById(`resumo-${grupo}`).innerHTML = "";
}

function formatarNumero(valor) {
  return valor.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}



// ===============================
// EQUIPAMENTOS
// ===============================

function calcularEquipamentos() {
  const campos = ["zip", "flash", "lio", "tef"];

  let totalQtdCielo = 0;
  let totalQtdConc = 0;
  let totalCustoCieloMensal = 0;
  let totalCustoConcMensal = 0;

  campos.forEach(campo => {
    const qtdCielo = parseInt(document.querySelector(`[name='qtd-${campo}']`)?.value) || 0;
    const qtdConc = parseInt(document.querySelector(`[name='qtdc-${campo}']`)?.value) || 0;
    const custoCieloUnit = parseFloat(document.querySelector(`[name='cielo-${campo}']`)?.value) || 0;
    const custoConcUnit = parseFloat(document.querySelector(`[name='conc-${campo}']`)?.value) || 0;

    totalQtdCielo += qtdCielo;
    totalQtdConc += qtdConc;
    totalCustoCieloMensal += qtdCielo * custoCieloUnit;
    totalCustoConcMensal += qtdConc * custoConcUnit;
  });

  const totalCustoCieloAnual = totalCustoCieloMensal * 12;
  const totalCustoConcAnual = totalCustoConcMensal * 12;

  // Diferença para frase comparativa
  const diferenca = totalCustoCieloMensal - totalCustoConcMensal;
  const textoComparativo = diferenca === 0
    ? "A Cielo tem o mesmo custo mensal que o concorrente."
    : diferenca > 0
      ? `A Cielo tem um custo mensal R$ ${diferenca.toFixed(2)} maior que o concorrente.`
      : `A Cielo tem um custo mensal R$ ${Math.abs(diferenca).toFixed(2)} menor que o concorrente.`;

  const html = `
    <div style="display: flex; gap: 40px; flex-wrap: wrap;">
      <div style="flex: 1; min-width: 200px; background: #e6f4ff; padding: 20px; border-radius: 8px;">
        <h4 style="margin-bottom: 10px;">CIELO</h4>
        <p>Qtd Total: <strong>${totalQtdCielo}</strong></p>
        <p>Custo Mensal: <strong>R$ ${totalCustoCieloMensal.toFixed(2)}</strong></p>
        <p>Custo Anual: <strong>R$ ${totalCustoCieloAnual.toFixed(2)}</strong></p>
      </div>
      <div style="flex: 1; min-width: 200px; background: #fff3f3; padding: 20px; border-radius: 8px;">
        <h4 style="margin-bottom: 10px;">Concorrente</h4>
        <p>Qtd Total: <strong>${totalQtdConc}</strong></p>
        <p>Custo Mensal: <strong>R$ ${totalCustoConcMensal.toFixed(2)}</strong></p>
        <p>Custo Anual: <strong>R$ ${totalCustoConcAnual.toFixed(2)}</strong></p>
      </div>
    </div>
    <p style="margin-top: 20px; font-weight: bold; color: #003366;">${textoComparativo}</p>
  `;

  const resultado = document.getElementById("resultado-equipamentos");
  resultado.innerHTML = html;
  resultado.style.display = "block";
}



function limparEquipamentos() {
  const campos = document.querySelectorAll("#equipamentos-form input");
  campos.forEach(campo => {
    campo.value = "";
  });

  const resultado = document.getElementById("resultado-equipamentos");
  resultado.innerHTML = "";
  resultado.style.display = "none";
}



function aplicarEventosGlobais() {
  document.querySelectorAll('[data-action="calcular"]').forEach(btn => {
    btn.onclick = () => calcularResumo(btn.dataset.grupo);
  });
  document.querySelectorAll('[data-action="limpar"]').forEach(btn => {
    btn.onclick = () => limparTabela(btn.dataset.grupo);
  });
  document.querySelectorAll('[data-remover]').forEach(btn => {
    btn.onclick = () => removerParcelamento(btn.dataset.remover);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const secoesContainer = document.getElementById("secoes-comparativas");
  secoesContainer.innerHTML = criarSecao("debito", "Débito") + criarSecao("credito", "Crédito");

  const parcelamentoWrapper = document.getElementById("parcelamento-wrapper");
  if (parcelamentoWrapper) {
    parcelamentoWrapper.innerHTML = criarSecao("parcelamento-1", "6x");
    const botaoAdicionar = document.createElement("div");
    botaoAdicionar.className = "form-actions";
    botaoAdicionar.innerHTML = `<button class="add-btn" onclick="adicionarParcelamento()">+ Adicionar Parcelamento</button>`;
    parcelamentoWrapper.appendChild(botaoAdicionar);
  }

  aplicarEventosGlobais();

  // Inicializacoes das tabelas dinamicas
  inicializarServicos();
  inicializarPixDemaisServicos();
  atualizarTotaisPixMaquininha();
  configurarExclusividadePixMaquininha();
  limparServicosConsolidados();

  const fatMensal = document.getElementById("fat-mensal");
  const fatAnual = document.getElementById("fat-anual");
  if (fatMensal && fatAnual) {
    fatMensal.addEventListener("input", () => {
      const valor = formatarParaNumero(fatMensal.value);
      fatAnual.value = "R$ " + (valor * 12).toFixed(2);
    });
  }

  // Listener para mostrar mensagem de Tipo de Cliente
  const tipoConquista = document.getElementById("tipo-conquista");
  const tipoBlindagem = document.getElementById("tipo-blindagem");
  const mensagemDiv = document.getElementById("mensagem-tipo-cliente");

  if (tipoConquista || tipoBlindagem) {
    const handleTipoCliente = () => {
      const tipoSelecionado = document.querySelector('input[name="tipo-cliente"]:checked');
      if (!tipoSelecionado) {
        mensagemDiv.style.display = "none";
        return;
      }

      mensagemDiv.style.display = "block";
      if (tipoSelecionado.value === "Conquista") {
        mensagemDiv.innerHTML = "A operação está em <strong>CONQUISTA</strong>: os itens da seção <strong>\"O que o Cliente trará na negociação\"</strong> serão considerados integralmente no resultado.";
      } else if (tipoSelecionado.value === "Blindagem") {
        mensagemDiv.innerHTML = "A operação está em <strong>BLINDAGEM</strong>: o cálculo considera manutenção da base atual e não projeta novos ganhos de cartões (Alelo/Veloe/Tag).";
      }
    };

    if (tipoConquista) tipoConquista.addEventListener("change", handleTipoCliente);
    if (tipoBlindagem) tipoBlindagem.addEventListener("change", handleTipoCliente);
  }
});


function removerParcelamento(grupo) {
  const form = document.getElementById(`form-${grupo}`);
  if (form) {
    const section = form.closest("section");
    if (section && grupo.startsWith("parcelamento")) {
      section.remove();
    }
  }
}

let contadorParcelamentos = 1;
function adicionarParcelamento() {
  contadorParcelamentos++;
  const novoId = `parcelamento-${contadorParcelamentos}`;
  const wrapper = document.getElementById("parcelamento-wrapper");
  const novaSecao = document.createElement("div");
  novaSecao.innerHTML = criarSecao(novoId, `${contadorParcelamentos + 5}x`);
  wrapper.insertBefore(novaSecao, wrapper.lastElementChild);
  aplicarEventosGlobais();
}

window.toggleSecao = function (id) {
  const el = document.getElementById(id);
  const btn = document.getElementById("btn-toggle-parcelamento");
  const ativo = el.classList.contains("active");
  el.classList.toggle("active");
  btn.textContent = ativo ? "+ Parcelamento" : "– Parcelamento";
};




// ===============================
// JAVASCRIPT - PIX + SERVICOS
// ===============================

function formatarInteiro(valor) {
  return Math.round(valor || 0).toLocaleString("pt-BR");
}

function normalizarNumeroBr(texto) {
  return parseFloat((texto || "0").toString().replace(/[R$\s]/g, "").replace(/\./g, "").replace(",", ".")) || 0;
}

function obterNumeroPorId(id) {
  const el = document.getElementById(id);
  if (!el) return 0;
  return parseFloat(el.value || 0) || 0;
}

function parseValorMonetario(valor) {
  if (valor === null || valor === undefined) return 0;
  return parseFloat(valor.toString().replace(/[R$\s]/g, "").replace(/\./g, "").replace(",", ".")) || 0;
}

function calcularCustoPorTipo(tipo, volumeTotal, qtdTotal, valor, valorMaximo) {
  if (tipo === "taxa") {
    const custoBase = volumeTotal * (valor / 100);
    if (qtdTotal > 0 && valorMaximo > 0) {
      const custoUnitario = custoBase / qtdTotal;
      if (custoUnitario > valorMaximo) {
        return qtdTotal * valorMaximo;
      }
    }
    return custoBase;
  }

  return qtdTotal * valor;
}

function escolherTipoPix(taxa, tarifa) {
  if (tarifa > 0) return "tarifa";
  if (taxa > 0) return "taxa";
  return "taxa";
}

function configurarExclusividadePixMaquininha() {
  const pares = [
    {
      taxa: "pixmaq-taxa-atual",
      max: "pixmaq-max-atual",
      tarifa: "pixmaq-tarifa-atual"
    },
    {
      taxa: "pixmaq-taxa-proposta",
      max: "pixmaq-max-proposta",
      tarifa: "pixmaq-tarifa-proposta"
    }
  ];

  pares.forEach(par => {
    const campoTaxa = document.getElementById(par.taxa);
    const campoMax = document.getElementById(par.max);
    const campoTarifa = document.getElementById(par.tarifa);
    if (!campoTaxa || !campoTarifa) return;

    campoTarifa.addEventListener("input", () => {
      const valorTarifa = parseFloat(campoTarifa.value || 0) || 0;
      if (valorTarifa > 0) {
        campoTaxa.value = "";
        if (campoMax) campoMax.value = "";
      }
    });

    campoTaxa.addEventListener("input", () => {
      const valorTaxa = parseFloat(campoTaxa.value || 0) || 0;
      if (valorTaxa > 0) {
        campoTarifa.value = "";
      }
    });
  });
}

function atualizarTotaisPixMaquininha() {
  const volumeBradesco = obterNumeroPorId("pixmaq-vol-bradesco");
  const volumeNovo = obterNumeroPorId("pixmaq-vol-novo");
  const qtdBradesco = obterNumeroPorId("pixmaq-qtd-bradesco");
  const qtdNovo = obterNumeroPorId("pixmaq-qtd-novo");

  const volumeTotal = volumeBradesco + volumeNovo;
  const qtdTotal = qtdBradesco + qtdNovo;

  const volumeTotalEl = document.getElementById("pixmaq-vol-total");
  const qtdTotalEl = document.getElementById("pixmaq-qtd-total");

  if (volumeTotalEl) volumeTotalEl.value = formatarMoedaComSimbolo(volumeTotal);
  if (qtdTotalEl) qtdTotalEl.value = formatarInteiro(qtdTotal);
}

function calcularPixMaquininha() {
  atualizarTotaisPixMaquininha();

  const volumeTotal = normalizarNumeroBr(document.getElementById("pixmaq-vol-total")?.value);
  const qtdTotal = normalizarNumeroBr(document.getElementById("pixmaq-qtd-total")?.value);

  const taxaAtual = obterNumeroPorId("pixmaq-taxa-atual");
  const maxAtual = obterNumeroPorId("pixmaq-max-atual");
  const taxaProposta = obterNumeroPorId("pixmaq-taxa-proposta");
  const maxProposta = obterNumeroPorId("pixmaq-max-proposta");

  const tarifaAtual = obterNumeroPorId("pixmaq-tarifa-atual");
  const tarifaProposta = obterNumeroPorId("pixmaq-tarifa-proposta");

  const tipoAtual = escolherTipoPix(taxaAtual, tarifaAtual);
  const tipoProposta = escolherTipoPix(taxaProposta, tarifaProposta);

  const valorAtual = tipoAtual === "taxa" ? taxaAtual : tarifaAtual;
  const valorProposta = tipoProposta === "taxa" ? taxaProposta : tarifaProposta;

  const custoAtual = calcularCustoPorTipo(tipoAtual, volumeTotal, qtdTotal, valorAtual, maxAtual);
  const custoProposto = calcularCustoPorTipo(tipoProposta, volumeTotal, qtdTotal, valorProposta, maxProposta);

  const reducaoMes = custoAtual - custoProposto;
  const reducaoAno = reducaoMes * 12;

  const custoAtualEl = document.getElementById("pixmaq-custo-atual");
  const custoPropostoEl = document.getElementById("pixmaq-custo-proposto");
  const reducaoMesEl = document.getElementById("pixmaq-reducao-mes");
  const reducaoAnoEl = document.getElementById("pixmaq-reducao-ano");

  if (custoAtualEl) custoAtualEl.value = formatarMoedaComSimbolo(custoAtual);
  if (custoPropostoEl) custoPropostoEl.value = formatarMoedaComSimbolo(custoProposto);
  if (reducaoMesEl) reducaoMesEl.value = formatarMoedaComSimbolo(reducaoMes);
  if (reducaoAnoEl) reducaoAnoEl.value = formatarMoedaComSimbolo(reducaoAno);
}

function limparPixMaquininha() {
  const form = document.getElementById("pix-maquininha-form");
  if (!form) return;

  form.querySelectorAll("input").forEach(input => {
    input.value = "";
  });
}

function atualizarTotaisLinhaDemaisPix(indice) {
  const volumeBradesco = obterNumeroPorId(`pixdem-${indice}-vol-bradesco`);
  const volumeNovo = obterNumeroPorId(`pixdem-${indice}-vol-novo`);
  const qtdBradesco = obterNumeroPorId(`pixdem-${indice}-qtd-bradesco`);
  const qtdNovo = obterNumeroPorId(`pixdem-${indice}-qtd-novo`);

  const volumeTotalEl = document.getElementById(`pixdem-${indice}-vol-total`);
  const qtdTotalEl = document.getElementById(`pixdem-${indice}-qtd-total`);

  if (volumeTotalEl) volumeTotalEl.value = formatarMoedaComSimbolo(volumeBradesco + volumeNovo);
  if (qtdTotalEl) qtdTotalEl.value = formatarInteiro(qtdBradesco + qtdNovo);
}

function inicializarPixDemaisServicos() {
  [0, 1].forEach(indice => {
    [
      `pixdem-${indice}-vol-bradesco`,
      `pixdem-${indice}-vol-novo`,
      `pixdem-${indice}-qtd-bradesco`,
      `pixdem-${indice}-qtd-novo`
    ].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", () => atualizarTotaisLinhaDemaisPix(indice));
      }
    });
  });
}

function calcularLinhaDemaisPix(indice) {
  atualizarTotaisLinhaDemaisPix(indice);

  const tipo = document.getElementById(`pixdem-${indice}-tipo`)?.value || "taxa";
  const volumeTotal = normalizarNumeroBr(document.getElementById(`pixdem-${indice}-vol-total`)?.value);
  const qtdTotal = normalizarNumeroBr(document.getElementById(`pixdem-${indice}-qtd-total`)?.value);

  const atual = obterNumeroPorId(`pixdem-${indice}-atual`);
  const atualMax = obterNumeroPorId(`pixdem-${indice}-atual-max`);
  const proposto = obterNumeroPorId(`pixdem-${indice}-proposto`);
  const propostoMax = obterNumeroPorId(`pixdem-${indice}-proposto-max`);

  const custoAtual = calcularCustoPorTipo(tipo, volumeTotal, qtdTotal, atual, atualMax);
  const custoProposto = calcularCustoPorTipo(tipo, volumeTotal, qtdTotal, proposto, propostoMax);

  const reducaoMes = custoAtual - custoProposto;
  const reducaoAno = reducaoMes * 12;

  const mesEl = document.getElementById(`pixdem-${indice}-mes`);
  const anoEl = document.getElementById(`pixdem-${indice}-ano`);
  if (mesEl) mesEl.textContent = formatarMoedaComSimbolo(reducaoMes);
  if (anoEl) anoEl.textContent = formatarMoedaComSimbolo(reducaoAno);

  return { custoAtual, custoProposto, reducaoMes, reducaoAno };
}

function calcularDemaisServicosPix() {
  let totalAtual = 0;
  let totalProposto = 0;
  let totalMes = 0;
  let totalAno = 0;

  [0, 1].forEach(indice => {
    const resultado = calcularLinhaDemaisPix(indice);
    totalAtual += resultado.custoAtual;
    totalProposto += resultado.custoProposto;
    totalMes += resultado.reducaoMes;
    totalAno += resultado.reducaoAno;
  });

  const totalMesEl = document.getElementById("pixdem-total-mes");
  const totalAnoEl = document.getElementById("pixdem-total-ano");
  const totalAtualEl = document.getElementById("pixdem-total-atual");
  const totalPropostoEl = document.getElementById("pixdem-total-proposto");
  const resultadoEl = document.getElementById("resultado-demais-pix");

  if (totalMesEl) totalMesEl.textContent = formatarMoedaComSimbolo(totalMes);
  if (totalAnoEl) totalAnoEl.textContent = formatarMoedaComSimbolo(totalAno);
  if (totalAtualEl) totalAtualEl.textContent = formatarMoedaComSimbolo(totalAtual);
  if (totalPropostoEl) totalPropostoEl.textContent = formatarMoedaComSimbolo(totalProposto);
  if (resultadoEl) resultadoEl.style.display = "block";
}

function limparDemaisServicosPix() {
  const form = document.getElementById("demais-servicos-pix-form");
  if (!form) return;

  form.querySelectorAll("input[type='number'], input[type='text']").forEach(input => {
    input.value = "";
  });

  form.querySelectorAll("span[id^='pixdem-']").forEach(span => {
    span.textContent = "";
  });

  form.querySelectorAll("select[id^='pixdem-']").forEach(select => {
    select.selectedIndex = 0;
  });

  const resultadoEl = document.getElementById("resultado-demais-pix");
  if (resultadoEl) resultadoEl.style.display = "none";
}

const servicosLista = [
  "Cesta de Servicos",
  "Cartao de Credito: Anuidade",
  "Boletos: Tarifa de Registro",
  "Folha de Pagamento: Transmissao",
  "TED"
];

function inicializarServicos() {
  const corpo = document.getElementById("corpo-servicos");
  if (!corpo) return;

  corpo.innerHTML = "";

  servicosLista.forEach((nome, i) => {
    const linha = document.createElement("tr");
    linha.innerHTML = `
      <td>${nome}</td>
      <td><input type="number" class="input-servico" id="qtd-bradesco-${i}"></td>
      <td><input type="number" class="input-servico" id="qtd-novo-${i}"></td>
      <td><input type="text" class="input-servico" id="qtd-total-${i}" disabled></td>
      <td><input type="text" class="input-servico" id="vol-bradesco-${i}" disabled></td>
      <td><input type="text" class="input-servico" id="vol-novo-${i}" disabled></td>
      <td><input type="text" class="input-servico" id="vol-total-${i}" disabled></td>
      <td><input type="number" class="input-servico" id="atual-${i}"></td>
      <td><input type="number" class="input-servico" id="proposto-${i}"></td>
      <td class="bg-calculado"><span id="mes-${i}"></span></td>
      <td class="bg-calculado"><span id="ano-${i}"></span></td>
      <td class="bg-calculado"><span id="perc-${i}"></span></td>
    `;
    corpo.appendChild(linha);
  });
}

function calcularServicos() {
  let totalQtdBradesco = 0;
  let totalQtdNovo = 0;
  let totalQtd = 0;
  let totalVolumeBradesco = 0;
  let totalVolumeNovo = 0;
  let totalVolumeTotal = 0;

  let totalAtualCalculado = 0;
  let totalPropostoCalculado = 0;
  let totalMes = 0;
  let totalAno = 0;
  let somaPercentuais = 0;
  let linhasValidas = 0;

  servicosLista.forEach((_, i) => {
    let qtdBradesco = obterNumeroPorId(`qtd-bradesco-${i}`);
    let qtdNovo = obterNumeroPorId(`qtd-novo-${i}`);
    const atual = obterNumeroPorId(`atual-${i}`);
    const proposto = obterNumeroPorId(`proposto-${i}`);

    if ((qtdBradesco + qtdNovo) === 0 && (atual > 0 || proposto > 0)) {
      qtdBradesco = 1;
    }

    const qtdTotal = qtdBradesco + qtdNovo;

    const volumeBradesco = qtdBradesco * atual;
    const volumeNovo = qtdNovo * proposto;
    const volumeTotal = volumeBradesco + volumeNovo;

    const custoAtualLinha = qtdTotal * atual;
    const custoPropostoLinha = qtdTotal * proposto;

    const mes = custoAtualLinha - custoPropostoLinha;
    const ano = mes * 12;
    const perc = custoAtualLinha !== 0 ? (mes / custoAtualLinha) * 100 : 0;

    const qtdTotalEl = document.getElementById(`qtd-total-${i}`);
    const volBradescoEl = document.getElementById(`vol-bradesco-${i}`);
    const volNovoEl = document.getElementById(`vol-novo-${i}`);
    const volTotalEl = document.getElementById(`vol-total-${i}`);

    if (qtdTotalEl) qtdTotalEl.value = formatarInteiro(qtdTotal);
    if (volBradescoEl) volBradescoEl.value = formatarMoedaComSimbolo(volumeBradesco);
    if (volNovoEl) volNovoEl.value = formatarMoedaComSimbolo(volumeNovo);
    if (volTotalEl) volTotalEl.value = formatarMoedaComSimbolo(volumeTotal);

    document.getElementById(`mes-${i}`).textContent = formatarMoedaComSimbolo(mes);
    document.getElementById(`ano-${i}`).textContent = formatarMoedaComSimbolo(ano);
    document.getElementById(`perc-${i}`).textContent = `${perc.toFixed(1)}%`;

    totalQtdBradesco += qtdBradesco;
    totalQtdNovo += qtdNovo;
    totalQtd += qtdTotal;

    totalVolumeBradesco += volumeBradesco;
    totalVolumeNovo += volumeNovo;
    totalVolumeTotal += volumeTotal;

    totalAtualCalculado += custoAtualLinha;
    totalPropostoCalculado += custoPropostoLinha;

    if (custoAtualLinha !== 0) {
      somaPercentuais += perc;
      linhasValidas++;
    }
  });

  totalMes = totalAtualCalculado - totalPropostoCalculado;
  totalAno = totalMes * 12;

  const mediaPercentual = linhasValidas > 0 ? somaPercentuais / linhasValidas : 0;

  document.getElementById("total-qtd-bradesco").textContent = formatarInteiro(totalQtdBradesco);
  document.getElementById("total-qtd-novo").textContent = formatarInteiro(totalQtdNovo);
  document.getElementById("total-qtd").textContent = formatarInteiro(totalQtd);
  document.getElementById("total-vol-bradesco").textContent = formatarMoedaComSimbolo(totalVolumeBradesco);
  document.getElementById("total-vol-novo").textContent = formatarMoedaComSimbolo(totalVolumeNovo);
  document.getElementById("total-vol-total").textContent = formatarMoedaComSimbolo(totalVolumeTotal);

  document.getElementById("total-atual").textContent = formatarMoedaComSimbolo(totalAtualCalculado);
  document.getElementById("total-proposto").textContent = formatarMoedaComSimbolo(totalPropostoCalculado);
  document.getElementById("total-mes").textContent = formatarMoedaComSimbolo(totalMes);
  document.getElementById("total-ano").textContent = formatarMoedaComSimbolo(totalAno);
  document.getElementById("total-percentual").textContent = `${mediaPercentual.toFixed(1)}%`;

  document.getElementById("resumo-serv-mes").textContent = formatarMoeda(totalMes);
  document.getElementById("resumo-serv-ano").textContent = formatarMoeda(totalAno);
  document.getElementById("resumo-serv-perc").textContent = `${mediaPercentual.toFixed(1)}%`;
  document.getElementById("resumo-serv-perc-ano").textContent = `${mediaPercentual.toFixed(1)}%`;

  document.getElementById("resultado-servicos").style.display = "block";
}

function limparServicos() {
  servicosLista.forEach((_, i) => {
    [
      `qtd-bradesco-${i}`,
      `qtd-novo-${i}`,
      `qtd-total-${i}`,
      `vol-bradesco-${i}`,
      `vol-novo-${i}`,
      `vol-total-${i}`,
      `atual-${i}`,
      `proposto-${i}`
    ].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });

    ["mes", "ano", "perc"].forEach(prefixo => {
      const el = document.getElementById(`${prefixo}-${i}`);
      if (el) el.textContent = "";
    });
  });

  [
    "total-qtd-bradesco",
    "total-qtd-novo",
    "total-qtd",
    "total-vol-bradesco",
    "total-vol-novo",
    "total-vol-total",
    "total-atual",
    "total-proposto",
    "total-mes",
    "total-ano",
    "total-percentual"
  ].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = "";
  });

  const boxResumo = document.getElementById("resultado-servicos");
  if (boxResumo) {
    boxResumo.style.display = "none";
  }
}


// ===============================
// JAVASCRIPT - CÁLCULO INVEST FÁCIL (VERSÃO SEGURA)
// ===============================

// Formata valores com separador de milhar e duas casas decimais
// Função para formatar valores como moeda brasileira
function formatarMoeda(valor) {
  return parseFloat(valor || 0).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function formatarMoedaComSimbolo(valor) {
  return `R$${formatarMoeda(valor)}`;
}

// Atribui valor formatado ao campo se existir
function setValueIfExists(id, valor) {
  const el = document.getElementById(id);
  if (el) el.value = formatarMoedaComSimbolo(valor);
}

// Atualiza automaticamente os valores anuais e totais, incluindo o saldo
function calcularInvestFacilParcial() {
  const get = id => parseFloat(document.getElementById(id)?.value || 0);

  const fatCartao = get("invest-fat");
  const boletos = get("invest-boletos");
  const pix = get("invest-pix");
  const pixMaquininha = get("invest-pixmaq");
  const diversos = get("invest-diversos");
  const folha = get("invest-folha");
  const alelo = get("invest-alelo");
  const veloeGo = get("invest-veloe-go");
  const tagVeloe = get("invest-tag-veloe");

  const entrada = fatCartao + boletos + pix + pixMaquininha;
  const saida = diversos + folha + alelo + veloeGo + tagVeloe;
  const saldoMes = entrada - saida;
  const saldoAno = saldoMes * 12;

  setValueIfExists("invest-fat-ano", fatCartao * 12);
  setValueIfExists("invest-boletos-ano", boletos * 12);
  setValueIfExists("invest-pix-ano", pix * 12);
  setValueIfExists("invest-pixmaq-ano", pixMaquininha * 12);
  setValueIfExists("invest-diversos-ano", diversos * 12);
  setValueIfExists("invest-folha-ano", folha * 12);
  setValueIfExists("invest-alelo-ano", alelo * 12);
  setValueIfExists("invest-veloe-go-ano", veloeGo * 12);
  setValueIfExists("invest-tag-veloe-ano", tagVeloe * 12);
  setValueIfExists("invest-saldo-mes", saldoMes);
  setValueIfExists("invest-saldo-ano", saldoAno);
}

// Exibe os quadrantes de saldo e resultado projetado
function calcularInvestFacil() {
  const saldoEl = document.getElementById("invest-saldo-mes");
  const saldo = saldoEl ? normalizarNumeroBr(saldoEl.value) : 0;

  const repasseMes = saldo * 0.0136;
  const repasseAno = repasseMes * 12;
  const incrementoMes = repasseMes * 0.05;
  const incrementoAno = incrementoMes * 12;

  const setTextIfExists = (id, valor) => {
    const el = document.getElementById(id);
    if (el) el.textContent = formatarMoeda(valor);
  };

  setTextIfExists("repasse-mes", repasseMes);
  setTextIfExists("repasse-ano", repasseAno);
  setTextIfExists("incremento-mes", incrementoMes);
  setTextIfExists("incremento-ano", incrementoAno);

  const resultadoDiv = document.getElementById("resultado-invest");
  if (resultadoDiv) {
    resultadoDiv.style.display = "flex";
  }
}

// Limpa todos os campos do Invest Fácil e esconde o resumo
function limparInvestFacil() {
  const inputs = document.querySelectorAll("#invest-facil-form input[type='number'], #invest-facil-form input[type='text']");
  inputs.forEach(input => input.value = "");

  const limparSpan = id => {
    const el = document.getElementById(id);
    if (el) el.textContent = "0,00";
  };

  limparSpan("repasse-mes");
  limparSpan("repasse-ano");
  limparSpan("incremento-mes");
  limparSpan("incremento-ano");

  const resultadoDiv = document.getElementById("resultado-invest");
  if (resultadoDiv) resultadoDiv.style.display = "none";
}




// ===============================
// NEGOCIACAO + CONSOLIDADO + RESUMO
// ===============================

function obterTipoClienteSelecionado() {
  return document.querySelector('input[name="tipo-cliente"]:checked')?.value?.toLowerCase() || "";
}

function obterNumeroCampo(id) {
  const el = document.getElementById(id);
  if (!el) return 0;
  return parseFloat(el.value || 0) || 0;
}

function obterNumeroSpan(id) {
  return parseValorMonetario(document.getElementById(id)?.textContent || "0");
}

function obterPercentualRecebiveisAntecipados() {
  const opcaoSelecionada = document.querySelector('input[name="possui-ra"]:checked')?.value;
  if (opcaoSelecionada === "sim") return CONFIGURACAO_RA.percentualComRA;
  if (opcaoSelecionada === "nao") return CONFIGURACAO_RA.percentualSemRA;
  return 0;
}

function calcularLinhaNegociacao(indice) {
  const linha = document.getElementById(`neg-${indice}-qtd`)?.closest("tr");
  if (!linha) return { repasseMes: 0, repasseAno: 0 };

  const tipo = linha.dataset.negocioTipo || "";
  const qtd = obterNumeroCampo(`neg-${indice}-qtd`);
  const volume = obterNumeroCampo(`neg-${indice}-volume`);
  const tarifa = obterNumeroCampo(`neg-${indice}-tarifa`);
  const taxa = obterNumeroCampo(`neg-${indice}-taxa`);
  const valorMaximo = obterNumeroCampo(`neg-${indice}-max`);
  const tipoCliente = obterTipoClienteSelecionado();

  let repasseMes = 0;

  switch (tipo) {
    case "faturamento_cartao": {
      if (tipoCliente !== "blindagem") {
        const percentualRA = obterPercentualRecebiveisAntecipados();
        repasseMes = volume * percentualRA;
      }
      break;
    }

    case "boletos": {
      if (tarifa > 0) {
        repasseMes = (tarifa - 0.55) * qtd;
      } else if (taxa > 0) {
        repasseMes = calcularCustoPorTipo("taxa", volume, qtd, taxa, valorMaximo) - (0.55 * qtd);
      }
      break;
    }

    case "pix_recebimento": {
      if (tarifa > 0) {
        repasseMes = (tarifa - 0.20) * qtd;
      } else if (taxa > 0) {
        repasseMes = calcularCustoPorTipo("taxa", volume, qtd, taxa, valorMaximo) - (0.20 * qtd);
      }
      break;
    }

    case "pix_pagamento": {
      if (tarifa > 0) {
        repasseMes = (tarifa - 0.04) * qtd;
      } else if (taxa > 0) {
        repasseMes = calcularCustoPorTipo("taxa", volume, qtd, taxa, valorMaximo) - (0.04 * qtd);
      }
      break;
    }

    case "folha": {
      repasseMes = volume * qtd * 0.20;
      break;
    }

    case "alelo_veloe": {
      if (tipoCliente !== "blindagem") {
        const taxaPercentual = taxa > 0 ? taxa / 100 : 0.03;
        const bonusCartao = tarifa > 0 ? tarifa : 10;
        repasseMes = (volume * taxaPercentual) + (qtd * bonusCartao);
      }
      break;
    }

    case "tag_veloe": {
      if (tipoCliente !== "blindagem") {
        const tarifaTag = tarifa > 0 ? tarifa : 10;
        repasseMes = qtd * tarifaTag;
      }
      break;
    }

    default:
      repasseMes = 0;
  }

  const repasseAno = repasseMes * 12;

  const mesEl = document.getElementById(`neg-${indice}-mes`);
  const anoEl = document.getElementById(`neg-${indice}-ano`);
  if (mesEl) mesEl.textContent = formatarMoedaComSimbolo(repasseMes);
  if (anoEl) anoEl.textContent = formatarMoedaComSimbolo(repasseAno);

  return { repasseMes, repasseAno };
}

function calcularNegociacao() {
  let totalMes = 0;
  let totalAno = 0;

  [0, 1, 2, 3, 4, 5, 6].forEach(indice => {
    const linha = calcularLinhaNegociacao(indice);
    totalMes += linha.repasseMes;
    totalAno += linha.repasseAno;
  });

  const totalMesEl = document.getElementById("neg-total-mes");
  const totalAnoEl = document.getElementById("neg-total-ano");

  if (totalMesEl) totalMesEl.textContent = formatarMoedaComSimbolo(totalMes);
  if (totalAnoEl) totalAnoEl.textContent = formatarMoedaComSimbolo(totalAno);

  return { totalMes, totalAno };
}

function limparNegociacao() {
  const form = document.getElementById("form-negociacao");
  if (!form) return;

  form.querySelectorAll("input[type='number'], input[type='text']").forEach(input => {
    input.value = "";
  });

  form.querySelectorAll("span[id^='neg-']").forEach(span => {
    span.textContent = "";
  });
}

function calcularPercentualReducao(reducao, baseAtual) {
  if (!baseAtual) return 0;
  return (reducao / baseAtual) * 100;
}

function preencherLinhaConsolidado(prefixo, valorMes, valorAno, reducaoMes, reducaoAno, percentual) {
  const set = (id, valor) => {
    const el = document.getElementById(id);
    if (el) el.textContent = valor;
  };

  set(`${prefixo}-valor-mes`, formatarMoedaComSimbolo(valorMes));
  set(`${prefixo}-valor-ano`, formatarMoedaComSimbolo(valorAno));
  set(`${prefixo}-red-mes`, formatarMoedaComSimbolo(reducaoMes));
  set(`${prefixo}-red-ano`, formatarMoedaComSimbolo(reducaoAno));
  set(`${prefixo}-red-perc`, `${percentual.toFixed(1)}%`);
}

function calcularServicosConsolidados() {
  const servAtual = obterNumeroSpan("total-atual");
  const servProposto = obterNumeroSpan("total-proposto");
  const servRedMes = obterNumeroSpan("total-mes");
  const servRedAno = obterNumeroSpan("total-ano");

  const pixmaqAtual = parseValorMonetario(document.getElementById("pixmaq-custo-atual")?.value || "0");
  const pixmaqProposto = parseValorMonetario(document.getElementById("pixmaq-custo-proposto")?.value || "0");
  const pixmaqRedMes = parseValorMonetario(document.getElementById("pixmaq-reducao-mes")?.value || "0");
  const pixmaqRedAno = parseValorMonetario(document.getElementById("pixmaq-reducao-ano")?.value || "0");

  const pixdemAtual = obterNumeroSpan("pixdem-total-atual");
  const pixdemProposto = obterNumeroSpan("pixdem-total-proposto");
  const pixdemRedMes = obterNumeroSpan("pixdem-total-mes");
  const pixdemRedAno = obterNumeroSpan("pixdem-total-ano");

  preencherLinhaConsolidado(
    "cons-diversos",
    servProposto,
    servProposto * 12,
    servRedMes,
    servRedAno,
    calcularPercentualReducao(servRedMes, servAtual)
  );

  preencherLinhaConsolidado(
    "cons-pixmaq",
    pixmaqProposto,
    pixmaqProposto * 12,
    pixmaqRedMes,
    pixmaqRedAno,
    calcularPercentualReducao(pixmaqRedMes, pixmaqAtual)
  );

  preencherLinhaConsolidado(
    "cons-pixdem",
    pixdemProposto,
    pixdemProposto * 12,
    pixdemRedMes,
    pixdemRedAno,
    calcularPercentualReducao(pixdemRedMes, pixdemAtual)
  );

  const totalAtual = servAtual + pixmaqAtual + pixdemAtual;
  const totalValorMes = servProposto + pixmaqProposto + pixdemProposto;
  const totalValorAno = totalValorMes * 12;
  const totalReducaoMes = servRedMes + pixmaqRedMes + pixdemRedMes;
  const totalReducaoAno = servRedAno + pixmaqRedAno + pixdemRedAno;
  const totalPercentual = calcularPercentualReducao(totalReducaoMes, totalAtual);

  const set = (id, valor) => {
    const el = document.getElementById(id);
    if (el) el.textContent = valor;
  };

  set("cons-total-valor-mes", formatarMoedaComSimbolo(totalValorMes));
  set("cons-total-valor-ano", formatarMoedaComSimbolo(totalValorAno));
  set("cons-total-red-mes", formatarMoedaComSimbolo(totalReducaoMes));
  set("cons-total-red-ano", formatarMoedaComSimbolo(totalReducaoAno));
  set("cons-total-red-perc", `${totalPercentual.toFixed(1)}%`);

  return {
    totalAtual,
    totalValorMes,
    totalValorAno,
    totalReducaoMes,
    totalReducaoAno,
    totalPercentual
  };
}

function limparServicosConsolidados() {
  const idsValor = [
    "cons-diversos-valor-mes",
    "cons-diversos-valor-ano",
    "cons-diversos-red-mes",
    "cons-diversos-red-ano",
    "cons-pixmaq-valor-mes",
    "cons-pixmaq-valor-ano",
    "cons-pixmaq-red-mes",
    "cons-pixmaq-red-ano",
    "cons-pixdem-valor-mes",
    "cons-pixdem-valor-ano",
    "cons-pixdem-red-mes",
    "cons-pixdem-red-ano",
    "cons-total-valor-mes",
    "cons-total-valor-ano",
    "cons-total-red-mes",
    "cons-total-red-ano"
  ];

  const idsPerc = [
    "cons-diversos-red-perc",
    "cons-pixmaq-red-perc",
    "cons-pixdem-red-perc",
    "cons-total-red-perc"
  ];

  idsValor.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = "R$ 0,00";
  });

  idsPerc.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = "0,0%";
  });
}

// ===============================
// RESUMO FINAL
// ===============================

function formatarMoedaResumo(valor) {
  return (valor || 0).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function classificarResultado(valor) {
  if (valor > 0) return "positivo";
  if (valor < 0) return "negativo";
  return "neutro";
}

function rotuloResultado(status) {
  if (status === "positivo") return "Positivo";
  if (status === "negativo") return "Negativo";
  return "Neutro";
}

function calcularResumoFinal() {
  calcularResumo("debito");
  calcularResumo("credito");
  calcularEquipamentos();
  calcularServicos();
  calcularPixMaquininha();
  calcularDemaisServicosPix();
  const consolidado = calcularServicosConsolidados();
  const negociacao = calcularNegociacao();
  calcularInvestFacilParcial();
  calcularInvestFacil();

  const gruposValidos = ["debito", "credito"];
  for (let i = 1; i <= contadorParcelamentos; i++) {
    gruposValidos.push(`parcelamento-${i}`);
  }

  let totalMensalTaxas = 0;
  let totalAnualTaxas = 0;
  let totalCustoCieloMensal = 0;
  let totalCustoConcMensal = 0;

  gruposValidos.forEach(grupo => {
    const listaBandeiras = grupo === "debito" ? ["visa", "master", "elo"] : [...bandeiras];
    listaBandeiras.forEach(b => {
      const faturamento = parseFloat(document.querySelector(`[name='${grupo}-faturamento-${b}']`)?.value || 0);
      const taxaCielo = parseFloat(document.querySelector(`[name='${grupo}-taxaCielo-${b}']`)?.value || 0);
      const taxaConc = parseFloat(document.querySelector(`[name='${grupo}-taxaConc-${b}']`)?.value || 0);

      totalCustoCieloMensal += (faturamento * taxaCielo) / 100;
      totalCustoConcMensal += (faturamento * taxaConc) / 100;
      totalMensalTaxas += (faturamento * (taxaConc - taxaCielo)) / 100;
      totalAnualTaxas += ((faturamento * (taxaConc - taxaCielo)) / 100) * 12;
    });
  });

  const camposEquip = ["zip", "flash", "lio", "tef"];
  let qtdCielo = 0;
  let qtdConc = 0;
  let custoCielo = 0;
  let custoConc = 0;

  camposEquip.forEach(c => {
    const qtdCieloItem = parseInt(document.querySelector(`[name='qtd-${c}']`)?.value || 0);
    const qtdConcItem = parseInt(document.querySelector(`[name='qtdc-${c}']`)?.value || 0);
    const custoCieloItem = parseFloat(document.querySelector(`[name='cielo-${c}']`)?.value || 0);
    const custoConcItem = parseFloat(document.querySelector(`[name='conc-${c}']`)?.value || 0);

    qtdCielo += qtdCieloItem;
    qtdConc += qtdConcItem;
    custoCielo += qtdCieloItem * custoCieloItem;
    custoConc += qtdConcItem * custoConcItem;
  });

  const difEquipMensal = custoConc - custoCielo;
  const difEquipAnual = difEquipMensal * 12;

  const repasseMesInvest = obterNumeroSpan("repasse-mes");
  const repasseAnoInvest = obterNumeroSpan("repasse-ano");
  const incrementoMesInvest = obterNumeroSpan("incremento-mes");
  const incrementoAnoInvest = obterNumeroSpan("incremento-ano");

  const resultadoClienteMes = totalMensalTaxas + difEquipMensal - consolidado.totalReducaoMes;
  const resultadoClienteAno = totalAnualTaxas + difEquipAnual - consolidado.totalReducaoAno;
  const resultadoBancoMes = incrementoMesInvest + negociacao.totalMes;
  const resultadoBancoAno = incrementoAnoInvest + negociacao.totalAno;

  const statusCliente = classificarResultado(resultadoClienteMes);
  const statusBanco = classificarResultado(resultadoBancoMes);
  const statusTaxas = classificarResultado(totalMensalTaxas);
  const statusEquip = classificarResultado(difEquipMensal);
  const statusConsolidado = classificarResultado(consolidado.totalReducaoMes);
  const statusNegociacao = classificarResultado(negociacao.totalMes);
  const empresa = document.getElementById("nome-empresa")?.value || "Cliente não informado";

  const html = `
  <div class="resumo-linha">
    <div class="resumo-card resumo-card-elegante bg-taxas">
      <div class="resumo-card-header">
        <h4>Comparativo de Taxas</h4>
        <span class="resumo-chip ${statusTaxas}">${rotuloResultado(statusTaxas)}</span>
      </div>
      <div class="resumo-metricas">
        <div class="resumo-metrica"><span>Custo Cielo (mês)</span><strong>R$ ${formatarMoedaResumo(totalCustoCieloMensal)}</strong></div>
        <div class="resumo-metrica"><span>Custo Concorrente (mês)</span><strong>R$ ${formatarMoedaResumo(totalCustoConcMensal)}</strong></div>
        <div class="resumo-metrica"><span>Diferença mensal (Conc - Cielo)</span><strong>R$ ${formatarMoedaResumo(Math.abs(totalMensalTaxas))}</strong></div>
        <div class="resumo-metrica"><span>Diferença anual (Conc - Cielo)</span><strong>R$ ${formatarMoedaResumo(Math.abs(totalAnualTaxas))}</strong></div>
      </div>
    </div>

    <div class="resumo-card resumo-card-elegante bg-equipamentos">
      <div class="resumo-card-header">
        <h4>Equipamentos</h4>
        <span class="resumo-chip ${statusEquip}">${rotuloResultado(statusEquip)}</span>
      </div>
      <div class="resumo-metricas">
        <div class="resumo-metrica"><span>Qtd. Cielo</span><strong>${qtdCielo}</strong></div>
        <div class="resumo-metrica"><span>Qtd. Concorrente</span><strong>${qtdConc}</strong></div>
        <div class="resumo-metrica"><span>Custo Cielo (mês)</span><strong>R$ ${formatarMoedaResumo(custoCielo)}</strong></div>
        <div class="resumo-metrica"><span>Custo Concorrente (mês)</span><strong>R$ ${formatarMoedaResumo(custoConc)}</strong></div>
        <div class="resumo-metrica"><span>Diferença mensal (Conc - Cielo)</span><strong>R$ ${formatarMoedaResumo(Math.abs(difEquipMensal))}</strong></div>
      </div>
    </div>
  </div>

  <div class="resumo-linha">
    <div class="resumo-card resumo-card-elegante bg-servicos">
      <div class="resumo-card-header">
        <h4>Produtos e Serviços Consolidados</h4>
        <span class="resumo-chip ${statusConsolidado}">${rotuloResultado(statusConsolidado)}</span>
      </div>
      <div class="resumo-metricas">
        <div class="resumo-metrica"><span>Valor pago pelo cliente (mês)</span><strong>R$ ${formatarMoedaResumo(consolidado.totalValorMes)}</strong></div>
        <div class="resumo-metrica"><span>Valor pago pelo cliente (ano)</span><strong>R$ ${formatarMoedaResumo(consolidado.totalValorAno)}</strong></div>
        <div class="resumo-metrica"><span>Redução consolidada (mês)</span><strong>R$ ${formatarMoedaResumo(consolidado.totalReducaoMes)}</strong></div>
        <div class="resumo-metrica"><span>Redução consolidada (ano)</span><strong>R$ ${formatarMoedaResumo(consolidado.totalReducaoAno)}</strong></div>
        <div class="resumo-metrica"><span>Percentual médio</span><strong>${consolidado.totalPercentual.toFixed(1)}%</strong></div>
      </div>
    </div>

    <div class="resumo-card resumo-card-elegante bg-gdad">
      <div class="resumo-card-header">
        <h4>O que o Cliente trará na negociação</h4>
        <span class="resumo-chip ${statusNegociacao}">${rotuloResultado(statusNegociacao)}</span>
      </div>
      <div class="resumo-metricas">
        <div class="resumo-metrica"><span>Resultado mensal (novos)</span><strong>R$ ${formatarMoedaResumo(Math.abs(negociacao.totalMes))}</strong></div>
        <div class="resumo-metrica"><span>Resultado anual (novos)</span><strong>R$ ${formatarMoedaResumo(Math.abs(negociacao.totalAno))}</strong></div>
        <div class="resumo-metrica"><span>Tipo de cliente</span><strong>${(obterTipoClienteSelecionado() || "não informado").toUpperCase()}</strong></div>
      </div>
    </div>
  </div>

  <div class="resumo-linha">
    <div class="resumo-card resumo-card-elegante bg-invest" style="width: 100%;">
      <div class="resumo-card-header">
        <h4>Invest Fácil</h4>
        <span class="resumo-chip ${classificarResultado(incrementoMesInvest)}">${rotuloResultado(classificarResultado(incrementoMesInvest))}</span>
      </div>
      <div class="resumo-metricas">
        <div class="resumo-metrica"><span>Saldo médio projetado (mês)</span><strong>R$ ${formatarMoedaResumo(repasseMesInvest)}</strong></div>
        <div class="resumo-metrica"><span>Saldo médio projetado (ano)</span><strong>R$ ${formatarMoedaResumo(repasseAnoInvest)}</strong></div>
        <div class="resumo-metrica"><span>Incremento projetado (mês)</span><strong>R$ ${formatarMoedaResumo(incrementoMesInvest)}</strong></div>
        <div class="resumo-metrica"><span>Incremento projetado (ano)</span><strong>R$ ${formatarMoedaResumo(incrementoAnoInvest)}</strong></div>
      </div>
    </div>
  </div>

  <div id="bloco-resultado-total" class="resumo-hero">
    <div class="resumo-hero-topo">
      <p>Cliente: <strong id="nome-cliente-final">${empresa}</strong></p>
      <span class="resumo-chip neutro">Resultado Consolidado</span>
    </div>

    <div class="resumo-resultados-grid">
      <article class="resumo-resultado-card ${statusCliente}">
        <span class="resumo-resultado-titulo">Visão do Cliente</span>
        <div class="resumo-valor-principal ${statusCliente}">R$ ${formatarMoedaResumo(Math.abs(resultadoClienteMes))}</div>
        <p class="resumo-subvalor">Por mês</p>
        <p class="resumo-subvalor">R$ ${formatarMoedaResumo(Math.abs(resultadoClienteAno))} ao ano</p>
        <p class="resumo-subvalor"><strong>Status:</strong> ${rotuloResultado(statusCliente)}</p>
      </article>

      <article class="resumo-resultado-card ${statusBanco}">
        <span class="resumo-resultado-titulo">Visão do Banco</span>
        <div class="resumo-valor-principal ${statusBanco}">R$ ${formatarMoedaResumo(Math.abs(resultadoBancoMes))}</div>
        <p class="resumo-subvalor">Por mês</p>
        <p class="resumo-subvalor">R$ ${formatarMoedaResumo(Math.abs(resultadoBancoAno))} ao ano</p>
        <p class="resumo-subvalor"><strong>Status:</strong> ${rotuloResultado(statusBanco)}</p>
      </article>
    </div>

    <p class="resumo-obs">
      O consolidado considera Produtos e Serviços Diversos + Pix na Maquininha + Demais Serviços Pix.
      A seção de negociação considera apenas volumes novos informados.
    </p>
  </div>
`;

  const resultado = document.getElementById("resumo-final");
  if (resultado) {
    const titulo = resultado.querySelector("h2");
    const tituloClonado = titulo?.cloneNode(true);
    resultado.innerHTML = "";
    if (tituloClonado) resultado.appendChild(tituloClonado);

    const wrapper = document.createElement("div");
    wrapper.innerHTML = html;
    while (wrapper.firstChild) resultado.appendChild(wrapper.firstChild);
    resultado.style.display = "block";
  }
}




// ===============================
// GERAR PDF
// ===============================

function adicionarBlocoNoPDF(pdf, canvas, config, estadoPagina, adicionarEspaco = true) {
  const { margemMm, larguraUtilMm, alturaUtilMm, espacoEntreBlocosMm } = config;
  const limiteInferiorMm = margemMm + alturaUtilMm;
  const pxPorMm = canvas.width / larguraUtilMm;
  const alturaFatiaPx = Math.max(1, Math.floor(alturaUtilMm * pxPorMm));
  let deslocamentoPx = 0;

  while (deslocamentoPx < canvas.height) {
    const restantePx = canvas.height - deslocamentoPx;
    const fatiaAtualPx = Math.min(alturaFatiaPx, restantePx);
    const fatiaAtualMm = fatiaAtualPx / pxPorMm;

    if (estadoPagina.cursorMm + fatiaAtualMm > limiteInferiorMm) {
      pdf.addPage();
      estadoPagina.cursorMm = margemMm;
    }

    const fatiaCanvas = document.createElement("canvas");
    fatiaCanvas.width = canvas.width;
    fatiaCanvas.height = fatiaAtualPx;

    const contexto = fatiaCanvas.getContext("2d");
    if (!contexto) {
      throw new Error("Nao foi possivel preparar a imagem para o PDF.");
    }

    contexto.fillStyle = "#FFFFFF";
    contexto.fillRect(0, 0, fatiaCanvas.width, fatiaCanvas.height);
    contexto.drawImage(
      canvas,
      0,
      deslocamentoPx,
      canvas.width,
      fatiaAtualPx,
      0,
      0,
      fatiaCanvas.width,
      fatiaCanvas.height
    );

    const imagem = fatiaCanvas.toDataURL("image/jpeg", 0.95);
    pdf.addImage(imagem, "JPEG", margemMm, estadoPagina.cursorMm, larguraUtilMm, fatiaAtualMm, undefined, "FAST");

    estadoPagina.cursorMm += fatiaAtualMm;
    deslocamentoPx += fatiaAtualPx;
  }

  if (!adicionarEspaco) return;

  if (estadoPagina.cursorMm + espacoEntreBlocosMm > limiteInferiorMm) {
    pdf.addPage();
    estadoPagina.cursorMm = margemMm;
  } else {
    estadoPagina.cursorMm += espacoEntreBlocosMm;
  }
}

async function exportarComoImagemPDF() {
  const area = document.querySelector(".container");
  const overlay = document.getElementById("loading-pdf-overlay");
  const jsPDFGlobal = window.jspdf?.jsPDF || window.jsPDF;

  if (!area) {
    alert("Área para exportação não encontrada.");
    return;
  }

  if (typeof html2canvas !== "function") {
    alert("Biblioteca de captura nao carregada. Recarregue a pagina e tente novamente.");
    return;
  }

  if (typeof jsPDFGlobal !== "function") {
    alert("Biblioteca de PDF nao carregada. Recarregue a pagina e tente novamente.");
    return;
  }

  if (overlay) overlay.style.display = "flex";

  try {
    await new Promise(resolve => setTimeout(resolve, 200));

    const blocosVisiveis = Array.from(area.children).filter(el => {
      const estilo = window.getComputedStyle(el);
      return estilo.display !== "none" && estilo.visibility !== "hidden" && el.offsetHeight > 0;
    });

    if (blocosVisiveis.length === 0) {
      throw new Error("Nenhum bloco visivel encontrado para exportacao.");
    }

    const pdf = new jsPDFGlobal({ orientation: "portrait", unit: "mm", format: "a4" });
    const margemMm = 8;
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const larguraUtilMm = pageWidth - margemMm * 2;
    const alturaUtilMm = pageHeight - margemMm * 2;
    const estadoPagina = { cursorMm: margemMm };
    const config = { margemMm, larguraUtilMm, alturaUtilMm, espacoEntreBlocosMm: 3 };

    for (let i = 0; i < blocosVisiveis.length; i++) {
      const bloco = blocosVisiveis[i];
      const canvas = await html2canvas(bloco, {
        scale: 1.6,
        useCORS: true,
        allowTaint: false,
        backgroundColor: "#FFFFFF",
        logging: false,
        scrollX: 0,
        scrollY: -window.scrollY,
        windowWidth: document.documentElement.scrollWidth,
        ignoreElements: element => element.id === "loading-pdf-overlay"
      });

      adicionarBlocoNoPDF(pdf, canvas, config, estadoPagina, i < blocosVisiveis.length - 1);
    }

    pdf.save("relatorio-simulacao.pdf");
  } catch (error) {
    console.error("Erro ao gerar PDF:", error);
    alert("Ocorreu um erro ao gerar o PDF.");
  } finally {
    if (overlay) overlay.style.display = "none";
  }
}





// ===============================
// LIMPAR TUDO GLOBAL
// ===============================

function limparTudo() {
  Swal.fire({
    title: 'Tem certeza?',
    text: "Todos os dados preenchidos serão perdidos!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Sim, limpar tudo',
    cancelButtonText: 'Cancelar'
  }).then((result) => {
    if (result.isConfirmed) {
      location.reload();
    }
  });
}



document.querySelectorAll('input[name="tipo-visao"]').forEach(radio => {
  radio.addEventListener('change', atualizarCamposVisao);
});

function atualizarCamposVisao() {
  const visaoGrupo = document.getElementById("visao-grupo").checked;

  const labelNomeEmpresa = document.querySelector('label[for="nome-empresa"]') || document.querySelector('label:has(#nome-empresa)');
  const campoAgencia = document.getElementById("agencia")?.closest("label");
  const campoConta = document.getElementById("conta")?.closest("label");
  const campoCnpj = document.getElementById("cnpj-empresa")?.closest("label");

  const campoNumeroGrupo = document.getElementById("campo-numero-grupo");
  const campoComposicao = document.getElementById("campo-composicao");

  if (visaoGrupo) {
    if (labelNomeEmpresa) labelNomeEmpresa.childNodes[0].nodeValue = "Nome do Grupo:";
    if (campoAgencia) campoAgencia.style.display = "none";
    if (campoConta) campoConta.style.display = "none";
    if (campoCnpj) campoCnpj.style.display = "none";
    campoNumeroGrupo.style.display = "block";
    campoComposicao.style.display = "block";
  } else {
    if (labelNomeEmpresa) labelNomeEmpresa.childNodes[0].nodeValue = "Nome da Empresa:";
    if (campoAgencia) campoAgencia.style.display = "block";
    if (campoConta) campoConta.style.display = "block";
    if (campoCnpj) campoCnpj.style.display = "block";
    campoNumeroGrupo.style.display = "none";
    campoComposicao.style.display = "none";
  }
}

["lista-cnpjs", "lista-agencias", "lista-contas"].forEach(id => {
  const campo = document.getElementById(id);
  if (campo) {
    campo.addEventListener("keypress", function(e) {
      // Permite só números e Enter
      if (!/[0-9]/.test(e.key) && e.key !== "Enter" && e.key !== "Backspace") {
        e.preventDefault();
      }
    });
  }
});

function adicionarItem(tipo) {
  let inputId = "";
  let listaId = "";

  if (tipo === "cnpj") {
    inputId = "input-cnpj";
    listaId = "lista-cnpjs";
  } else if (tipo === "agencia") {
    inputId = "input-agencia";
    listaId = "lista-agencias";
  } else if (tipo === "conta") {
    inputId = "input-conta";
    listaId = "lista-contas";
  }

  const input = document.getElementById(inputId);
  const lista = document.getElementById(listaId);
  const valor = input.value.trim();

  if (valor && /^\d+$/.test(valor)) {  // Só permite números
    const item = document.createElement("span");
    item.className = "composicao-item";
    item.textContent = valor;

    const botaoRemover = document.createElement("button");
    botaoRemover.textContent = "×";
    botaoRemover.onclick = () => item.remove();

    item.appendChild(botaoRemover);
    lista.appendChild(item);
    input.value = "";
  } else {
    Swal.fire({
      icon: "warning",
      title: "Somente números!",
      text: "Por favor, digite apenas números antes de adicionar.",
    });
  }
}

function criarChip(valor, listaId) {
  const lista = document.getElementById(listaId);
  const chip = document.createElement("span");
  chip.className = "composicao-item";
  chip.textContent = valor;

  const botao = document.createElement("button");
  botao.textContent = "×";
  botao.onclick = () => chip.remove();

  chip.appendChild(botao);
  lista.appendChild(chip);
}

function configurarCampoComEnter(inputId, listaId) {
  const input = document.getElementById(inputId);
  input.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      adicionarItensDoInput(input, listaId);
    }
  });

  input.addEventListener("blur", function() {
    adicionarItensDoInput(input, listaId);
  });
}

function adicionarItensDoInput(input, listaId) {
  const valores = input.value.split(",").map(v => v.trim()).filter(v => v);
  let algumInvalido = false;

  valores.forEach(valor => {
    if (/^\d+$/.test(valor)) {
      criarChip(valor, listaId);
    } else {
      algumInvalido = true;
    }
  });

  if (algumInvalido) {
    Swal.fire({
      icon: "warning",
      title: "Atenção!",
      text: "Digite apenas números (separados por vírgula).",
    });
  }

  input.value = "";
}


// 👉 Inicie quando carregar a página:
document.addEventListener("DOMContentLoaded", function() {
  configurarCampoComEnter("input-cnpj", "lista-cnpjs");
  configurarCampoComEnter("input-agencia", "lista-agencias");
  configurarCampoComEnter("input-conta", "lista-contas");
});
























