@echo off
REM ============================================================================
REM  ESTE ARQUIVO PRECISA SER ASCII PURO.
REM
REM  O cmd.exe le em codepage ANSI, nao em UTF-8. Um travessao ou uma letra
REM  acentuada aqui dentro vira dois ou tres bytes que ele nao entende, e o
REM  parser perde o comeco das linhas seguintes - o script morre com erros do
REM  tipo "'etlocal' nao e reconhecido". Sem acento, sem travessao, sem aspas
REM  tipograficas.
REM ============================================================================
REM ============================================================================
REM  Monta o ZIP para levar ao PC do banco.
REM
REM  Gera calculadora_pricing.zip NA PASTA ACIMA desta - normalmente a Area de
REM  Trabalho. E de proposito: o caminho da Area de Trabalho muda quando o
REM  OneDrive esta ligado (vira "OneDrive\Area de Trabalho") e o %USERPROFILE%
REM  \Desktop deixa de existir. Subir um nivel sempre funciona.
REM
REM  Usa o tar.exe do proprio Windows e nao o Compress-Archive: ele recebe
REM  caminhos relativos, e assim o acento de "Area de Trabalho" nunca precisa
REM  atravessar a linha de comando.
REM
REM  ---------------------------------------------------------------------------
REM  O QUE FICA DE FORA
REM
REM    config\segredos.php   as credenciais DESTA maquina. As de la sao outras,
REM                          e levar senha de banco dentro de um zip e o tipo
REM                          de descuido que ninguem quer explicar depois.
REM    node_modules\         so serve para rodar o teste dos motores aqui.
REM    *.log, *.zip          lixo de execucao.
REM
REM  O QUE VAI JUNTO, e faz falta: banco\INSTALAR.sql, mock\, testes\ e os
REM  arquivos .md. No PC do banco voce vai querer conferir se a conta bate e
REM  ler o passo a passo - e pode nao ter como baixar nada por la.
REM ============================================================================

setlocal
set NOME=calculadora_pricing
set ZIP=%NOME%.zip

echo.
echo  Montando o pacote...
echo.

REM --- sobe um nivel; dai em diante so caminho relativo --------------------
pushd "%~dp0.."
if errorlevel 1 (
    echo  ERRO: nao consegui entrar na pasta acima.
    exit /b 1
)

if not exist "%NOME%\banco\INSTALAR.sql" (
    echo  ERRO: nao achei %NOME%\banco\INSTALAR.sql.
    echo  Este script precisa ficar DENTRO da pasta do projeto.
    popd
    exit /b 1
)

if exist "%ZIP%" del "%ZIP%"

tar -a -c -f "%ZIP%" ^
    --exclude="%NOME%/node_modules" ^
    --exclude="%NOME%/config/segredos.php" ^
    --exclude="*.log" ^
    --exclude="*.zip" ^
    "%NOME%"

if not exist "%ZIP%" (
    echo  ERRO: o zip nao foi criado.
    popd
    exit /b 1
)

REM --- confere que a senha nao entrou --------------------------------------
REM  Barato de fazer e caro de esquecer: um zip com a senha do banco dentro,
REM  circulando por e-mail, e um problema que nao se desfaz.
tar -tf "%ZIP%" | findstr /E "config/segredos.php" >nul
if not errorlevel 1 (
    echo  ERRO: segredos.php entrou no pacote. Apagando por seguranca.
    del "%ZIP%"
    popd
    exit /b 1
)

for %%A in ("%ZIP%") do set TAMANHO=%%~zA
set /a TAMANHO_KB=%TAMANHO%/1024

echo  Pronto: %CD%\%ZIP%
echo  Tamanho: %TAMANHO_KB% KB
echo  Sem a senha do banco dentro (conferido).
echo.
echo  ---------------------------------------------------------------
echo   NO PC DO BANCO, nesta ordem:
echo.
echo    1. descompacte em C:\xampp\htdocs\calculadora_pricing
echo       o caminho NAO pode ter acento - o PHP no Windows nao abre
echo.
echo    2. abra banco\INSTALAR.sql e troque as 3 linhas do PASSO 1
echo       pelo seu e-mail, nome e funcional
echo.
echo    3. rode INSTALAR.sql no phpMyAdmin, aba Importar
echo       a conferencia no fim tem que dizer OK em tudo
echo.
echo    4. copie config\segredos.exemplo.php para config\segredos.php
echo       e preencha os dados do banco de la
echo.
echo    5. troque o e-mail em mock\perfil.json pelo mesmo do passo 2
echo.
echo    6. abra http://localhost/calculadora_pricing/
echo  ---------------------------------------------------------------
echo.

popd
endlocal
