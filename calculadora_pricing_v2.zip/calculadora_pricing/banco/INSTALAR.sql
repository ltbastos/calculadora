/* ============================================================================
   CALCULADORA DE PRICING PJ - INSTALACAO COMPLETA

   Rode ESTE arquivo, uma vez, e o banco fica pronto: tabelas, catalogo de
   produtos, regua do veredito e cinco clientes ficticios para a tela abrir
   funcionando.

   ---------------------------------------------------------------------------
   ANTES DE RODAR - troque as tres linhas do PASSO 1 pelo SEU e-mail
   corporativo, nome e funcional.

   Por que isso importa: a carteira e encontrada pelo e-mail. Se ele nao bater
   com o que o Power App entrega (ou com mock/perfil.json, no modo local), a
   tela abre dizendo que voce nao tem cliente nenhum - e o problema parece ser
   da ferramenta, quando e so o e-mail.

   ---------------------------------------------------------------------------
   COMO RODAR

   phpMyAdmin:  aba Importar, escolha este arquivo, Executar.
                (ou aba SQL, cole o conteudo inteiro, Executar)

   Terminal:    mysql -u root -p < INSTALAR.sql

   Pode rodar quantas vezes quiser: o script APAGA e recria tudo do zero. Isso
   e proposital enquanto o dado e ficticio - mas e justamente por isso que ele
   NAO deve ser rodado de novo depois que a carga real entrar. Para trocar o
   ficticio pelo real sem perder o catalogo, use LIMPAR-MOCK.sql.

   ---------------------------------------------------------------------------
   O QUE ESTE ARQUIVO CRIA, em ordem:

     1. o banco calculadora_pricing
     2. as 9 tabelas
     3. os 14 produtos e os 9 parametros da regua
     4. 5 clientes ficticios (o MOCK, que depois sai)
     5. voce como administrador
     6. uma conferencia, que imprime o resultado no fim

   ---------------------------------------------------------------------------
   NAO EDITE ESTE ARQUIVO A MAO. Ele e gerado por banco/gerar-instalador.py a
   partir de 01-esquema.sql, 02-produtos.sql e 03-exemplo.sql.

   Compativel com MariaDB 10.1+ e MySQL 5.7+.
   ========================================================================== */


/* ############################################################################
   PASSO 1 - TROQUE ESTAS TRES LINHAS
   ######################################################################### */

SET @MEU_EMAIL       = 'luantbastos@gmail.com';
SET @MEU_NOME        = 'Luan Bastos';
SET @MINHA_FUNCIONAL = '9437643';

/* ######################################################################### */


/* Sem truncar calado: em modo nao-estrito o MySQL aceita um ENUM invalido
   gravando string vazia, e ai o motor de calculo recebe um produto que nao
   sabe como cobra. Melhor a carga falhar na hora. */
SET @MODO_ANTIGO = @@SESSION.sql_mode;
SET SESSION sql_mode = 'STRICT_ALL_TABLES';

/* A collation da CONEXAO precisa ser a mesma das colunas. Uma variavel de
   usuario (@MEU_EMAIL) nasce com a collation da conexao, e comparar ela com
   uma coluna utf8mb4_unicode_ci da "Illegal mix of collations" e derruba o
   script no meio. O padrao da conexao varia de instalacao para instalacao -
   aqui nao fica ao acaso. */
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;


CREATE DATABASE IF NOT EXISTS calculadora_pricing
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE calculadora_pricing;

/* ############################################################################
   PARTE 1 - AS TABELAS
   ######################################################################### */

/* ===========================================================================
   encarteiramento — quem atende quem

   Uma linha por CONTA. O mesmo CNPJ costuma ter várias contas, e o mesmo
   grupo econômico vários CNPJs — por isso a linha nasce na conta, que é o
   nível mais fino. Subir para CNPJ ou grupo é só agrupar.

   A carteira do usuário sai daqui: entra o e-mail (ou a funcional) de quem
   abriu a página, saem os clientes dele. Nenhuma tela mostra cliente de
   outro gerente sem isso bater.
   ========================================================================= */
DROP TABLE IF EXISTS encarteiramento;
CREATE TABLE encarteiramento (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,

  /* --- o cliente ------------------------------------------------------- */
  cnpj              VARCHAR(14)  NOT NULL COMMENT 'So digitos, 14 posicoes, com zeros a esquerda',
  razao_social      VARCHAR(180) NOT NULL,
  nome_fantasia     VARCHAR(180)     NULL,

  /* --- a conta --------------------------------------------------------- */
  agencia           VARCHAR(6)       NULL,
  conta             VARCHAR(14)      NULL COMMENT 'So digitos, DV incluido no fim',
  conta_exibicao    VARCHAR(24)      NULL COMMENT 'Como o gerente le: 1234 / 0012345-6',

  /* --- o grupo economico ----------------------------------------------- */
  grupo_numero      VARCHAR(20)      NULL,
  grupo_nome        VARCHAR(180)     NULL,

  /* --- quem atende ------------------------------------------------------
     O e-mail é a chave de verdade: é o que o Power App / Automate entrega
     com certeza. A funcional entra junto porque nem todo extrato de carteira
     traz e-mail, e aí ela salva o dia.                                     */
  gerente_email     VARCHAR(160)     NULL,
  gerente_funcional VARCHAR(20)      NULL,
  gerente_nome      VARCHAR(160)     NULL,

  /* --- onde o cliente se encaixa --------------------------------------- */
  segmento          VARCHAR(60)      NULL COMMENT 'Ex.: Corporate, Empresas, Varejo PJ',
  porte             VARCHAR(40)      NULL,
  regional          VARCHAR(80)      NULL,
  juncao            VARCHAR(20)      NULL,

  ativo             TINYINT(1)   NOT NULL DEFAULT 1,
  carga_em          DATETIME         NULL COMMENT 'Quando esta linha entrou na ultima carga',

  PRIMARY KEY (id),
  KEY ix_enc_cnpj     (cnpj),
  KEY ix_enc_conta    (conta),
  KEY ix_enc_grupo    (grupo_numero),
  KEY ix_enc_email    (gerente_email),
  KEY ix_enc_func     (gerente_funcional),
  KEY ix_enc_razao    (razao_social)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   dim_produto — o catálogo, e o que cada fator significa

   Aqui mora a decisão que faz a calculadora inteira funcionar: um produto não
   cobra sempre do mesmo jeito.

     Emissão de Cobrança  cobra POR BOLETO      -> volume é QUANTIDADE,
                                                   fator é TARIFA em R$
     Invest Fácil         cobra SOBRE O SALDO   -> volume é VALOR em R$,
                                                   fator é TAXA em %

   Por isso cada produto declara os dois tipos, e o motor de cálculo só
   pergunta ao produto como ele cobra. Produto novo entra como linha, não
   como alteração de código.

   ---------------------------------------------------------------------------
   ATENÇÃO AO FORMATO DO FATOR — é o erro mais fácil de cometer aqui:

     tipo_fator = TARIFA     o fator está em REAIS por unidade.
                             2.45000000  = R$ 2,45 por boleto

     tipo_fator = TAXA       o fator está em PONTOS PERCENTUAIS, já na
                             escala que a área fala.
                             0.35000000  = 0,35%   (e NÃO 35%)
                             O motor divide por 100 na hora de calcular.

   A tela de administração mostra o sufixo certo (R$ ou %) ao lado do campo,
   justamente para ninguém digitar 35 quando queria dizer 0,35.
   ========================================================================= */
DROP TABLE IF EXISTS dim_produto;
CREATE TABLE dim_produto (
  codigo          VARCHAR(40)  NOT NULL COMMENT 'Slug estavel. Nunca mude depois de usado em simulacao',
  nome            VARCHAR(120) NOT NULL COMMENT 'O nome que o gerente le na tela',
  grupo           VARCHAR(60)  NOT NULL DEFAULT 'Outros' COMMENT 'Agrupador visual da tabela',
  ordem           SMALLINT     NOT NULL DEFAULT 999,

  /* --- como o produto cobra -------------------------------------------- */
  tipo_volume     ENUM('QUANTIDADE','VALOR','CONTEXTO') NOT NULL DEFAULT 'VALOR',
  tipo_fator      ENUM('TARIFA','TAXA','NENHUM')        NOT NULL DEFAULT 'TAXA',
  periodicidade   ENUM('MENSAL','ANUAL')                NOT NULL DEFAULT 'MENSAL',

  /* CONTEXTO + NENHUM é a dupla para o que NÃO gera receita mas importa na
     conversa — o prazo contratual da Cielo, por exemplo. Entra na tela, sai
     no relatório, e fica de fora de toda soma.                             */

  unidade         VARCHAR(40)      NULL COMMENT 'Ex.: boletos/mes, funcionarios, meses',
  ajuda           VARCHAR(255)     NULL COMMENT 'Aparece no balao de ajuda do produto',

  /* --- o preço ---------------------------------------------------------- */
  fator           DECIMAL(18,8) NOT NULL DEFAULT 0 COMMENT 'R$ se TARIFA, pontos percentuais se TAXA',
  fator_piso      DECIMAL(18,8)     NULL COMMENT 'Minimo que o gerente pode negociar. NULL = sem piso',
  fator_teto      DECIMAL(18,8)     NULL COMMENT 'Maximo. NULL = sem teto',

  ativo           TINYINT(1)   NOT NULL DEFAULT 1,
  atualizado_em   DATETIME         NULL,
  atualizado_por  VARCHAR(160)     NULL,

  PRIMARY KEY (codigo),
  KEY ix_prod_ativo (ativo, ordem)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   fdados — o retrato do cliente hoje

   Uma linha por (chave, nível). O mesmo cliente pode aparecer três vezes:
   uma pela conta, uma pelo CNPJ e uma pelo grupo econômico. Não é duplicata,
   são três recortes do mesmo cliente — e a tela deixa o gerente escolher em
   qual deles quer negociar.

   A CHAVE guarda só dígitos, sempre. CNPJ com ponto, conta com traço e grupo
   com prefixo são formas de ESCREVER a mesma coisa; se o banco guardar a
   forma escrita, a busca falha no primeiro cliente que alguém digitou
   diferente. A tela normaliza antes de procurar.
   ========================================================================= */
DROP TABLE IF EXISTS fdados;
CREATE TABLE fdados (
  id                      INT UNSIGNED NOT NULL AUTO_INCREMENT,

  chave                   VARCHAR(24) NOT NULL COMMENT 'So digitos: CNPJ, conta ou numero do grupo',
  nivel                   ENUM('CONTA','CNPJ','GRUPO') NOT NULL,

  /* Repetido aqui de propósito: o gerente precisa ver o nome do cliente
     mesmo quando a busca entrou por um número de grupo que não está no
     encarteiramento dele.                                                  */
  razao_social            VARCHAR(180)     NULL,

  /* --- o que o banco sabe do cliente ------------------------------------ */
  faturamento_mensal_medio  DECIMAL(18,2) NOT NULL DEFAULT 0,
  receita_mensal_atual      DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'Soma da receita de todos os produtos hoje',
  receita_projetada_ano     DECIMAL(18,2) NOT NULL DEFAULT 0,

  segmento                VARCHAR(60)      NULL,
  porte                   VARCHAR(40)      NULL,
  data_relacionamento     DATE             NULL COMMENT 'Desde quando e cliente. Vazio = prospect',

  referencia              CHAR(7)          NULL COMMENT 'Mes-base dos numeros, AAAA-MM',
  carga_em                DATETIME         NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uq_fdados (chave, nivel),
  KEY ix_fdados_razao (razao_social)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   fdados_produto — a abertura de fdados, produto a produto

   Formato longo: uma linha por cliente E produto. É o formato que a planilha
   da área já usa por dentro, e o único que aguenta produto novo sem mexer no
   banco — produto novo é uma linha a mais, nunca uma coluna a mais.

   receita_atual vem do banco em vez de ser calculada de volta a partir do
   volume, e isso é proposital: a receita que o cliente paga hoje pode ter
   desconto, acordo antigo ou condição especial que o fator padrão da tabela
   não reproduz. A tela avisa quando os dois não batem, mas quem manda no
   "hoje" é o número que veio do banco.
   ========================================================================= */
DROP TABLE IF EXISTS fdados_produto;
CREATE TABLE fdados_produto (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,

  chave           VARCHAR(24) NOT NULL,
  nivel           ENUM('CONTA','CNPJ','GRUPO') NOT NULL,
  produto_codigo  VARCHAR(40) NOT NULL,

  volume_atual    DECIMAL(18,4) NOT NULL DEFAULT 0 COMMENT 'Quantidade ou R$, conforme tipo_volume do produto',
  receita_atual   DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'O que esse produto rende hoje, em R$/mes',

  referencia      CHAR(7)          NULL,
  carga_em        DATETIME         NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uq_fdprod (chave, nivel, produto_codigo),
  KEY ix_fdprod_produto (produto_codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   fator_historico — o rastro de quem mexeu no preço

   Gravado pela própria tela de administração, a cada alteração. Nunca é
   apagado. Quando alguém perguntar "por que essa simulação de março usou
   2,10 se hoje é 2,45?", a resposta está aqui.
   ========================================================================= */
DROP TABLE IF EXISTS fator_historico;
CREATE TABLE fator_historico (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  produto_codigo  VARCHAR(40)  NOT NULL,
  campo           VARCHAR(40)  NOT NULL DEFAULT 'fator' COMMENT 'fator, fator_piso, fator_teto, ativo...',
  valor_antes     VARCHAR(60)      NULL,
  valor_depois    VARCHAR(60)      NULL,
  motivo          VARCHAR(255)     NULL,
  usuario_nome    VARCHAR(160)     NULL,
  usuario_email   VARCHAR(160)     NULL,
  criado_em       DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_hist_produto (produto_codigo, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   parametro — a régua do veredito, e o resto do que a área regula

   Tabela chave-valor de propósito: parâmetro novo não pede coluna nova. O
   valor viaja como texto e o PHP converte, porque aqui cabe número, texto e
   sim/não no mesmo lugar.
   ========================================================================= */
DROP TABLE IF EXISTS parametro;
CREATE TABLE parametro (
  chave           VARCHAR(60)  NOT NULL,
  valor           VARCHAR(255) NOT NULL,
  rotulo          VARCHAR(160)     NULL COMMENT 'Como aparece na tela de administracao',
  ajuda           VARCHAR(255)     NULL,
  tipo            ENUM('NUMERO','PERCENTUAL','DINHEIRO','TEXTO','BOOLEANO') NOT NULL DEFAULT 'NUMERO',
  grupo           VARCHAR(60)  NOT NULL DEFAULT 'Geral',
  ordem           SMALLINT     NOT NULL DEFAULT 999,
  atualizado_em   DATETIME         NULL,
  atualizado_por  VARCHAR(160)     NULL,
  PRIMARY KEY (chave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   simulacao / simulacao_item — o histórico

   O item guarda o fator usado NAQUELE momento. Não é redundância: é o que
   impede a simulação de ontem de mudar de resultado porque a área reajustou
   a tarifa hoje de manhã.
   ========================================================================= */
DROP TABLE IF EXISTS simulacao_item;
DROP TABLE IF EXISTS simulacao;

CREATE TABLE simulacao (
  id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  protocolo             VARCHAR(20)  NOT NULL COMMENT 'Codigo curto para o gerente citar no e-mail',

  /* --- quem simulou ----------------------------------------------------- */
  usuario_nome          VARCHAR(160)     NULL,
  usuario_email         VARCHAR(160)     NULL,
  usuario_funcional     VARCHAR(20)      NULL,

  /* --- para quem -------------------------------------------------------- */
  chave                 VARCHAR(24)  NOT NULL,
  nivel                 ENUM('CONTA','CNPJ','GRUPO') NOT NULL,
  razao_social          VARCHAR(180)     NULL,
  cliente_novo          TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '1 = nao havia nada em fdados',

  /* --- o resultado, congelado ------------------------------------------- */
  receita_atual_mes     DECIMAL(18,2) NOT NULL DEFAULT 0,
  receita_projetada_mes DECIMAL(18,2) NOT NULL DEFAULT 0,
  incremento_mes        DECIMAL(18,2) NOT NULL DEFAULT 0,
  variacao_pct          DECIMAL(12,4) NOT NULL DEFAULT 0,
  receita_ano           DECIMAL(18,2) NOT NULL DEFAULT 0,
  veredito              ENUM('APROVADO','ATENCAO','REPROVADO') NOT NULL DEFAULT 'ATENCAO',
  veredito_texto        VARCHAR(255)     NULL,

  observacao            TEXT             NULL,
  criado_em             DATETIME     NOT NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uq_sim_protocolo (protocolo),
  KEY ix_sim_usuario (usuario_email, criado_em),
  KEY ix_sim_cliente (chave, nivel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE simulacao_item (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  simulacao_id       INT UNSIGNED NOT NULL,
  produto_codigo     VARCHAR(40)  NOT NULL,
  produto_nome       VARCHAR(120)     NULL COMMENT 'Congelado: o nome pode mudar no catalogo',

  volume_atual       DECIMAL(18,4) NOT NULL DEFAULT 0,
  receita_atual      DECIMAL(18,2) NOT NULL DEFAULT 0,
  incremento_volume  DECIMAL(18,4) NOT NULL DEFAULT 0 COMMENT 'O que o gerente digitou',
  fator_usado        DECIMAL(18,8) NOT NULL DEFAULT 0,
  fator_negociado    TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '1 = gerente alterou o fator padrao',
  receita_incremento DECIMAL(18,2) NOT NULL DEFAULT 0,
  receita_projetada  DECIMAL(18,2) NOT NULL DEFAULT 0,

  PRIMARY KEY (id),
  KEY ix_item_sim (simulacao_id),
  CONSTRAINT fk_item_sim FOREIGN KEY (simulacao_id)
      REFERENCES simulacao (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


/* ===========================================================================
   app_admin — quem abre a tela de administração

   Deliberadamente simples: uma lista de e-mails. Quem autentica é o Power
   App / Automate; esta tabela só responde "este e-mail pode mexer nos
   fatores?". Sem senha, porque senha aqui seria uma segunda porta para
   guardar e nenhuma segurança a mais.
   ========================================================================= */
DROP TABLE IF EXISTS app_admin;
CREATE TABLE app_admin (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  email         VARCHAR(160) NOT NULL,
  nome          VARCHAR(160)     NULL,
  funcional     VARCHAR(20)      NULL,
  ativo         TINYINT(1)   NOT NULL DEFAULT 1,
  criado_em     DATETIME         NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

/* ############################################################################
   PARTE 2 - O CATALOGO DE PRODUTOS E A REGUA DO VEREDITO

   Esta parte PERMANECE quando o dado real entrar. Os fatores daqui sao
   provisorios; depois da primeira carga quem manda neles e a tela de
   administracao, e rodar este arquivo de novo apagaria o que a area tiver
   ajustado.
   ######################################################################### */

DELETE FROM dim_produto;

INSERT INTO dim_produto
  (codigo, nome, grupo, ordem, tipo_volume, tipo_fator, periodicidade, unidade, ajuda,
   fator, fator_piso, fator_teto, ativo, atualizado_em, atualizado_por)
VALUES

/* --- Investimentos ------------------------------------------------------ */
('invest_facil', 'Invest Fácil (Saldo)', 'Investimentos', 10,
 'VALOR', 'TAXA', 'MENSAL', 'R$ de saldo médio',
 'Saldo médio aplicado no mês. O fator é o spread mensal que o banco captura sobre esse saldo.',
 0.35000000, 0.15000000, 0.60000000, 1, NOW(), 'carga inicial'),

/* --- Cobrança -----------------------------------------------------------
   Duas linhas porque são duas cobranças diferentes sobre o mesmo produto:
   a tarifa por boleto emitido, e o percentual sobre o valor financeiro.   */
('cobranca_qtde', 'Emissão de Cobrança — Qtde/mês', 'Cobrança', 20,
 'QUANTIDADE', 'TARIFA', 'MENSAL', 'boletos/mês',
 'Quantidade de boletos emitidos por mês. O fator é a tarifa unitária por boleto.',
 2.45000000, 1.20000000, 4.50000000, 1, NOW(), 'carga inicial'),

('cobranca_valor', 'Emissão de Cobrança — R$', 'Cobrança', 30,
 'VALOR', 'TAXA', 'MENSAL', 'R$ liquidados/mês',
 'Valor financeiro liquidado via cobrança no mês.',
 0.08000000, 0.02000000, 0.20000000, 1, NOW(), 'carga inicial'),

/* --- Folha de pagamento ------------------------------------------------- */
('fopag_qtde', 'Fopag — Qtde de funcionários/mês', 'Folha de pagamento', 40,
 'QUANTIDADE', 'TARIFA', 'MENSAL', 'funcionários',
 'Funcionários processados na folha. O fator é a tarifa por crédito de salário.',
 3.90000000, 1.50000000, 7.00000000, 1, NOW(), 'carga inicial'),

('fopag_valor', 'Fopag — R$/mês', 'Folha de pagamento', 50,
 'VALOR', 'TAXA', 'MENSAL', 'R$ de folha/mês',
 'Volume financeiro da folha. Conta pelo saldo médio que circula na conta.',
 0.05000000, 0.01000000, 0.15000000, 1, NOW(), 'carga inicial'),

/* --- Pagamentos e recebimentos ------------------------------------------ */
('contas_pagar', 'Contas a Pagar — R$/mês', 'Pagamentos e recebimentos', 60,
 'VALOR', 'TAXA', 'MENSAL', 'R$ pagos/mês',
 'Volume mensal de pagamentos a fornecedores processados pelo banco.',
 0.06000000, 0.01000000, 0.18000000, 1, NOW(), 'carga inicial'),

('contas_receber', 'Contas a Receber — R$/mês', 'Pagamentos e recebimentos', 70,
 'VALOR', 'TAXA', 'MENSAL', 'R$ recebidos/mês',
 'Volume mensal de recebimentos processados pelo banco.',
 0.06000000, 0.01000000, 0.18000000, 1, NOW(), 'carga inicial'),

('pix', 'Pix — total média/mês', 'Pagamentos e recebimentos', 80,
 'VALOR', 'TAXA', 'MENSAL', 'R$ transacionados/mês',
 'Média mensal transacionada em Pix, entrada e saída.',
 0.02000000, 0.00000000, 0.10000000, 1, NOW(), 'carga inicial'),

/* --- Benefícios ---------------------------------------------------------- */
('alelo', 'Alelo — mês', 'Benefícios', 90,
 'VALOR', 'TAXA', 'MENSAL', 'R$ em benefícios/mês',
 'Valor mensal carregado em cartões de benefício.',
 0.90000000, 0.30000000, 2.00000000, 1, NOW(), 'carga inicial'),

/* --- Adquirência ---------------------------------------------------------
   TPV é ANUAL na planilha da área — o volume digitado já é o do ano inteiro.
   O motor sabe disso e não multiplica por 12 de novo na projeção do ano.   */
('tpv_ano', 'TPV esperado — ano', 'Adquirência', 100,
 'VALOR', 'TAXA', 'ANUAL', 'R$ de TPV no ano',
 'Volume total transacionado em cartão previsto para os 12 meses. O fator é a taxa média de desconto (MDR).',
 0.89000000, 0.45000000, 2.50000000, 1, NOW(), 'carga inicial'),

('ad_valorem', 'Ad Valorem — mês', 'Adquirência', 110,
 'VALOR', 'TAXA', 'MENSAL', 'R$ antecipados/mês',
 'Base mensal sujeita a ad valorem. O fator é o percentual cobrado sobre ela.',
 1.20000000, 0.50000000, 3.00000000, 1, NOW(), 'carga inicial'),

/* CONTEXTO: entra na tela, aparece no resumo, e fica fora de toda soma.
   Prazo não é receita — é o que sustenta (ou derruba) a receita projetada. */
('prazo_cielo', 'Prazo contratual Cielo', 'Adquirência', 120,
 'CONTEXTO', 'NENHUM', 'MENSAL', 'meses',
 'Prazo do contrato de adquirência, em meses. Não gera receita direta: entra como contexto da negociação.',
 0.00000000, NULL, NULL, 1, NOW(), 'carga inicial'),

/* --- Livres --------------------------------------------------------------
   As duas linhas "Outros" da planilha. Nascem desligadas: quem precisar
   liga na tela de administração, dá um nome de verdade e define o fator.  */
('outros_1', 'Outros 1', 'Outros', 900,
 'VALOR', 'TAXA', 'MENSAL', 'R$/mês',
 'Linha livre. Renomeie na tela de administração conforme a necessidade.',
 0.00000000, NULL, NULL, 0, NOW(), 'carga inicial'),

('outros_2', 'Outros 2', 'Outros', 910,
 'VALOR', 'TAXA', 'MENSAL', 'R$/mês',
 'Linha livre. Renomeie na tela de administração conforme a necessidade.',
 0.00000000, NULL, NULL, 0, NOW(), 'carga inicial');


/* ===========================================================================
   A RÉGUA DO VEREDITO

   A conta é sempre a mesma: quanto a receita projetada cresce sobre a receita
   que o cliente já dá hoje.

       variação = (receita projetada - receita atual) / receita atual x 100

   E aí ela cai numa das três faixas abaixo.

   O caso do PROSPECT é diferente e precisa de régua própria: quem não é
   cliente tem receita atual zero, e dividir por zero não dá veredito nenhum.
   Para esses, o que vale é o valor absoluto — a receita projetada precisa
   passar do piso. Os dois pisos abaixo cuidam disso.
   ========================================================================= */

DELETE FROM parametro;

INSERT INTO parametro (chave, valor, rotulo, ajuda, tipo, grupo, ordem, atualizado_em, atualizado_por) VALUES

('veredito_pct_aprovado', '15',
 'Incremento para aprovar',
 'A partir deste crescimento sobre a receita atual, a negociação sai como "vale a pena".',
 'PERCENTUAL', 'Régua do veredito', 10, NOW(), 'carga inicial'),

('veredito_pct_atencao', '5',
 'Incremento mínimo aceitável',
 'Abaixo deste crescimento a negociação sai como "não compensa". Entre este e o de cima, sai como "atenção".',
 'PERCENTUAL', 'Régua do veredito', 20, NOW(), 'carga inicial'),

('prospect_piso_aprovado', '5000',
 'Receita mínima para aprovar prospect',
 'Cliente novo não tem receita atual para comparar. Precisa gerar pelo menos isto por mês para valer a pena.',
 'DINHEIRO', 'Régua do veredito', 30, NOW(), 'carga inicial'),

('prospect_piso_atencao', '1500',
 'Receita mínima para não reprovar prospect',
 'Abaixo disto, a proposta para cliente novo sai como "não compensa".',
 'DINHEIRO', 'Régua do veredito', 40, NOW(), 'carga inicial'),

('meses_projecao', '12',
 'Meses na projeção do ano',
 'Quantos meses a calculadora usa para anualizar a receita mensal. Mexer aqui muda a coluna "Receita total ano".',
 'NUMERO', 'Cálculo', 50, NOW(), 'carga inicial'),

('permitir_negociar_fator', '1',
 'Gerente pode ajustar o fator',
 'Ligado, o gerente altera o fator de cada produto dentro do piso e do teto cadastrados. Desligado, o fator é fixo.',
 'BOOLEANO', 'Cálculo', 60, NOW(), 'carga inicial'),

('alerta_divergencia_pct', '10',
 'Alerta de divergência de receita',
 'Quando a receita que o cliente paga hoje difere do fator padrão acima desta margem, a tela sinaliza a linha.',
 'PERCENTUAL', 'Cálculo', 70, NOW(), 'carga inicial'),

('titulo_ferramenta', 'Calculadora de Pricing',
 'Nome da ferramenta',
 'Aparece no cabeçalho de todas as telas.',
 'TEXTO', 'Geral', 80, NOW(), 'carga inicial'),

('subtitulo_ferramenta', 'Pessoa Jurídica',
 'Complemento do nome',
 'O texto menor ao lado do nome, no cabeçalho.',
 'TEXTO', 'Geral', 90, NOW(), 'carga inicial');

/* ############################################################################
   PARTE 3 - OS DADOS FICTICIOS (O MOCK)

   TUDO DAQUI PARA BAIXO SAI quando o dado real entrar. Sao as tres tabelas de
   carga - encarteiramento, fdados e fdados_produto - mais voce como
   administrador.

   Use LIMPAR-MOCK.sql para remove-las sem tocar no catalogo.
   ######################################################################### */

DELETE FROM fdados_produto;
DELETE FROM fdados;
DELETE FROM encarteiramento;
DELETE FROM app_admin;


/* ===========================================================================
   Os gerentes fictícios

   Troque estes e-mails pelo SEU e-mail para a carteira aparecer quando você
   abrir a página em modo mock. O e-mail do mock está em mock/perfil.json.
   ========================================================================= */

INSERT INTO encarteiramento
  (cnpj, razao_social, nome_fantasia, agencia, conta, conta_exibicao,
   grupo_numero, grupo_nome, gerente_email, gerente_funcional, gerente_nome,
   segmento, porte, regional, juncao, ativo, carga_em)
VALUES

/* --- 1. Transportadora Rota Norte: uma conta, cliente relevante --------- */
('11222333000181', 'TRANSPORTADORA ROTA NORTE LTDA', 'Rota Norte',
 '1234', '00123456', '1234 / 0012345-6',
 '4471', 'GRUPO ROTA NORTE',
 @MEU_EMAIL, @MINHA_FUNCIONAL, @MEU_NOME,
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 2. Metalúrgica São Bento: cliente médio, pouca receita ------------- */
('22333444000172', 'METALURGICA SAO BENTO S/A', 'São Bento Metais',
 '1234', '00234567', '1234 / 0023456-7',
 '5580', 'GRUPO SAO BENTO',
 @MEU_EMAIL, @MINHA_FUNCIONAL, @MEU_NOME,
 'Empresas', 'Média', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 3. Distribuidora Vale Verde: duas contas, mesmo CNPJ ---------------
   Duas linhas, um CNPJ. É o caso que obriga a tabela a nascer na conta.  */
('33444555000163', 'DISTRIBUIDORA VALE VERDE LTDA', 'Vale Verde',
 '1234', '00345678', '1234 / 0034567-8',
 '6692', 'GRUPO VALE VERDE',
 @MEU_EMAIL, @MINHA_FUNCIONAL, @MEU_NOME,
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

('33444555000163', 'DISTRIBUIDORA VALE VERDE LTDA', 'Vale Verde — filial',
 '4321', '00456789', '4321 / 0045678-9',
 '6692', 'GRUPO VALE VERDE',
 @MEU_EMAIL, @MINHA_FUNCIONAL, @MEU_NOME,
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 3b. Outro CNPJ do MESMO grupo econômico ---------------------------
   Serve para o nível GRUPO ter o que somar.                             */
('33444555000244', 'VALE VERDE LOGISTICA LTDA', 'Vale Verde Log',
 '4321', '00567890', '4321 / 0056789-0',
 '6692', 'GRUPO VALE VERDE',
 @MEU_EMAIL, @MINHA_FUNCIONAL, @MEU_NOME,
 'Corporate', 'Grande', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 4. Clínica Bom Pastor: cliente sem produto contratado ------------- */
('44555666000154', 'CLINICA BOM PASTOR LTDA', 'Bom Pastor',
 '1234', '00678901', '1234 / 0067890-1',
 '7703', 'CLINICA BOM PASTOR',
 @MEU_EMAIL, @MINHA_FUNCIONAL, @MEU_NOME,
 'Empresas', 'Pequena', 'São Paulo Centro', '1234', 1, NOW()),

/* --- 5. Cliente de OUTRO gerente ---------------------------------------
   Existe na base, mas não na sua carteira. Serve para conferir que a
   tela não entrega cliente alheio.                                      */
('55666777000145', 'INDUSTRIA PAULISTA DE PAPEL LTDA', 'IPP',
 '9876', '00789012', '9876 / 0078901-2',
 '8814', 'GRUPO IPP',
 'outro.gerente@exemplo.com', '9111222', 'Outro Gerente',
 'Corporate', 'Grande', 'Campinas', '9876', 1, NOW());


/* ===========================================================================
   fdados — o retrato de cada cliente

   Os números de receita_mensal_atual batem com a soma de fdados_produto mais
   abaixo. Se você mexer num, mexa no outro: a tela compara os dois e avisa
   quando divergem.
   ========================================================================= */

INSERT INTO fdados
  (chave, nivel, razao_social, faturamento_mensal_medio, receita_mensal_atual,
   receita_projetada_ano, segmento, porte, data_relacionamento, referencia, carga_em)
VALUES

/* --- 1. Rota Norte: R$ 47.190 de receita mensal ------------------------- */
('00123456', 'CONTA', 'TRANSPORTADORA ROTA NORTE LTDA',
 8500000.00, 47190.00, 566280.00, 'Corporate', 'Grande', '2015-03-10', '2026-08', NOW()),
('11222333000181', 'CNPJ', 'TRANSPORTADORA ROTA NORTE LTDA',
 8500000.00, 47190.00, 566280.00, 'Corporate', 'Grande', '2015-03-10', '2026-08', NOW()),

/* --- 2. São Bento: R$ 3.640 de receita mensal --------------------------- */
('00234567', 'CONTA', 'METALURGICA SAO BENTO S/A',
 1200000.00, 3640.00, 43680.00, 'Empresas', 'Média', '2021-07-01', '2026-08', NOW()),
('22333444000172', 'CNPJ', 'METALURGICA SAO BENTO S/A',
 1200000.00, 3640.00, 43680.00, 'Empresas', 'Média', '2021-07-01', '2026-08', NOW()),

/* --- 3. Vale Verde: os três níveis -------------------------------------
   Matriz R$ 12.800 + filial R$ 5.200 = CNPJ R$ 18.000
   CNPJ R$ 18.000 + logística R$ 6.500 = GRUPO R$ 24.500                  */
('00345678', 'CONTA', 'DISTRIBUIDORA VALE VERDE LTDA',
 4200000.00, 12800.00, 153600.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),
('00456789', 'CONTA', 'DISTRIBUIDORA VALE VERDE LTDA',
 1600000.00, 5200.00, 62400.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),
('33444555000163', 'CNPJ', 'DISTRIBUIDORA VALE VERDE LTDA',
 5800000.00, 18000.00, 216000.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),
('00567890', 'CONTA', 'VALE VERDE LOGISTICA LTDA',
 2100000.00, 6500.00, 78000.00, 'Corporate', 'Grande', '2019-11-04', '2026-08', NOW()),
('33444555000244', 'CNPJ', 'VALE VERDE LOGISTICA LTDA',
 2100000.00, 6500.00, 78000.00, 'Corporate', 'Grande', '2019-11-04', '2026-08', NOW()),
('6692', 'GRUPO', 'GRUPO VALE VERDE',
 7900000.00, 24500.00, 294000.00, 'Corporate', 'Grande', '2018-05-22', '2026-08', NOW()),

/* --- 4. Bom Pastor: é cliente, mas não tem produto nenhum --------------- */
('00678901', 'CONTA', 'CLINICA BOM PASTOR LTDA',
 380000.00, 0.00, 0.00, 'Empresas', 'Pequena', '2024-02-19', '2026-08', NOW()),
('44555666000154', 'CNPJ', 'CLINICA BOM PASTOR LTDA',
 380000.00, 0.00, 0.00, 'Empresas', 'Pequena', '2024-02-19', '2026-08', NOW());


/* ===========================================================================
   fdados_produto — a abertura por produto

   Confira as contas: volume x fator tem que dar a receita. Os números foram
   escolhidos para fechar redondo, para você conseguir auditar a tela olhando.

   Rota Norte, por exemplo:
     Invest Fácil    R$ 6.000.000 x 0,35%  = R$ 21.000
     Cobrança qtde         8.000 x R$ 2,45 = R$ 19.600
     Fopag qtde              420 x R$ 3,90 = R$  1.638
     Contas a pagar  R$ 4.500.000 x 0,06%  = R$  2.700
     Pix             R$ 8.000.000 x 0,02%  = R$  1.600
     Alelo              R$ 25.000 x 0,90%  = R$    225
     Ad valorem        R$ 210.000 x 1,20%  = R$  2.520
                                             ----------
                                             R$ 49.283

   Está de propósito diferente dos R$ 47.190 de fdados: é o caso real de
   receita negociada abaixo da tabela. A tela sinaliza a divergência em vez
   de esconder, porque essa diferença costuma ser o assunto da reunião.
   ========================================================================= */

INSERT INTO fdados_produto
  (chave, nivel, produto_codigo, volume_atual, receita_atual, referencia, carga_em)
VALUES

/* --- 1. Rota Norte (conta e CNPJ, mesmos números) ----------------------- */
('00123456', 'CONTA', 'invest_facil',   6000000.0000, 21000.00, '2026-08', NOW()),
('00123456', 'CONTA', 'cobranca_qtde',     8000.0000, 18400.00, '2026-08', NOW()),
('00123456', 'CONTA', 'fopag_qtde',         420.0000,  1638.00, '2026-08', NOW()),
('00123456', 'CONTA', 'contas_pagar',  4500000.0000,  2700.00, '2026-08', NOW()),
('00123456', 'CONTA', 'pix',           8000000.0000,  1600.00, '2026-08', NOW()),
('00123456', 'CONTA', 'alelo',           25000.0000,   225.00, '2026-08', NOW()),
('00123456', 'CONTA', 'ad_valorem',     210000.0000,  1627.00, '2026-08', NOW()),

('11222333000181', 'CNPJ', 'invest_facil',   6000000.0000, 21000.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'cobranca_qtde',     8000.0000, 18400.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'fopag_qtde',         420.0000,  1638.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'contas_pagar',  4500000.0000,  2700.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'pix',           8000000.0000,  1600.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'alelo',           25000.0000,   225.00, '2026-08', NOW()),
('11222333000181', 'CNPJ', 'ad_valorem',     210000.0000,  1627.00, '2026-08', NOW()),

/* --- 2. São Bento: pouca coisa contratada ------------------------------ */
('00234567', 'CONTA', 'cobranca_qtde',   1200.0000, 2940.00, '2026-08', NOW()),
('00234567', 'CONTA', 'fopag_qtde',        80.0000,  312.00, '2026-08', NOW()),
('00234567', 'CONTA', 'pix',         1940000.0000,  388.00, '2026-08', NOW()),

('22333444000172', 'CNPJ', 'cobranca_qtde',   1200.0000, 2940.00, '2026-08', NOW()),
('22333444000172', 'CNPJ', 'fopag_qtde',        80.0000,  312.00, '2026-08', NOW()),
('22333444000172', 'CNPJ', 'pix',         1940000.0000,  388.00, '2026-08', NOW()),

/* --- 3. Vale Verde: matriz -------------------------------------------- */
('00345678', 'CONTA', 'invest_facil',  2000000.0000, 7000.00, '2026-08', NOW()),
('00345678', 'CONTA', 'cobranca_qtde',    1800.0000, 4410.00, '2026-08', NOW()),
('00345678', 'CONTA', 'contas_receber', 1500000.0000,  900.00, '2026-08', NOW()),
('00345678', 'CONTA', 'pix',           2450000.0000,  490.00, '2026-08', NOW()),

/* --- 3. Vale Verde: filial -------------------------------------------- */
('00456789', 'CONTA', 'cobranca_qtde',    1400.0000, 3430.00, '2026-08', NOW()),
('00456789', 'CONTA', 'fopag_qtde',        300.0000, 1170.00, '2026-08', NOW()),
('00456789', 'CONTA', 'pix',           3000000.0000,  600.00, '2026-08', NOW()),

/* --- 3. Vale Verde: consolidado no CNPJ da matriz --------------------- */
('33444555000163', 'CNPJ', 'invest_facil',  2000000.0000,  7000.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'cobranca_qtde',    3200.0000,  7840.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'fopag_qtde',        300.0000,  1170.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'contas_receber', 1500000.0000,   900.00, '2026-08', NOW()),
('33444555000163', 'CNPJ', 'pix',           5450000.0000,  1090.00, '2026-08', NOW()),

/* --- 3. Vale Verde Logística ------------------------------------------ */
('00567890', 'CONTA', 'invest_facil',  1000000.0000, 3500.00, '2026-08', NOW()),
('00567890', 'CONTA', 'contas_pagar',  3000000.0000, 1800.00, '2026-08', NOW()),
('00567890', 'CONTA', 'ad_valorem',      100000.0000, 1200.00, '2026-08', NOW()),

('33444555000244', 'CNPJ', 'invest_facil',  1000000.0000, 3500.00, '2026-08', NOW()),
('33444555000244', 'CNPJ', 'contas_pagar',  3000000.0000, 1800.00, '2026-08', NOW()),
('33444555000244', 'CNPJ', 'ad_valorem',      100000.0000, 1200.00, '2026-08', NOW()),

/* --- 3. Vale Verde: o grupo econômico inteiro ------------------------- */
('6692', 'GRUPO', 'invest_facil',  3000000.0000, 10500.00, '2026-08', NOW()),
('6692', 'GRUPO', 'cobranca_qtde',    3200.0000,  7840.00, '2026-08', NOW()),
('6692', 'GRUPO', 'fopag_qtde',        300.0000,  1170.00, '2026-08', NOW()),
('6692', 'GRUPO', 'contas_pagar',  3000000.0000,  1800.00, '2026-08', NOW()),
('6692', 'GRUPO', 'contas_receber', 1500000.0000,   900.00, '2026-08', NOW()),
('6692', 'GRUPO', 'pix',           5450000.0000,  1090.00, '2026-08', NOW()),
('6692', 'GRUPO', 'ad_valorem',     100000.0000,  1200.00, '2026-08', NOW());

/* Bom Pastor não entra aqui de propósito: é cliente do banco, tem cadastro
   em fdados, e não tem uma linha de produto sequer. A tela precisa abrir
   sem quebrar e tratar como receita zero. */


/* ===========================================================================
   Quem administra

   Coloque o SEU e-mail aqui para a tela de administração abrir no mock.
   ========================================================================= */
INSERT INTO app_admin (email, nome, funcional, ativo, criado_em) VALUES
(@MEU_EMAIL, @MEU_NOME, @MINHA_FUNCIONAL, 1, NOW());


/* ############################################################################
   PARTE 4 - CONFERENCIA

   Roda sozinha no fim e imprime o resultado. Se algum numero vier diferente do
   esperado, a instalacao nao ficou completa - e e melhor descobrir agora do
   que na frente de um cliente.
   ######################################################################### */

SET SESSION sql_mode = @MODO_ANTIGO;

SELECT '=== INSTALACAO CONCLUIDA ===' AS `Calculadora de Pricing PJ`;

SELECT
    'Tabelas criadas' AS `O que`,
    COUNT(*)          AS `Encontrado`,
    9                 AS `Esperado`,
    IF(COUNT(*) = 9, 'OK', '>>> FALTA TABELA') AS `Situacao`
  FROM information_schema.tables
 WHERE table_schema = 'calculadora_pricing'

UNION ALL SELECT 'Produtos no catalogo', COUNT(*), 14,
    IF(COUNT(*) = 14, 'OK', '>>> CONFERIR') FROM dim_produto
UNION ALL SELECT 'Produtos ativos', COUNT(*), 12,
    IF(COUNT(*) = 12, 'OK', '>>> CONFERIR') FROM dim_produto WHERE ativo = 1
UNION ALL SELECT 'Parametros da regua', COUNT(*), 9,
    IF(COUNT(*) = 9, 'OK', '>>> CONFERIR') FROM parametro
UNION ALL SELECT 'Contas no encarteiramento', COUNT(*), 7,
    IF(COUNT(*) = 7, 'OK', '>>> CONFERIR') FROM encarteiramento
UNION ALL SELECT 'Clientes em fdados', COUNT(*), 12,
    IF(COUNT(*) = 12, 'OK', '>>> CONFERIR') FROM fdados
UNION ALL SELECT 'Linhas por produto', COUNT(*), 45,
    IF(COUNT(*) = 45, 'OK', '>>> CONFERIR') FROM fdados_produto
UNION ALL SELECT 'Administradores', COUNT(*), 1,
    IF(COUNT(*) >= 1, 'OK', '>>> NINGUEM ADMINISTRA') FROM app_admin;


/* --- a sua carteira -------------------------------------------------------
   Zero aqui quer dizer que o e-mail do PASSO 1 nao bate com o que foi gravado.
   E o erro mais comum, e o mais facil de corrigir.                          */
SELECT
    'Clientes na SUA carteira' AS `O que`,
    COUNT(DISTINCT cnpj)       AS `Encontrado`,
    @MEU_EMAIL                 AS `Procurando pelo e-mail`,
    IF(COUNT(*) > 0, 'OK', '>>> NENHUM: confira o e-mail do PASSO 1') AS `Situacao`
  FROM encarteiramento
 WHERE ativo = 1
   AND LOWER(gerente_email) = LOWER(@MEU_EMAIL COLLATE utf8mb4_unicode_ci);


/* --- as somas batem? ------------------------------------------------------
   O cabecalho de fdados tem que bater com a soma da abertura por produto. Se
   divergir, o gerente ve dois numeros que nao conversam na mesma tela.      */
SELECT
    'Clientes com soma divergente' AS `O que`,
    COUNT(*)                       AS `Encontrado`,
    0                              AS `Esperado`,
    IF(COUNT(*) = 0, 'OK', '>>> CONFERIR A CARGA') AS `Situacao`
  FROM (
    SELECT f.chave
      FROM fdados f
      JOIN fdados_produto fp ON fp.chave = f.chave AND fp.nivel = f.nivel
     GROUP BY f.chave, f.nivel, f.receita_mensal_atual
    HAVING ABS(f.receita_mensal_atual - ROUND(SUM(fp.receita_atual), 2)) > 1
  ) AS divergentes;


/* --- produto orfao --------------------------------------------------------
   Codigo que a carga conhece e o catalogo nao. Some da tela sem avisar.     */
SELECT
    'Produtos orfaos na carga' AS `O que`,
    COUNT(*)                   AS `Encontrado`,
    0                          AS `Esperado`,
    IF(COUNT(*) = 0, 'OK', '>>> HA CODIGO SEM CADASTRO') AS `Situacao`
  FROM (
    SELECT DISTINCT fp.produto_codigo
      FROM fdados_produto fp
      LEFT JOIN dim_produto p ON p.codigo = fp.produto_codigo
     WHERE p.codigo IS NULL
  ) AS orfaos;


SELECT CONCAT(
    'Pronto. Agora troque o e-mail em mock/perfil.json para ', @MEU_EMAIL,
    ' e abra a calculadora.'
) AS `Proximo passo`;
