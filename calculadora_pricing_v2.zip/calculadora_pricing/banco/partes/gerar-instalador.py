# -*- coding: utf-8 -*-
"""
Monta banco/INSTALAR.sql costurando os três scripts separados.

    python banco/partes/gerar-instalador.py

RODE ISTO depois de mexer em 01-esquema.sql, 02-produtos.sql ou
03-exemplo.sql, todos aqui nesta pasta. O INSTALAR.sql é gerado, não escrito à mão — editá-lo
diretamente faz os dois caminhos divergirem, e o pior tipo de divergência é a
que só aparece na outra máquina.

Por que existem os dois caminhos:

  · o deploy em produção roda só 01 e 02, porque lá o mock não entra;
  · o pacote que viaja roda o INSTALAR.sql, que traz tudo e é um arquivo só.

Precisa de Python só para gerar. A aplicação não usa Python para nada.
"""
import io
import os
import re

AQUI = os.path.dirname(os.path.abspath(__file__))


def ler(nome):
    return io.open(os.path.join(AQUI, nome), encoding='utf-8').read()


def sem_cabecalho(txt):
    """Tira o comentário de abertura e o CREATE DATABASE / USE — eles passam a
       viver no cabeçalho único do instalador."""
    i = txt.find('*/')
    corpo = txt[i + 2:] if i > 0 else txt
    corpo = re.sub(r'(?m)^CREATE DATABASE[\s\S]*?;\s*', '', corpo)
    corpo = re.sub(r'(?m)^USE calculadora_pricing;\s*', '', corpo)
    return corpo.strip('\n')


esq_c = sem_cabecalho(ler('01-esquema.sql'))
prod_c = sem_cabecalho(ler('02-produtos.sql'))
exemp_c = sem_cabecalho(ler('03-exemplo.sql'))

# A identidade vira variável de SQL, para trocar em um lugar só.
for velho, novo in [
    ("'luantbastos@gmail.com'", '@MEU_EMAIL'),
    ("'Luan Bastos'", '@MEU_NOME'),
    ("'9437643'", '@MINHA_FUNCIONAL'),
]:
    exemp_c = exemp_c.replace(velho, novo)

CABECALHO = u"""/* ============================================================================
   CALCULADORA DE PRICING PJ - INSTALACAO COMPLETA

   Rode ESTE arquivo, uma vez, e o banco fica pronto: tabelas, catalogo de
   produtos, regua do veredito e cinco clientes ficticios para a tela abrir
   funcionando.

   ---------------------------------------------------------------------------
   ANTES DE RODAR - troque as tres linhas do PASSO 1 pelo SEU e-mail
   corporativo, nome e funcional.

   Por que isso importa: a carteira e encontrada pelo e-mail. Se ele nao bater
   com o que o Power App entrega (ou com mock/perfil.json, no modo local), a
   tela abre dizendo que voce nao tem cliente nenhum - e o problema parece ser
   da ferramenta, quando e so o e-mail.

   ---------------------------------------------------------------------------
   COMO RODAR

   phpMyAdmin:  aba Importar, escolha este arquivo, Executar.
                (ou aba SQL, cole o conteudo inteiro, Executar)

   Terminal:    mysql -u root -p < INSTALAR.sql

   Pode rodar quantas vezes quiser: o script APAGA e recria tudo do zero. Isso
   e proposital enquanto o dado e ficticio - mas e justamente por isso que ele
   NAO deve ser rodado de novo depois que a carga real entrar. Para trocar o
   ficticio pelo real sem perder o catalogo, use LIMPAR-MOCK.sql.

   ---------------------------------------------------------------------------
   O QUE ESTE ARQUIVO CRIA, em ordem:

     1. o banco calculadora_pricing
     2. as 9 tabelas
     3. os 14 produtos e os 9 parametros da regua
     4. 5 clientes ficticios (o MOCK, que depois sai)
     5. voce como administrador
     6. uma conferencia, que imprime o resultado no fim

   ---------------------------------------------------------------------------
   NAO EDITE ESTE ARQUIVO A MAO. Ele e gerado por banco/gerar-instalador.py a
   partir de 01-esquema.sql, 02-produtos.sql e 03-exemplo.sql.

   Compativel com MariaDB 10.1+ e MySQL 5.7+.
   ========================================================================== */


/* ############################################################################
   PASSO 1 - TROQUE ESTAS TRES LINHAS
   ######################################################################### */

SET @MEU_EMAIL       = 'luantbastos@gmail.com';
SET @MEU_NOME        = 'Luan Bastos';
SET @MINHA_FUNCIONAL = '9437643';

/* ######################################################################### */


/* Sem truncar calado: em modo nao-estrito o MySQL aceita um ENUM invalido
   gravando string vazia, e ai o motor de calculo recebe um produto que nao
   sabe como cobra. Melhor a carga falhar na hora. */
SET @MODO_ANTIGO = @@SESSION.sql_mode;
SET SESSION sql_mode = 'STRICT_ALL_TABLES';

/* A collation da CONEXAO precisa ser a mesma das colunas. Uma variavel de
   usuario (@MEU_EMAIL) nasce com a collation da conexao, e comparar ela com
   uma coluna utf8mb4_unicode_ci da "Illegal mix of collations" e derruba o
   script no meio. O padrao da conexao varia de instalacao para instalacao -
   aqui nao fica ao acaso. */
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;


CREATE DATABASE IF NOT EXISTS calculadora_pricing
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE calculadora_pricing;
"""

P1 = u"""
/* ############################################################################
   PARTE 1 - AS TABELAS
   ######################################################################### */

"""

P2 = u"""

/* ############################################################################
   PARTE 2 - O CATALOGO DE PRODUTOS E A REGUA DO VEREDITO

   Esta parte PERMANECE quando o dado real entrar. Os fatores daqui sao
   provisorios; depois da primeira carga quem manda neles e a tela de
   administracao, e rodar este arquivo de novo apagaria o que a area tiver
   ajustado.
   ######################################################################### */

"""

P3 = u"""

/* ############################################################################
   PARTE 3 - OS DADOS FICTICIOS (O MOCK)

   TUDO DAQUI PARA BAIXO SAI quando o dado real entrar. Sao as tres tabelas de
   carga - encarteiramento, fdados e fdados_produto - mais voce como
   administrador.

   Use LIMPAR-MOCK.sql para remove-las sem tocar no catalogo.
   ######################################################################### */

"""

CONFERENCIA = u"""


/* ############################################################################
   PARTE 4 - CONFERENCIA

   Roda sozinha no fim e imprime o resultado. Se algum numero vier diferente do
   esperado, a instalacao nao ficou completa - e e melhor descobrir agora do
   que na frente de um cliente.
   ######################################################################### */

SET SESSION sql_mode = @MODO_ANTIGO;

SELECT '=== INSTALACAO CONCLUIDA ===' AS `Calculadora de Pricing PJ`;

SELECT
    'Tabelas criadas' AS `O que`,
    COUNT(*)          AS `Encontrado`,
    9                 AS `Esperado`,
    IF(COUNT(*) = 9, 'OK', '>>> FALTA TABELA') AS `Situacao`
  FROM information_schema.tables
 WHERE table_schema = 'calculadora_pricing'

UNION ALL SELECT 'Produtos no catalogo', COUNT(*), 14,
    IF(COUNT(*) = 14, 'OK', '>>> CONFERIR') FROM dim_produto
UNION ALL SELECT 'Produtos ativos', COUNT(*), 12,
    IF(COUNT(*) = 12, 'OK', '>>> CONFERIR') FROM dim_produto WHERE ativo = 1
UNION ALL SELECT 'Parametros da regua', COUNT(*), 9,
    IF(COUNT(*) = 9, 'OK', '>>> CONFERIR') FROM parametro
UNION ALL SELECT 'Contas no encarteiramento', COUNT(*), 7,
    IF(COUNT(*) = 7, 'OK', '>>> CONFERIR') FROM encarteiramento
UNION ALL SELECT 'Clientes em fdados', COUNT(*), 12,
    IF(COUNT(*) = 12, 'OK', '>>> CONFERIR') FROM fdados
UNION ALL SELECT 'Linhas por produto', COUNT(*), 45,
    IF(COUNT(*) = 45, 'OK', '>>> CONFERIR') FROM fdados_produto
UNION ALL SELECT 'Administradores', COUNT(*), 1,
    IF(COUNT(*) >= 1, 'OK', '>>> NINGUEM ADMINISTRA') FROM app_admin;


/* --- a sua carteira -------------------------------------------------------
   Zero aqui quer dizer que o e-mail do PASSO 1 nao bate com o que foi gravado.
   E o erro mais comum, e o mais facil de corrigir.                          */
SELECT
    'Clientes na SUA carteira' AS `O que`,
    COUNT(DISTINCT cnpj)       AS `Encontrado`,
    @MEU_EMAIL                 AS `Procurando pelo e-mail`,
    IF(COUNT(*) > 0, 'OK', '>>> NENHUM: confira o e-mail do PASSO 1') AS `Situacao`
  FROM encarteiramento
 WHERE ativo = 1
   AND LOWER(gerente_email) = LOWER(@MEU_EMAIL COLLATE utf8mb4_unicode_ci);


/* --- as somas batem? ------------------------------------------------------
   O cabecalho de fdados tem que bater com a soma da abertura por produto. Se
   divergir, o gerente ve dois numeros que nao conversam na mesma tela.      */
SELECT
    'Clientes com soma divergente' AS `O que`,
    COUNT(*)                       AS `Encontrado`,
    0                              AS `Esperado`,
    IF(COUNT(*) = 0, 'OK', '>>> CONFERIR A CARGA') AS `Situacao`
  FROM (
    SELECT f.chave
      FROM fdados f
      JOIN fdados_produto fp ON fp.chave = f.chave AND fp.nivel = f.nivel
     GROUP BY f.chave, f.nivel, f.receita_mensal_atual
    HAVING ABS(f.receita_mensal_atual - ROUND(SUM(fp.receita_atual), 2)) > 1
  ) AS divergentes;


/* --- produto orfao --------------------------------------------------------
   Codigo que a carga conhece e o catalogo nao. Some da tela sem avisar.     */
SELECT
    'Produtos orfaos na carga' AS `O que`,
    COUNT(*)                   AS `Encontrado`,
    0                          AS `Esperado`,
    IF(COUNT(*) = 0, 'OK', '>>> HA CODIGO SEM CADASTRO') AS `Situacao`
  FROM (
    SELECT DISTINCT fp.produto_codigo
      FROM fdados_produto fp
      LEFT JOIN dim_produto p ON p.codigo = fp.produto_codigo
     WHERE p.codigo IS NULL
  ) AS orfaos;


SELECT CONCAT(
    'Pronto. Agora troque o e-mail em mock/perfil.json para ', @MEU_EMAIL,
    ' e abra a calculadora.'
) AS `Proximo passo`;
"""

saida = CABECALHO + P1 + esq_c + P2 + prod_c + P3 + exemp_c + CONFERENCIA

destino = os.path.join(os.path.dirname(AQUI), 'INSTALAR.sql')
io.open(destino, 'w', encoding='utf-8', newline='\n').write(saida)

print('banco/INSTALAR.sql gerado: %d linhas' % saida.count('\n'))
print('  @MEU_EMAIL usado %d vezes' % saida.count('@MEU_EMAIL'))
literal = saida.count('luantbastos@gmail.com')
print('  e-mail literal: %d %s' % (literal, '(so o do PASSO 1 - ok)' if literal == 1
                                   else '>>> DEVERIA SER 1'))
