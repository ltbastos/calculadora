/* ============================================================================
   TROCAR O DADO FICTICIO PELO REAL

   Rode isto quando a carga de verdade estiver pronta para entrar. Ele apaga
   SO os dados ficticios das tres tabelas de carga.

   ---------------------------------------------------------------------------
   O QUE SAI                          O QUE FICA

     encarteiramento                    dim_produto     (o catalogo)
     fdados                             parametro       (a regua do veredito)
     fdados_produto                     app_admin       (quem administra)
     simulacoes de teste                fator_historico (o rastro de precos)

   Por que o catalogo fica: depois da primeira semana de uso, os fatores de
   dim_produto ja nao sao os que vieram do INSTALAR.sql — sao os que a area
   ajustou pela tela. Apagar essa tabela jogaria fora esse trabalho e, pior,
   faria as simulacoes ja gravadas apontarem para produtos que nao existem
   mais.

   Por que fator_historico fica: ele existe para responder "por que essa tarifa
   mudou?". Um historico que se apaga nao responde nada.

   ---------------------------------------------------------------------------
   NAO rode o INSTALAR.sql de novo depois disto. Aquele arquivo recria tudo do
   zero, catalogo incluido.
   ========================================================================== */

USE calculadora_pricing;


/* --------------------------------------------------------------------------
   1. FORA O FICTICIO
   ------------------------------------------------------------------------ */

DELETE FROM fdados_produto;
DELETE FROM fdados;
DELETE FROM encarteiramento;

/* As simulacoes feitas contra clientes ficticios nao servem de historico de
   nada. Os itens saem junto pela chave estrangeira.

   COMENTE as duas linhas abaixo se voce quiser guardar as simulacoes de
   treinamento — elas nao atrapalham, so ficam apontando para clientes que
   nao existem mais. */
DELETE FROM simulacao_item;
DELETE FROM simulacao;

/* O AUTO_INCREMENT volta ao 1. So para a base real nascer limpa; nao muda
   nada no funcionamento. */
ALTER TABLE encarteiramento AUTO_INCREMENT = 1;
ALTER TABLE fdados          AUTO_INCREMENT = 1;
ALTER TABLE fdados_produto  AUTO_INCREMENT = 1;


/* --------------------------------------------------------------------------
   2. AGORA CARREGUE O REAL

   As tres tabelas, nesta ordem. O formato de cada coluna esta em DEPLOY.md,
   secao "Carregar as tres tabelas" — vale conferir antes, principalmente os
   tres pontos abaixo, que sao os que mais custam tempo quando passam batido.

   ---------------------------------------------------------------------------
   a) CNPJ E CONTA SO COM DIGITOS, e com os zeros a esquerda.

      Um CNPJ que passou por coluna numerica do Excel perde o zero da frente:
      01234567000189 vira 1234567000189, e o cliente some da busca para
      sempre. Importe como TEXTO.

   b) A CHAVE de fdados e fdados_produto tambem e so digitos.

      CNPJ com ponto, conta com traco e grupo com prefixo sao formas de
      ESCREVER a mesma coisa. Se o banco guardar a forma escrita, a busca
      falha no primeiro cliente que alguem digitou diferente.

   c) produto_codigo TEM QUE EXISTIR em dim_produto.

      E a unica amarracao entre a carga e o catalogo. Codigo que o catalogo
      nao conhece some da tela sem avisar.
   ------------------------------------------------------------------------ */


/* --------------------------------------------------------------------------
   3. DEPOIS DA CARGA, RODE ESTA CONFERENCIA

   Os quatro numeros abaixo tem que dar ZERO. Cada um deles e um problema que
   so aparece na tela como "esse cliente sumiu" ou "esse numero nao bate", sem
   dizer o motivo.
   ------------------------------------------------------------------------ */

SELECT 'CNPJ fora de 14 digitos' AS `Problema`, COUNT(*) AS `Quantos`,
       IF(COUNT(*) = 0, 'OK', '>>> perdeu zero a esquerda no Excel') AS `Situacao`
  FROM encarteiramento WHERE LENGTH(cnpj) <> 14

UNION ALL
SELECT 'Chave com caractere nao numerico', COUNT(*),
       IF(COUNT(*) = 0, 'OK', '>>> normalize a chave para so digitos')
  FROM fdados WHERE chave REGEXP '[^0-9]'

UNION ALL
SELECT 'Produto da carga sem cadastro', COUNT(*),
       IF(COUNT(*) = 0, 'OK', '>>> codigo nao existe em dim_produto')
  FROM (SELECT DISTINCT fp.produto_codigo
          FROM fdados_produto fp
          LEFT JOIN dim_produto p ON p.codigo = fp.produto_codigo
         WHERE p.codigo IS NULL) AS orfaos

UNION ALL
SELECT 'Cliente com soma divergente', COUNT(*),
       IF(COUNT(*) = 0, 'OK', '>>> cabecalho e abertura de recortes diferentes')
  FROM (SELECT f.chave
          FROM fdados f
          JOIN fdados_produto fp ON fp.chave = f.chave AND fp.nivel = f.nivel
         GROUP BY f.chave, f.nivel, f.receita_mensal_atual
        HAVING ABS(f.receita_mensal_atual - ROUND(SUM(fp.receita_atual), 2)) > 1
       ) AS divergentes;


/* --- e a sua carteira apareceu? -------------------------------------------
   Troque o e-mail e rode. Zero aqui quer dizer que gerente_email da carga nao
   bate com o e-mail que o Power App entrega.                                */

SELECT COUNT(DISTINCT cnpj) AS `Clientes na minha carteira`
  FROM encarteiramento
 WHERE ativo = 1
   AND LOWER(gerente_email) = LOWER('troque@pelo.seu.email');
